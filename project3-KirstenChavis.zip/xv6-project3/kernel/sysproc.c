#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"
#include "vm.h"

uint64
sys_exit(void)
{
  int n;
  argint(0, &n);
  kexit(n);
  return 0; // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return kfork();
}

uint64
sys_wait(void)
{
  uint64 p;
  argaddr(0, &p);
  return kwait(p);
}

uint64
sys_sbrk(void)
{
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
  argint(1, &t);
  addr = myproc()->sz;

  if (t == SBRK_EAGER || n < 0) {
    if (growproc(n) < 0) {
      return -1;
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if (addr + n < addr)
      return -1;
    if (addr + n > TRAPFRAME)
      return -1;
    myproc()->sz += n;
  }
  return addr;
}

uint64
sys_pause(void)
{
  acquire(&tickslock);
  
  sleep(&ticks, &tickslock);
  
  release(&tickslock);
  return 0;
}


uint64
sys_kill(void)
{
  int pid;

  argint(0, &pid);
  return kkill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

uint64
sys_setpriority(void)
{
  int new_priority;
  int old_priority;
  struct proc *p = myproc();

  // Extract the first integer argument
  argint(0, &new_priority);

  // Reject values outside 0 through 200
  if (new_priority < 0 || new_priority > 200) {
    return -1;
  }

  acquire(&p->lock);
  
  // Save current priority for evaluation and eventual return
  old_priority = p->priority;
  
  // Assign the new priority requested by user space
  p->priority = new_priority;

  if (new_priority > old_priority) {
    release(&p->lock);
    yield();
  } else {
    release(&p->lock);
  }

  return (uint64)old_priority;
}
