kernel/trap.o: kernel/trap.c kernel/types.h kernel/param.h \
 kernel/memlayout.h kernel/riscv.h kernel/spinlock.h kernel/proc.h \
 kernel/defs.h C:/msys64/ucrt64/riscv64-unknown-elf/include/stdio.h \
 C:/msys64/ucrt64/riscv64-unknown-elf/include/_ansi.h \
 C:/msys64/ucrt64/riscv64-unknown-elf/include/newlib.h \
 C:/msys64/ucrt64/riscv64-unknown-elf/include/_newlib_version.h \
 C:/msys64/ucrt64/riscv64-unknown-elf/include/sys/config.h \
 C:/msys64/ucrt64/riscv64-unknown-elf/include/machine/ieeefp.h \
 C:/msys64/ucrt64/riscv64-unknown-elf/include/sys/features.h \
 C:/msys64/ucrt64/riscv64-unknown-elf/include/sys/cdefs.h \
 C:/msys64/ucrt64/riscv64-unknown-elf/include/machine/_default_types.h \
 C:/msys64/ucrt64/lib/gcc/riscv64-unknown-elf/16.1.0/include/stddef.h \
 C:/msys64/ucrt64/lib/gcc/riscv64-unknown-elf/16.1.0/include/stdarg.h \
 C:/msys64/ucrt64/riscv64-unknown-elf/include/sys/reent.h \
 C:/msys64/ucrt64/riscv64-unknown-elf/include/_ansi.h \
 C:/msys64/ucrt64/riscv64-unknown-elf/include/sys/_types.h \
 C:/msys64/ucrt64/riscv64-unknown-elf/include/machine/_types.h \
 C:/msys64/ucrt64/riscv64-unknown-elf/include/sys/lock.h \
 C:/msys64/ucrt64/riscv64-unknown-elf/include/sys/stdio.h
