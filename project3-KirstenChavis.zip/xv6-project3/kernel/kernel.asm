
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
_entry:
        # set up a stack for C.
        # stack0 is declared in start.c,
        # with a 4096-byte stack per CPU.
        # sp = stack0 + ((hartid + 1) * 4096)
        la sp, stack0
    80000000:	00008117          	auipc	sp,0x8
    80000004:	8e010113          	addi	sp,sp,-1824 # 800078e0 <stack0>
        li a0, 1024*4
    80000008:	6505                	lui	a0,0x1
        csrr a1, mhartid
    8000000a:	f14025f3          	csrr	a1,mhartid
        addi a1, a1, 1
    8000000e:	0585                	addi	a1,a1,1
        mul a0, a0, a1
    80000010:	02b50533          	mul	a0,a0,a1
        add sp, sp, a0
    80000014:	912a                	add	sp,sp,a0
        # jump to start() in start.c
        call start
    80000016:	042000ef          	jal	80000058 <start>

000000008000001a <spin>:
spin:
        j spin
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e406                	sd	ra,8(sp)
    80000020:	e022                	sd	s0,0(sp)
    80000022:	0800                	addi	s0,sp,16
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r"(x));
    80000024:	30a027f3          	csrr	a5,0x30a
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | MENVCFG_STCE);
    80000028:	577d                	li	a4,-1
    8000002a:	177e                	slli	a4,a4,0x3f
    8000002c:	8fd9                	or	a5,a5,a4

static inline void
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r"(x));
    8000002e:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r"(x));
    80000032:	306027f3          	csrr	a5,mcounteren

  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000036:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r"(x));
    8000003a:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r"(x));
    8000003e:	c01027f3          	rdtime	a5

  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    80000042:	000f4737          	lui	a4,0xf4
    80000046:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    8000004a:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r"(x));
    8000004c:	14d79073          	csrw	stimecmp,a5
}
    80000050:	60a2                	ld	ra,8(sp)
    80000052:	6402                	ld	s0,0(sp)
    80000054:	0141                	addi	sp,sp,16
    80000056:	8082                	ret

0000000080000058 <start>:
{
    80000058:	1141                	addi	sp,sp,-16
    8000005a:	e406                	sd	ra,8(sp)
    8000005c:	e022                	sd	s0,0(sp)
    8000005e:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r"(x));
    80000060:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80000064:	7779                	lui	a4,0xffffe
    80000066:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffdda17>
    8000006a:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    8000006c:	6705                	lui	a4,0x1
    8000006e:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    80000072:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r"(x));
    80000074:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r"(x));
    80000078:	00001797          	auipc	a5,0x1
    8000007c:	e1c78793          	addi	a5,a5,-484 # 80000e94 <main>
    80000080:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r"(x));
    80000084:	4781                	li	a5,0
    80000086:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r"(x));
    8000008a:	67c1                	lui	a5,0x10
    8000008c:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    8000008e:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r"(x));
    80000092:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r"(x));
    80000096:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    8000009a:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r"(x));
    8000009e:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r"(x));
    800000a2:	57fd                	li	a5,-1
    800000a4:	83a9                	srli	a5,a5,0xa
    800000a6:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r"(x));
    800000aa:	47bd                	li	a5,15
    800000ac:	3a079073          	csrw	pmpcfg0,a5
  asm volatile("csrr %0, 0x30a" : "=r"(x));
    800000b0:	30a027f3          	csrr	a5,0x30a
  w_menvcfg(r_menvcfg() | MENVCFG_ADUE);
    800000b4:	4705                	li	a4,1
    800000b6:	1776                	slli	a4,a4,0x3d
    800000b8:	8fd9                	or	a5,a5,a4
  asm volatile("csrw 0x30a, %0" : : "r"(x));
    800000ba:	30a79073          	csrw	0x30a,a5
  timerinit();
    800000be:	f5fff0ef          	jal	8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r"(x));
    800000c2:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c6:	2781                	sext.w	a5,a5
}

static inline void
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r"(x));
    800000c8:	823e                	mv	tp,a5
  asm volatile("mret");
    800000ca:	30200073          	mret
}
    800000ce:	60a2                	ld	ra,8(sp)
    800000d0:	6402                	ld	s0,0(sp)
    800000d2:	0141                	addi	sp,sp,16
    800000d4:	8082                	ret

00000000800000d6 <consolewrite>:
// user write() system calls to the console go here.
// uses sleep() and UART interrupts.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000d6:	7119                	addi	sp,sp,-128
    800000d8:	fc86                	sd	ra,120(sp)
    800000da:	f8a2                	sd	s0,112(sp)
    800000dc:	f4a6                	sd	s1,104(sp)
    800000de:	0100                	addi	s0,sp,128
  char buf[32]; // move batches from user space to uart.
  int i = 0;

  while (i < n) {
    800000e0:	06c05b63          	blez	a2,80000156 <consolewrite+0x80>
    800000e4:	f0ca                	sd	s2,96(sp)
    800000e6:	ecce                	sd	s3,88(sp)
    800000e8:	e8d2                	sd	s4,80(sp)
    800000ea:	e4d6                	sd	s5,72(sp)
    800000ec:	e0da                	sd	s6,64(sp)
    800000ee:	fc5e                	sd	s7,56(sp)
    800000f0:	f862                	sd	s8,48(sp)
    800000f2:	f466                	sd	s9,40(sp)
    800000f4:	f06a                	sd	s10,32(sp)
    800000f6:	8b2a                	mv	s6,a0
    800000f8:	8bae                	mv	s7,a1
    800000fa:	8a32                	mv	s4,a2
  int i = 0;
    800000fc:	4481                	li	s1,0
    int nn = sizeof(buf);
    if (nn > n - i)
    800000fe:	02000c93          	li	s9,32
    80000102:	02000d13          	li	s10,32
      nn = n - i;
    if (either_copyin(buf, user_src, src + i, nn) == -1)
    80000106:	f8040a93          	addi	s5,s0,-128
    8000010a:	5c7d                	li	s8,-1
    8000010c:	a025                	j	80000134 <consolewrite+0x5e>
    if (nn > n - i)
    8000010e:	0009099b          	sext.w	s3,s2
    if (either_copyin(buf, user_src, src + i, nn) == -1)
    80000112:	86ce                	mv	a3,s3
    80000114:	01748633          	add	a2,s1,s7
    80000118:	85da                	mv	a1,s6
    8000011a:	8556                	mv	a0,s5
    8000011c:	298020ef          	jal	800023b4 <either_copyin>
    80000120:	03850d63          	beq	a0,s8,8000015a <consolewrite+0x84>
      break;
    uartwrite(buf, nn);
    80000124:	85ce                	mv	a1,s3
    80000126:	8556                	mv	a0,s5
    80000128:	7c0000ef          	jal	800008e8 <uartwrite>
    i += nn;
    8000012c:	009904bb          	addw	s1,s2,s1
  while (i < n) {
    80000130:	0144d963          	bge	s1,s4,80000142 <consolewrite+0x6c>
    if (nn > n - i)
    80000134:	409a07bb          	subw	a5,s4,s1
    80000138:	893e                	mv	s2,a5
    8000013a:	fcfcdae3          	bge	s9,a5,8000010e <consolewrite+0x38>
    8000013e:	896a                	mv	s2,s10
    80000140:	b7f9                	j	8000010e <consolewrite+0x38>
    80000142:	7906                	ld	s2,96(sp)
    80000144:	69e6                	ld	s3,88(sp)
    80000146:	6a46                	ld	s4,80(sp)
    80000148:	6aa6                	ld	s5,72(sp)
    8000014a:	6b06                	ld	s6,64(sp)
    8000014c:	7be2                	ld	s7,56(sp)
    8000014e:	7c42                	ld	s8,48(sp)
    80000150:	7ca2                	ld	s9,40(sp)
    80000152:	7d02                	ld	s10,32(sp)
    80000154:	a821                	j	8000016c <consolewrite+0x96>
  int i = 0;
    80000156:	4481                	li	s1,0
    80000158:	a811                	j	8000016c <consolewrite+0x96>
    8000015a:	7906                	ld	s2,96(sp)
    8000015c:	69e6                	ld	s3,88(sp)
    8000015e:	6a46                	ld	s4,80(sp)
    80000160:	6aa6                	ld	s5,72(sp)
    80000162:	6b06                	ld	s6,64(sp)
    80000164:	7be2                	ld	s7,56(sp)
    80000166:	7c42                	ld	s8,48(sp)
    80000168:	7ca2                	ld	s9,40(sp)
    8000016a:	7d02                	ld	s10,32(sp)
  }

  return i;
}
    8000016c:	8526                	mv	a0,s1
    8000016e:	70e6                	ld	ra,120(sp)
    80000170:	7446                	ld	s0,112(sp)
    80000172:	74a6                	ld	s1,104(sp)
    80000174:	6109                	addi	sp,sp,128
    80000176:	8082                	ret

0000000080000178 <consoleread>:
// user_dst indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80000178:	711d                	addi	sp,sp,-96
    8000017a:	ec86                	sd	ra,88(sp)
    8000017c:	e8a2                	sd	s0,80(sp)
    8000017e:	e4a6                	sd	s1,72(sp)
    80000180:	e0ca                	sd	s2,64(sp)
    80000182:	fc4e                	sd	s3,56(sp)
    80000184:	f852                	sd	s4,48(sp)
    80000186:	f05a                	sd	s6,32(sp)
    80000188:	ec5e                	sd	s7,24(sp)
    8000018a:	1080                	addi	s0,sp,96
    8000018c:	8b2a                	mv	s6,a0
    8000018e:	8a2e                	mv	s4,a1
    80000190:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80000192:	8bb2                	mv	s7,a2
  acquire(&cons.lock);
    80000194:	0000f517          	auipc	a0,0xf
    80000198:	74c50513          	addi	a0,a0,1868 # 8000f8e0 <cons>
    8000019c:	275000ef          	jal	80000c10 <acquire>
  while (n > 0) {
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while (cons.r == cons.w) {
    800001a0:	0000f497          	auipc	s1,0xf
    800001a4:	74048493          	addi	s1,s1,1856 # 8000f8e0 <cons>
      if (killed(myproc())) {
        release(&cons.lock);
        return -1;
      }
      sleep_prepare(&cons.r);
    800001a8:	0000f917          	auipc	s2,0xf
    800001ac:	7d090913          	addi	s2,s2,2000 # 8000f978 <cons+0x98>
  while (n > 0) {
    800001b0:	0b305e63          	blez	s3,8000026c <consoleread+0xf4>
    while (cons.r == cons.w) {
    800001b4:	0984a783          	lw	a5,152(s1)
    800001b8:	09c4a703          	lw	a4,156(s1)
    800001bc:	0af71363          	bne	a4,a5,80000262 <consoleread+0xea>
      if (killed(myproc())) {
    800001c0:	756010ef          	jal	80001916 <myproc>
    800001c4:	080020ef          	jal	80002244 <killed>
    800001c8:	e525                	bnez	a0,80000230 <consoleread+0xb8>
      sleep_prepare(&cons.r);
    800001ca:	854a                	mv	a0,s2
    800001cc:	5d9010ef          	jal	80001fa4 <sleep_prepare>
//      release(&cons.lock);
      sleep(&cons.r, &cons.lock);
    800001d0:	85a6                	mv	a1,s1
    800001d2:	854a                	mv	a0,s2
    800001d4:	60d010ef          	jal	80001fe0 <sleep>
    while (cons.r == cons.w) {
    800001d8:	0984a783          	lw	a5,152(s1)
    800001dc:	09c4a703          	lw	a4,156(s1)
    800001e0:	fef700e3          	beq	a4,a5,800001c0 <consoleread+0x48>
    800001e4:	f456                	sd	s5,40(sp)
//      acquire(&cons.lock);
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001e6:	0000f717          	auipc	a4,0xf
    800001ea:	6fa70713          	addi	a4,a4,1786 # 8000f8e0 <cons>
    800001ee:	0017869b          	addiw	a3,a5,1
    800001f2:	08d72c23          	sw	a3,152(a4)
    800001f6:	07f7f693          	andi	a3,a5,127
    800001fa:	9736                	add	a4,a4,a3
    800001fc:	01874703          	lbu	a4,24(a4)
    80000200:	00070a9b          	sext.w	s5,a4

    if (c == C('D')) { // end-of-file
    80000204:	4691                	li	a3,4
    80000206:	04da8663          	beq	s5,a3,80000252 <consoleread+0xda>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    8000020a:	fae407a3          	sb	a4,-81(s0)
    if (either_copyout(user_dst, dst, &cbuf, 1) == -1)
    8000020e:	4685                	li	a3,1
    80000210:	faf40613          	addi	a2,s0,-81
    80000214:	85d2                	mv	a1,s4
    80000216:	855a                	mv	a0,s6
    80000218:	150020ef          	jal	80002368 <either_copyout>
    8000021c:	57fd                	li	a5,-1
    8000021e:	04f50663          	beq	a0,a5,8000026a <consoleread+0xf2>
      break;

    dst++;
    80000222:	0a05                	addi	s4,s4,1
    --n;
    80000224:	39fd                	addiw	s3,s3,-1

    if (c == '\n') {
    80000226:	47a9                	li	a5,10
    80000228:	04fa8b63          	beq	s5,a5,8000027e <consoleread+0x106>
    8000022c:	7aa2                	ld	s5,40(sp)
    8000022e:	b749                	j	800001b0 <consoleread+0x38>
        release(&cons.lock);
    80000230:	0000f517          	auipc	a0,0xf
    80000234:	6b050513          	addi	a0,a0,1712 # 8000f8e0 <cons>
    80000238:	26b000ef          	jal	80000ca2 <release>
        return -1;
    8000023c:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    8000023e:	60e6                	ld	ra,88(sp)
    80000240:	6446                	ld	s0,80(sp)
    80000242:	64a6                	ld	s1,72(sp)
    80000244:	6906                	ld	s2,64(sp)
    80000246:	79e2                	ld	s3,56(sp)
    80000248:	7a42                	ld	s4,48(sp)
    8000024a:	7b02                	ld	s6,32(sp)
    8000024c:	6be2                	ld	s7,24(sp)
    8000024e:	6125                	addi	sp,sp,96
    80000250:	8082                	ret
      if (n < target) {
    80000252:	0179fa63          	bgeu	s3,s7,80000266 <consoleread+0xee>
        cons.r--;
    80000256:	0000f717          	auipc	a4,0xf
    8000025a:	72f72123          	sw	a5,1826(a4) # 8000f978 <cons+0x98>
    8000025e:	7aa2                	ld	s5,40(sp)
    80000260:	a031                	j	8000026c <consoleread+0xf4>
    80000262:	f456                	sd	s5,40(sp)
    80000264:	b749                	j	800001e6 <consoleread+0x6e>
    80000266:	7aa2                	ld	s5,40(sp)
    80000268:	a011                	j	8000026c <consoleread+0xf4>
    8000026a:	7aa2                	ld	s5,40(sp)
  release(&cons.lock);
    8000026c:	0000f517          	auipc	a0,0xf
    80000270:	67450513          	addi	a0,a0,1652 # 8000f8e0 <cons>
    80000274:	22f000ef          	jal	80000ca2 <release>
  return target - n;
    80000278:	413b853b          	subw	a0,s7,s3
    8000027c:	b7c9                	j	8000023e <consoleread+0xc6>
    8000027e:	7aa2                	ld	s5,40(sp)
    80000280:	b7f5                	j	8000026c <consoleread+0xf4>

0000000080000282 <consputc>:
{
    80000282:	1141                	addi	sp,sp,-16
    80000284:	e406                	sd	ra,8(sp)
    80000286:	e022                	sd	s0,0(sp)
    80000288:	0800                	addi	s0,sp,16
if(panicking) {
    8000028a:	00007797          	auipc	a5,0x7
    8000028e:	61a7a783          	lw	a5,1562(a5) # 800078a4 <panicking>
    80000292:	e799                	bnez	a5,800002a0 <consputc+0x1e>
uartputc_sync(c);
    80000294:	6e8000ef          	jal	8000097c <uartputc_sync>
}
    80000298:	60a2                	ld	ra,8(sp)
    8000029a:	6402                	ld	s0,0(sp)
    8000029c:	0141                	addi	sp,sp,16
    8000029e:	8082                	ret
uartputc_sync(c); 
    800002a0:	6dc000ef          	jal	8000097c <uartputc_sync>
return;
    800002a4:	bfd5                	j	80000298 <consputc+0x16>

00000000800002a6 <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    800002a6:	1101                	addi	sp,sp,-32
    800002a8:	ec06                	sd	ra,24(sp)
    800002aa:	e822                	sd	s0,16(sp)
    800002ac:	e426                	sd	s1,8(sp)
    800002ae:	1000                	addi	s0,sp,32
    800002b0:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    800002b2:	0000f517          	auipc	a0,0xf
    800002b6:	62e50513          	addi	a0,a0,1582 # 8000f8e0 <cons>
    800002ba:	157000ef          	jal	80000c10 <acquire>

  switch (c) {
    800002be:	47d5                	li	a5,21
    800002c0:	0af48163          	beq	s1,a5,80000362 <consoleintr+0xbc>
    800002c4:	0297c563          	blt	a5,s1,800002ee <consoleintr+0x48>
    800002c8:	47a1                	li	a5,8
    800002ca:	0ef48663          	beq	s1,a5,800003b6 <consoleintr+0x110>
    800002ce:	47c1                	li	a5,16
    800002d0:	10f49763          	bne	s1,a5,800003de <consoleintr+0x138>
  case C('P'): // Print process list.
    procdump();
    800002d4:	12c020ef          	jal	80002400 <procdump>
      }
    }
    break;
  }

  release(&cons.lock);
    800002d8:	0000f517          	auipc	a0,0xf
    800002dc:	60850513          	addi	a0,a0,1544 # 8000f8e0 <cons>
    800002e0:	1c3000ef          	jal	80000ca2 <release>
}
    800002e4:	60e2                	ld	ra,24(sp)
    800002e6:	6442                	ld	s0,16(sp)
    800002e8:	64a2                	ld	s1,8(sp)
    800002ea:	6105                	addi	sp,sp,32
    800002ec:	8082                	ret
  switch (c) {
    800002ee:	07f00793          	li	a5,127
    800002f2:	0cf48263          	beq	s1,a5,800003b6 <consoleintr+0x110>
    if (c != 0 && cons.e - cons.r < INPUT_BUF_SIZE) {
    800002f6:	0000f717          	auipc	a4,0xf
    800002fa:	5ea70713          	addi	a4,a4,1514 # 8000f8e0 <cons>
    800002fe:	0a072783          	lw	a5,160(a4)
    80000302:	09872703          	lw	a4,152(a4)
    80000306:	9f99                	subw	a5,a5,a4
    80000308:	07f00713          	li	a4,127
    8000030c:	fcf766e3          	bltu	a4,a5,800002d8 <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    80000310:	47b5                	li	a5,13
    80000312:	0cf48963          	beq	s1,a5,800003e4 <consoleintr+0x13e>
      consputc(c);
    80000316:	8526                	mv	a0,s1
    80000318:	f6bff0ef          	jal	80000282 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    8000031c:	0000f717          	auipc	a4,0xf
    80000320:	5c470713          	addi	a4,a4,1476 # 8000f8e0 <cons>
    80000324:	0a072683          	lw	a3,160(a4)
    80000328:	0016879b          	addiw	a5,a3,1
    8000032c:	863e                	mv	a2,a5
    8000032e:	0af72023          	sw	a5,160(a4)
    80000332:	07f6f693          	andi	a3,a3,127
    80000336:	9736                	add	a4,a4,a3
    80000338:	00970c23          	sb	s1,24(a4)
      if (c == '\n' || c == C('D') || cons.e - cons.r == INPUT_BUF_SIZE) {
    8000033c:	ff648713          	addi	a4,s1,-10
    80000340:	00173713          	seqz	a4,a4
    80000344:	14f1                	addi	s1,s1,-4
    80000346:	0014b493          	seqz	s1,s1
    8000034a:	8f45                	or	a4,a4,s1
    8000034c:	e361                	bnez	a4,8000040c <consoleintr+0x166>
    8000034e:	0000f717          	auipc	a4,0xf
    80000352:	62a72703          	lw	a4,1578(a4) # 8000f978 <cons+0x98>
    80000356:	9f99                	subw	a5,a5,a4
    80000358:	08000713          	li	a4,128
    8000035c:	f6e79ee3          	bne	a5,a4,800002d8 <consoleintr+0x32>
    80000360:	a075                	j	8000040c <consoleintr+0x166>
    80000362:	e04a                	sd	s2,0(sp)
    while (cons.e != cons.w &&
    80000364:	0000f717          	auipc	a4,0xf
    80000368:	57c70713          	addi	a4,a4,1404 # 8000f8e0 <cons>
    8000036c:	0a072783          	lw	a5,160(a4)
    80000370:	09c72703          	lw	a4,156(a4)
           cons.buf[(cons.e - 1) % INPUT_BUF_SIZE] != '\n') {
    80000374:	0000f497          	auipc	s1,0xf
    80000378:	56c48493          	addi	s1,s1,1388 # 8000f8e0 <cons>
    while (cons.e != cons.w &&
    8000037c:	4929                	li	s2,10
    8000037e:	02f70863          	beq	a4,a5,800003ae <consoleintr+0x108>
           cons.buf[(cons.e - 1) % INPUT_BUF_SIZE] != '\n') {
    80000382:	37fd                	addiw	a5,a5,-1
    80000384:	07f7f713          	andi	a4,a5,127
    80000388:	9726                	add	a4,a4,s1
    while (cons.e != cons.w &&
    8000038a:	01874703          	lbu	a4,24(a4)
    8000038e:	03270263          	beq	a4,s2,800003b2 <consoleintr+0x10c>
      cons.e--;
    80000392:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    80000396:	10000513          	li	a0,256
    8000039a:	ee9ff0ef          	jal	80000282 <consputc>
    while (cons.e != cons.w &&
    8000039e:	0a04a783          	lw	a5,160(s1)
    800003a2:	09c4a703          	lw	a4,156(s1)
    800003a6:	fcf71ee3          	bne	a4,a5,80000382 <consoleintr+0xdc>
    800003aa:	6902                	ld	s2,0(sp)
    800003ac:	b735                	j	800002d8 <consoleintr+0x32>
    800003ae:	6902                	ld	s2,0(sp)
    800003b0:	b725                	j	800002d8 <consoleintr+0x32>
    800003b2:	6902                	ld	s2,0(sp)
    800003b4:	b715                	j	800002d8 <consoleintr+0x32>
    if (cons.e != cons.w) {
    800003b6:	0000f717          	auipc	a4,0xf
    800003ba:	52a70713          	addi	a4,a4,1322 # 8000f8e0 <cons>
    800003be:	0a072783          	lw	a5,160(a4)
    800003c2:	09c72703          	lw	a4,156(a4)
    800003c6:	f0f709e3          	beq	a4,a5,800002d8 <consoleintr+0x32>
      cons.e--;
    800003ca:	37fd                	addiw	a5,a5,-1
    800003cc:	0000f717          	auipc	a4,0xf
    800003d0:	5af72a23          	sw	a5,1460(a4) # 8000f980 <cons+0xa0>
      consputc(BACKSPACE);
    800003d4:	10000513          	li	a0,256
    800003d8:	eabff0ef          	jal	80000282 <consputc>
    800003dc:	bdf5                	j	800002d8 <consoleintr+0x32>
    if (c != 0 && cons.e - cons.r < INPUT_BUF_SIZE) {
    800003de:	ee048de3          	beqz	s1,800002d8 <consoleintr+0x32>
    800003e2:	bf11                	j	800002f6 <consoleintr+0x50>
      consputc(c);
    800003e4:	4529                	li	a0,10
    800003e6:	e9dff0ef          	jal	80000282 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800003ea:	0000f797          	auipc	a5,0xf
    800003ee:	4f678793          	addi	a5,a5,1270 # 8000f8e0 <cons>
    800003f2:	0a07a703          	lw	a4,160(a5)
    800003f6:	0017069b          	addiw	a3,a4,1
    800003fa:	8636                	mv	a2,a3
    800003fc:	0ad7a023          	sw	a3,160(a5)
    80000400:	07f77713          	andi	a4,a4,127
    80000404:	97ba                	add	a5,a5,a4
    80000406:	4729                	li	a4,10
    80000408:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    8000040c:	0000f797          	auipc	a5,0xf
    80000410:	56c7a823          	sw	a2,1392(a5) # 8000f97c <cons+0x9c>
        wakeup(&cons.r);
    80000414:	0000f517          	auipc	a0,0xf
    80000418:	56450513          	addi	a0,a0,1380 # 8000f978 <cons+0x98>
    8000041c:	411010ef          	jal	8000202c <wakeup>
    80000420:	bd65                	j	800002d8 <consoleintr+0x32>

0000000080000422 <consoleinit>:

void
consoleinit(void)
{
    80000422:	1141                	addi	sp,sp,-16
    80000424:	e406                	sd	ra,8(sp)
    80000426:	e022                	sd	s0,0(sp)
    80000428:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    8000042a:	00007597          	auipc	a1,0x7
    8000042e:	bd658593          	addi	a1,a1,-1066 # 80007000 <etext>
    80000432:	0000f517          	auipc	a0,0xf
    80000436:	4ae50513          	addi	a0,a0,1198 # 8000f8e0 <cons>
    8000043a:	756000ef          	jal	80000b90 <initlock>

  uartinit();
    8000043e:	454000ef          	jal	80000892 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80000442:	00020797          	auipc	a5,0x20
    80000446:	80e78793          	addi	a5,a5,-2034 # 8001fc50 <devsw>
    8000044a:	00000717          	auipc	a4,0x0
    8000044e:	d2e70713          	addi	a4,a4,-722 # 80000178 <consoleread>
    80000452:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    80000454:	00000717          	auipc	a4,0x0
    80000458:	c8270713          	addi	a4,a4,-894 # 800000d6 <consolewrite>
    8000045c:	ef98                	sd	a4,24(a5)
}
    8000045e:	60a2                	ld	ra,8(sp)
    80000460:	6402                	ld	s0,0(sp)
    80000462:	0141                	addi	sp,sp,16
    80000464:	8082                	ret

0000000080000466 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    80000466:	7139                	addi	sp,sp,-64
    80000468:	fc06                	sd	ra,56(sp)
    8000046a:	f822                	sd	s0,48(sp)
    8000046c:	f04a                	sd	s2,32(sp)
    8000046e:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if (sign && (sign = (xx < 0)))
    80000470:	c219                	beqz	a2,80000476 <printint+0x10>
    80000472:	08054063          	bltz	a0,800004f2 <printint+0x8c>
    x = -xx;
  else
    x = xx;
    80000476:	4301                	li	t1,0

  i = 0;
    80000478:	fc840913          	addi	s2,s0,-56
    x = xx;
    8000047c:	86ca                	mv	a3,s2
  i = 0;
    8000047e:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    80000480:	00007817          	auipc	a6,0x7
    80000484:	2f080813          	addi	a6,a6,752 # 80007770 <digits>
    80000488:	88ba                	mv	a7,a4
    8000048a:	0017061b          	addiw	a2,a4,1
    8000048e:	8732                	mv	a4,a2
    80000490:	02b577b3          	remu	a5,a0,a1
    80000494:	97c2                	add	a5,a5,a6
    80000496:	0007c783          	lbu	a5,0(a5)
    8000049a:	00f68023          	sb	a5,0(a3)
  } while ((x /= base) != 0);
    8000049e:	87aa                	mv	a5,a0
    800004a0:	02b55533          	divu	a0,a0,a1
    800004a4:	0685                	addi	a3,a3,1
    800004a6:	feb7f1e3          	bgeu	a5,a1,80000488 <printint+0x22>

  if (sign)
    800004aa:	00030b63          	beqz	t1,800004c0 <printint+0x5a>
    buf[i++] = '-';
    800004ae:	fe040793          	addi	a5,s0,-32
    800004b2:	963e                	add	a2,a2,a5
    800004b4:	02d00793          	li	a5,45
    800004b8:	fef60423          	sb	a5,-24(a2)
    800004bc:	0028871b          	addiw	a4,a7,2

  while (--i >= 0)
    800004c0:	02e05463          	blez	a4,800004e8 <printint+0x82>
    800004c4:	f426                	sd	s1,40(sp)
    800004c6:	377d                	addiw	a4,a4,-1
    800004c8:	00e904b3          	add	s1,s2,a4
    800004cc:	197d                	addi	s2,s2,-1
    800004ce:	993a                	add	s2,s2,a4
    800004d0:	1702                	slli	a4,a4,0x20
    800004d2:	9301                	srli	a4,a4,0x20
    800004d4:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    800004d8:	0004c503          	lbu	a0,0(s1)
    800004dc:	da7ff0ef          	jal	80000282 <consputc>
  while (--i >= 0)
    800004e0:	14fd                	addi	s1,s1,-1
    800004e2:	ff249be3          	bne	s1,s2,800004d8 <printint+0x72>
    800004e6:	74a2                	ld	s1,40(sp)
}
    800004e8:	70e2                	ld	ra,56(sp)
    800004ea:	7442                	ld	s0,48(sp)
    800004ec:	7902                	ld	s2,32(sp)
    800004ee:	6121                	addi	sp,sp,64
    800004f0:	8082                	ret
    x = -xx;
    800004f2:	40a00533          	neg	a0,a0
  if (sign && (sign = (xx < 0)))
    800004f6:	4305                	li	t1,1
    x = -xx;
    800004f8:	b741                	j	80000478 <printint+0x12>

00000000800004fa <printk>:
}

// Print to the console.
int
printk(char *fmt, ...)
{
    800004fa:	7131                	addi	sp,sp,-192
    800004fc:	fc86                	sd	ra,120(sp)
    800004fe:	f8a2                	sd	s0,112(sp)
    80000500:	f4a6                	sd	s1,104(sp)
    80000502:	0100                	addi	s0,sp,128
    80000504:	84aa                	mv	s1,a0
    80000506:	e40c                	sd	a1,8(s0)
    80000508:	e810                	sd	a2,16(s0)
    8000050a:	ec14                	sd	a3,24(s0)
    8000050c:	f018                	sd	a4,32(s0)
    8000050e:	f41c                	sd	a5,40(s0)
    80000510:	03043823          	sd	a6,48(s0)
    80000514:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2;
  char *s;

  if (panicking == 0)
    80000518:	00007797          	auipc	a5,0x7
    8000051c:	38c7a783          	lw	a5,908(a5) # 800078a4 <panicking>
    80000520:	cf9d                	beqz	a5,8000055e <printk+0x64>
    acquire(&pr.lock);

  va_start(ap, fmt);
    80000522:	00840793          	addi	a5,s0,8
    80000526:	f8f43423          	sd	a5,-120(s0)
  for (i = 0; (cx = fmt[i] & 0xff) != 0; i++) {
    8000052a:	0004c503          	lbu	a0,0(s1)
    8000052e:	22050363          	beqz	a0,80000754 <printk+0x25a>
    80000532:	f0ca                	sd	s2,96(sp)
    80000534:	ecce                	sd	s3,88(sp)
    80000536:	e8d2                	sd	s4,80(sp)
    80000538:	e4d6                	sd	s5,72(sp)
    8000053a:	e0da                	sd	s6,64(sp)
    8000053c:	fc5e                	sd	s7,56(sp)
    8000053e:	f862                	sd	s8,48(sp)
    80000540:	f06a                	sd	s10,32(sp)
    80000542:	ec6e                	sd	s11,24(sp)
    80000544:	4a01                	li	s4,0
    if (cx != '%') {
    80000546:	02500993          	li	s3,37
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if (c0 == 'u') {
    8000054a:	07500c13          	li	s8,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if (c0 == 'x') {
    8000054e:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if (c0 == 'p') {
    80000552:	07000d93          	li	s11,112
      printint(va_arg(ap, uint64), 10, 0);
    80000556:	4b29                	li	s6,10
    if (c0 == 'd') {
    80000558:	06400b93          	li	s7,100
    8000055c:	a015                	j	80000580 <printk+0x86>
    acquire(&pr.lock);
    8000055e:	0000f517          	auipc	a0,0xf
    80000562:	42a50513          	addi	a0,a0,1066 # 8000f988 <pr>
    80000566:	6aa000ef          	jal	80000c10 <acquire>
    8000056a:	bf65                	j	80000522 <printk+0x28>
      consputc(cx);
    8000056c:	d17ff0ef          	jal	80000282 <consputc>
  for (i = 0; (cx = fmt[i] & 0xff) != 0; i++) {
    80000570:	001a079b          	addiw	a5,s4,1
    80000574:	8a3e                	mv	s4,a5
    80000576:	97a6                	add	a5,a5,s1
    80000578:	0007c503          	lbu	a0,0(a5)
    8000057c:	1c050363          	beqz	a0,80000742 <printk+0x248>
    if (cx != '%') {
    80000580:	ff3516e3          	bne	a0,s3,8000056c <printk+0x72>
    i++;
    80000584:	001a091b          	addiw	s2,s4,1
    c0 = fmt[i + 0] & 0xff;
    80000588:	012487b3          	add	a5,s1,s2
    8000058c:	0007ca83          	lbu	s5,0(a5)
    if (c0)
    80000590:	200a8763          	beqz	s5,8000079e <printk+0x2a4>
      c1 = fmt[i + 1] & 0xff;
    80000594:	0017c703          	lbu	a4,1(a5)
    if (c1)
    80000598:	1e070a63          	beqz	a4,8000078c <printk+0x292>
    if (c0 == 'd') {
    8000059c:	037a8963          	beq	s5,s7,800005ce <printk+0xd4>
    } else if (c0 == 'l' && c1 == 'd') {
    800005a0:	f94a8793          	addi	a5,s5,-108
    800005a4:	0017b793          	seqz	a5,a5
    800005a8:	f9c70693          	addi	a3,a4,-100
    800005ac:	0016b693          	seqz	a3,a3
    800005b0:	8efd                	and	a3,a3,a5
    800005b2:	ca9d                	beqz	a3,800005e8 <printk+0xee>
      printint(va_arg(ap, uint64), 10, 1);
    800005b4:	f8843783          	ld	a5,-120(s0)
    800005b8:	00878713          	addi	a4,a5,8
    800005bc:	f8e43423          	sd	a4,-120(s0)
    800005c0:	4605                	li	a2,1
    800005c2:	85da                	mv	a1,s6
    800005c4:	6388                	ld	a0,0(a5)
    800005c6:	ea1ff0ef          	jal	80000466 <printint>
      i += 1;
    800005ca:	2a09                	addiw	s4,s4,2
    800005cc:	b755                	j	80000570 <printk+0x76>
      printint(va_arg(ap, int), 10, 1);
    800005ce:	f8843783          	ld	a5,-120(s0)
    800005d2:	00878713          	addi	a4,a5,8
    800005d6:	f8e43423          	sd	a4,-120(s0)
    800005da:	4605                	li	a2,1
    800005dc:	85da                	mv	a1,s6
    800005de:	4388                	lw	a0,0(a5)
    800005e0:	e87ff0ef          	jal	80000466 <printint>
    i++;
    800005e4:	8a4a                	mv	s4,s2
    800005e6:	b769                	j	80000570 <printk+0x76>
      c2 = fmt[i + 2] & 0xff;
    800005e8:	012486b3          	add	a3,s1,s2
    800005ec:	863a                	mv	a2,a4
    800005ee:	0026c703          	lbu	a4,2(a3)
    800005f2:	aa65                	j	800007aa <printk+0x2b0>
      printint(va_arg(ap, uint64), 10, 1);
    800005f4:	f8843783          	ld	a5,-120(s0)
    800005f8:	00878713          	addi	a4,a5,8
    800005fc:	f8e43423          	sd	a4,-120(s0)
    80000600:	4605                	li	a2,1
    80000602:	45a9                	li	a1,10
    80000604:	6388                	ld	a0,0(a5)
    80000606:	e61ff0ef          	jal	80000466 <printint>
      i += 2;
    8000060a:	2a0d                	addiw	s4,s4,3
    8000060c:	b795                	j	80000570 <printk+0x76>
      printint(va_arg(ap, uint32), 10, 0);
    8000060e:	f8843783          	ld	a5,-120(s0)
    80000612:	00878713          	addi	a4,a5,8
    80000616:	f8e43423          	sd	a4,-120(s0)
    8000061a:	4601                	li	a2,0
    8000061c:	85da                	mv	a1,s6
    8000061e:	0007e503          	lwu	a0,0(a5)
    80000622:	e45ff0ef          	jal	80000466 <printint>
    80000626:	bf7d                	j	800005e4 <printk+0xea>
      printint(va_arg(ap, uint64), 10, 0);
    80000628:	f8843783          	ld	a5,-120(s0)
    8000062c:	00878713          	addi	a4,a5,8
    80000630:	f8e43423          	sd	a4,-120(s0)
    80000634:	4601                	li	a2,0
    80000636:	85da                	mv	a1,s6
    80000638:	6388                	ld	a0,0(a5)
    8000063a:	e2dff0ef          	jal	80000466 <printint>
      i += 1;
    8000063e:	2a09                	addiw	s4,s4,2
    80000640:	bf05                	j	80000570 <printk+0x76>
      printint(va_arg(ap, uint64), 10, 0);
    80000642:	f8843783          	ld	a5,-120(s0)
    80000646:	00878713          	addi	a4,a5,8
    8000064a:	f8e43423          	sd	a4,-120(s0)
    8000064e:	4601                	li	a2,0
    80000650:	45a9                	li	a1,10
    80000652:	6388                	ld	a0,0(a5)
    80000654:	e13ff0ef          	jal	80000466 <printint>
      i += 2;
    80000658:	2a0d                	addiw	s4,s4,3
    8000065a:	bf19                	j	80000570 <printk+0x76>
      printint(va_arg(ap, uint32), 16, 0);
    8000065c:	f8843783          	ld	a5,-120(s0)
    80000660:	00878713          	addi	a4,a5,8
    80000664:	f8e43423          	sd	a4,-120(s0)
    80000668:	4601                	li	a2,0
    8000066a:	45c1                	li	a1,16
    8000066c:	0007e503          	lwu	a0,0(a5)
    80000670:	df7ff0ef          	jal	80000466 <printint>
    80000674:	bf85                	j	800005e4 <printk+0xea>
      printint(va_arg(ap, uint64), 16, 0);
    80000676:	f8843783          	ld	a5,-120(s0)
    8000067a:	00878713          	addi	a4,a5,8
    8000067e:	f8e43423          	sd	a4,-120(s0)
    80000682:	4601                	li	a2,0
    80000684:	45c1                	li	a1,16
    80000686:	6388                	ld	a0,0(a5)
    80000688:	ddfff0ef          	jal	80000466 <printint>
      i += 1;
    8000068c:	2a09                	addiw	s4,s4,2
    8000068e:	b5cd                	j	80000570 <printk+0x76>
      printint(va_arg(ap, uint64), 16, 0);
    80000690:	f8843783          	ld	a5,-120(s0)
    80000694:	00878713          	addi	a4,a5,8
    80000698:	f8e43423          	sd	a4,-120(s0)
    8000069c:	45c1                	li	a1,16
    8000069e:	6388                	ld	a0,0(a5)
    800006a0:	dc7ff0ef          	jal	80000466 <printint>
      i += 2;
    800006a4:	2a0d                	addiw	s4,s4,3
    800006a6:	b5e9                	j	80000570 <printk+0x76>
    800006a8:	f466                	sd	s9,40(sp)
      printptr(va_arg(ap, uint64));
    800006aa:	f8843783          	ld	a5,-120(s0)
    800006ae:	00878713          	addi	a4,a5,8
    800006b2:	f8e43423          	sd	a4,-120(s0)
    800006b6:	0007ba83          	ld	s5,0(a5)
  consputc('0');
    800006ba:	03000513          	li	a0,48
    800006be:	bc5ff0ef          	jal	80000282 <consputc>
  consputc('x');
    800006c2:	07800513          	li	a0,120
    800006c6:	bbdff0ef          	jal	80000282 <consputc>
    800006ca:	4a41                	li	s4,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800006cc:	00007c97          	auipc	s9,0x7
    800006d0:	0a4c8c93          	addi	s9,s9,164 # 80007770 <digits>
    800006d4:	03cad793          	srli	a5,s5,0x3c
    800006d8:	97e6                	add	a5,a5,s9
    800006da:	0007c503          	lbu	a0,0(a5)
    800006de:	ba5ff0ef          	jal	80000282 <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800006e2:	0a92                	slli	s5,s5,0x4
    800006e4:	3a7d                	addiw	s4,s4,-1
    800006e6:	fe0a17e3          	bnez	s4,800006d4 <printk+0x1da>
    800006ea:	7ca2                	ld	s9,40(sp)
    800006ec:	bde5                	j	800005e4 <printk+0xea>
    } else if (c0 == 'c') {
      consputc(va_arg(ap, uint));
    800006ee:	f8843783          	ld	a5,-120(s0)
    800006f2:	00878713          	addi	a4,a5,8
    800006f6:	f8e43423          	sd	a4,-120(s0)
    800006fa:	4388                	lw	a0,0(a5)
    800006fc:	b87ff0ef          	jal	80000282 <consputc>
    80000700:	b5d5                	j	800005e4 <printk+0xea>
    } else if (c0 == 's') {
      if ((s = va_arg(ap, char *)) == 0)
    80000702:	f8843783          	ld	a5,-120(s0)
    80000706:	00878713          	addi	a4,a5,8
    8000070a:	f8e43423          	sd	a4,-120(s0)
    8000070e:	0007ba03          	ld	s4,0(a5)
    80000712:	000a0d63          	beqz	s4,8000072c <printk+0x232>
        s = "(null)";
      for (; *s; s++)
    80000716:	000a4503          	lbu	a0,0(s4)
    8000071a:	ec0505e3          	beqz	a0,800005e4 <printk+0xea>
        consputc(*s);
    8000071e:	b65ff0ef          	jal	80000282 <consputc>
      for (; *s; s++)
    80000722:	0a05                	addi	s4,s4,1
    80000724:	000a4503          	lbu	a0,0(s4)
    80000728:	f97d                	bnez	a0,8000071e <printk+0x224>
    8000072a:	bd6d                	j	800005e4 <printk+0xea>
        s = "(null)";
    8000072c:	00007a17          	auipc	s4,0x7
    80000730:	8dca0a13          	addi	s4,s4,-1828 # 80007008 <etext+0x8>
      for (; *s; s++)
    80000734:	02800513          	li	a0,40
    80000738:	b7dd                	j	8000071e <printk+0x224>
    } else if (c0 == '%') {
      consputc('%');
    8000073a:	8556                	mv	a0,s5
    8000073c:	b47ff0ef          	jal	80000282 <consputc>
    80000740:	b555                	j	800005e4 <printk+0xea>
    80000742:	7906                	ld	s2,96(sp)
    80000744:	69e6                	ld	s3,88(sp)
    80000746:	6a46                	ld	s4,80(sp)
    80000748:	6aa6                	ld	s5,72(sp)
    8000074a:	6b06                	ld	s6,64(sp)
    8000074c:	7be2                	ld	s7,56(sp)
    8000074e:	7c42                	ld	s8,48(sp)
    80000750:	7d02                	ld	s10,32(sp)
    80000752:	6de2                	ld	s11,24(sp)
      consputc(c0);
    }
  }
  va_end(ap);

  if (panicking == 0)
    80000754:	00007797          	auipc	a5,0x7
    80000758:	1507a783          	lw	a5,336(a5) # 800078a4 <panicking>
    8000075c:	c38d                	beqz	a5,8000077e <printk+0x284>
    release(&pr.lock);

  return 0;
}
    8000075e:	4501                	li	a0,0
    80000760:	70e6                	ld	ra,120(sp)
    80000762:	7446                	ld	s0,112(sp)
    80000764:	74a6                	ld	s1,104(sp)
    80000766:	6129                	addi	sp,sp,192
    80000768:	8082                	ret
    8000076a:	7906                	ld	s2,96(sp)
    8000076c:	69e6                	ld	s3,88(sp)
    8000076e:	6a46                	ld	s4,80(sp)
    80000770:	6aa6                	ld	s5,72(sp)
    80000772:	6b06                	ld	s6,64(sp)
    80000774:	7be2                	ld	s7,56(sp)
    80000776:	7c42                	ld	s8,48(sp)
    80000778:	7d02                	ld	s10,32(sp)
    8000077a:	6de2                	ld	s11,24(sp)
    8000077c:	bfe1                	j	80000754 <printk+0x25a>
    release(&pr.lock);
    8000077e:	0000f517          	auipc	a0,0xf
    80000782:	20a50513          	addi	a0,a0,522 # 8000f988 <pr>
    80000786:	51c000ef          	jal	80000ca2 <release>
  return 0;
    8000078a:	bfd1                	j	8000075e <printk+0x264>
    if (c0 == 'd') {
    8000078c:	e57a81e3          	beq	s5,s7,800005ce <printk+0xd4>
    } else if (c0 == 'l' && c1 == 'd') {
    80000790:	f94a8793          	addi	a5,s5,-108
    80000794:	0017b793          	seqz	a5,a5
    80000798:	863a                	mv	a2,a4
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    8000079a:	4681                	li	a3,0
    8000079c:	a01d                	j	800007c2 <printk+0x2c8>
    } else if (c0 == 'l' && c1 == 'd') {
    8000079e:	f94a8793          	addi	a5,s5,-108
    800007a2:	0017b793          	seqz	a5,a5
    c1 = c2 = 0;
    800007a6:	8656                	mv	a2,s5
    800007a8:	8756                	mv	a4,s5
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    800007aa:	f9460693          	addi	a3,a2,-108
    800007ae:	0016b693          	seqz	a3,a3
    800007b2:	8efd                	and	a3,a3,a5
    800007b4:	f9c70593          	addi	a1,a4,-100
    800007b8:	0015b593          	seqz	a1,a1
    800007bc:	8df5                	and	a1,a1,a3
    800007be:	e2059be3          	bnez	a1,800005f4 <printk+0xfa>
    } else if (c0 == 'u') {
    800007c2:	e58a86e3          	beq	s5,s8,8000060e <printk+0x114>
    } else if (c0 == 'l' && c1 == 'u') {
    800007c6:	f8b60593          	addi	a1,a2,-117
    800007ca:	0015b593          	seqz	a1,a1
    800007ce:	8dfd                	and	a1,a1,a5
    800007d0:	e4059ce3          	bnez	a1,80000628 <printk+0x12e>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
    800007d4:	f8b70593          	addi	a1,a4,-117
    800007d8:	0015b593          	seqz	a1,a1
    800007dc:	8df5                	and	a1,a1,a3
    800007de:	e60592e3          	bnez	a1,80000642 <printk+0x148>
    } else if (c0 == 'x') {
    800007e2:	e7aa8de3          	beq	s5,s10,8000065c <printk+0x162>
    } else if (c0 == 'l' && c1 == 'x') {
    800007e6:	f8860613          	addi	a2,a2,-120
    800007ea:	00163613          	seqz	a2,a2
    800007ee:	8e7d                	and	a2,a2,a5
    800007f0:	e80613e3          	bnez	a2,80000676 <printk+0x17c>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
    800007f4:	f8870713          	addi	a4,a4,-120
    800007f8:	00173713          	seqz	a4,a4
    800007fc:	8f75                	and	a4,a4,a3
    800007fe:	e80719e3          	bnez	a4,80000690 <printk+0x196>
    } else if (c0 == 'p') {
    80000802:	ebba83e3          	beq	s5,s11,800006a8 <printk+0x1ae>
    } else if (c0 == 'c') {
    80000806:	06300793          	li	a5,99
    8000080a:	eefa82e3          	beq	s5,a5,800006ee <printk+0x1f4>
    } else if (c0 == 's') {
    8000080e:	07300793          	li	a5,115
    80000812:	eefa88e3          	beq	s5,a5,80000702 <printk+0x208>
    } else if (c0 == '%') {
    80000816:	02500793          	li	a5,37
    8000081a:	f2fa80e3          	beq	s5,a5,8000073a <printk+0x240>
    } else if (c0 == 0) {
    8000081e:	f40a86e3          	beqz	s5,8000076a <printk+0x270>
      consputc('%');
    80000822:	02500513          	li	a0,37
    80000826:	a5dff0ef          	jal	80000282 <consputc>
      consputc(c0);
    8000082a:	8556                	mv	a0,s5
    8000082c:	a57ff0ef          	jal	80000282 <consputc>
    80000830:	bb55                	j	800005e4 <printk+0xea>

0000000080000832 <panic>:

void
panic(char *s)
{
    80000832:	1101                	addi	sp,sp,-32
    80000834:	ec06                	sd	ra,24(sp)
    80000836:	e822                	sd	s0,16(sp)
    80000838:	e426                	sd	s1,8(sp)
    8000083a:	e04a                	sd	s2,0(sp)
    8000083c:	1000                	addi	s0,sp,32
    8000083e:	892a                	mv	s2,a0
  panicking = 1;
    80000840:	4485                	li	s1,1
    80000842:	00007797          	auipc	a5,0x7
    80000846:	0697a123          	sw	s1,98(a5) # 800078a4 <panicking>
  printk("panic: ");
    8000084a:	00006517          	auipc	a0,0x6
    8000084e:	7ce50513          	addi	a0,a0,1998 # 80007018 <etext+0x18>
    80000852:	ca9ff0ef          	jal	800004fa <printk>
  printk("%s\n", s);
    80000856:	85ca                	mv	a1,s2
    80000858:	00006517          	auipc	a0,0x6
    8000085c:	7c850513          	addi	a0,a0,1992 # 80007020 <etext+0x20>
    80000860:	c9bff0ef          	jal	800004fa <printk>
  panicked = 1; // freeze uart output from other CPUs
    80000864:	00007797          	auipc	a5,0x7
    80000868:	0297ae23          	sw	s1,60(a5) # 800078a0 <panicked>
  for (;;)
    8000086c:	a001                	j	8000086c <panic+0x3a>

000000008000086e <printkinit>:
    ;
}

void
printkinit(void)
{
    8000086e:	1141                	addi	sp,sp,-16
    80000870:	e406                	sd	ra,8(sp)
    80000872:	e022                	sd	s0,0(sp)
    80000874:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    80000876:	00006597          	auipc	a1,0x6
    8000087a:	7b258593          	addi	a1,a1,1970 # 80007028 <etext+0x28>
    8000087e:	0000f517          	auipc	a0,0xf
    80000882:	10a50513          	addi	a0,a0,266 # 8000f988 <pr>
    80000886:	30a000ef          	jal	80000b90 <initlock>
}
    8000088a:	60a2                	ld	ra,8(sp)
    8000088c:	6402                	ld	s0,0(sp)
    8000088e:	0141                	addi	sp,sp,16
    80000890:	8082                	ret

0000000080000892 <uartinit>:
extern volatile int panicking; // from printk.c
extern volatile int panicked;  // from printk.c

void
uartinit(void)
{
    80000892:	1141                	addi	sp,sp,-16
    80000894:	e406                	sd	ra,8(sp)
    80000896:	e022                	sd	s0,0(sp)
    80000898:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    8000089a:	100007b7          	lui	a5,0x10000
    8000089e:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    800008a2:	10000737          	lui	a4,0x10000
    800008a6:	f8000693          	li	a3,-128
    800008aa:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    800008ae:	468d                	li	a3,3
    800008b0:	10000637          	lui	a2,0x10000
    800008b4:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    800008b8:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    800008bc:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    800008c0:	8732                	mv	a4,a2
    800008c2:	461d                	li	a2,7
    800008c4:	00c70123          	sb	a2,2(a4)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    800008c8:	00d780a3          	sb	a3,1(a5)

  initlock(&tx_lock, "uart");
    800008cc:	00006597          	auipc	a1,0x6
    800008d0:	76458593          	addi	a1,a1,1892 # 80007030 <etext+0x30>
    800008d4:	0000f517          	auipc	a0,0xf
    800008d8:	0cc50513          	addi	a0,a0,204 # 8000f9a0 <tx_lock>
    800008dc:	2b4000ef          	jal	80000b90 <initlock>
}
    800008e0:	60a2                	ld	ra,8(sp)
    800008e2:	6402                	ld	s0,0(sp)
    800008e4:	0141                	addi	sp,sp,16
    800008e6:	8082                	ret

00000000800008e8 <uartwrite>:
// interrupts, only from write() system calls.


void
uartwrite(char buf[], int n)
{
    800008e8:	715d                	addi	sp,sp,-80
    800008ea:	e486                	sd	ra,72(sp)
    800008ec:	e0a2                	sd	s0,64(sp)
    800008ee:	fc26                	sd	s1,56(sp)
    800008f0:	ec56                	sd	s5,24(sp)
    800008f2:	0880                	addi	s0,sp,80
    800008f4:	8aaa                	mv	s5,a0
    800008f6:	84ae                	mv	s1,a1
  acquire(&tx_lock);
    800008f8:	0000f517          	auipc	a0,0xf
    800008fc:	0a850513          	addi	a0,a0,168 # 8000f9a0 <tx_lock>
    80000900:	310000ef          	jal	80000c10 <acquire>

  int i = 0;
  while (i < n) {
    80000904:	06905063          	blez	s1,80000964 <uartwrite+0x7c>
    80000908:	f84a                	sd	s2,48(sp)
    8000090a:	f44e                	sd	s3,40(sp)
    8000090c:	f052                	sd	s4,32(sp)
    8000090e:	e85a                	sd	s6,16(sp)
    80000910:	e45e                	sd	s7,8(sp)
    80000912:	8a56                	mv	s4,s5
    80000914:	9aa6                	add	s5,s5,s1
    while(tx_busy != 0){
    80000916:	00007497          	auipc	s1,0x7
    8000091a:	f9648493          	addi	s1,s1,-106 # 800078ac <tx_busy>
      // Standard xv6: Pass the tx_lock directly into sleep.
      // Do NOT call sleep_prepare.
      sleep(&tx_chan, &tx_lock); 
    8000091e:	0000f997          	auipc	s3,0xf
    80000922:	08298993          	addi	s3,s3,130 # 8000f9a0 <tx_lock>
    80000926:	00007917          	auipc	s2,0x7
    8000092a:	f8290913          	addi	s2,s2,-126 # 800078a8 <tx_chan>
    }
    WriteReg(THR, buf[i]);
    8000092e:	10000bb7          	lui	s7,0x10000
    i += 1;
    tx_busy = 1;
    80000932:	4b05                	li	s6,1
    80000934:	a005                	j	80000954 <uartwrite+0x6c>
      sleep(&tx_chan, &tx_lock); 
    80000936:	85ce                	mv	a1,s3
    80000938:	854a                	mv	a0,s2
    8000093a:	6a6010ef          	jal	80001fe0 <sleep>
    while(tx_busy != 0){
    8000093e:	409c                	lw	a5,0(s1)
    80000940:	fbfd                	bnez	a5,80000936 <uartwrite+0x4e>
    WriteReg(THR, buf[i]);
    80000942:	000a4783          	lbu	a5,0(s4)
    80000946:	00fb8023          	sb	a5,0(s7) # 10000000 <_entry-0x70000000>
    tx_busy = 1;
    8000094a:	0164a023          	sw	s6,0(s1)
  while (i < n) {
    8000094e:	0a05                	addi	s4,s4,1
    80000950:	015a0563          	beq	s4,s5,8000095a <uartwrite+0x72>
    while(tx_busy != 0){
    80000954:	409c                	lw	a5,0(s1)
    80000956:	f3e5                	bnez	a5,80000936 <uartwrite+0x4e>
    80000958:	b7ed                	j	80000942 <uartwrite+0x5a>
    8000095a:	7942                	ld	s2,48(sp)
    8000095c:	79a2                	ld	s3,40(sp)
    8000095e:	7a02                	ld	s4,32(sp)
    80000960:	6b42                	ld	s6,16(sp)
    80000962:	6ba2                	ld	s7,8(sp)
  }

  release(&tx_lock);
    80000964:	0000f517          	auipc	a0,0xf
    80000968:	03c50513          	addi	a0,a0,60 # 8000f9a0 <tx_lock>
    8000096c:	336000ef          	jal	80000ca2 <release>
}
    80000970:	60a6                	ld	ra,72(sp)
    80000972:	6406                	ld	s0,64(sp)
    80000974:	74e2                	ld	s1,56(sp)
    80000976:	6ae2                	ld	s5,24(sp)
    80000978:	6161                	addi	sp,sp,80
    8000097a:	8082                	ret

000000008000097c <uartputc_sync>:
// interrupts, for use by kernel printk() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    8000097c:	1101                	addi	sp,sp,-32
    8000097e:	ec06                	sd	ra,24(sp)
    80000980:	e822                	sd	s0,16(sp)
    80000982:	e426                	sd	s1,8(sp)
    80000984:	1000                	addi	s0,sp,32
    80000986:	84aa                	mv	s1,a0
  if (panicking == 0)
    80000988:	00007797          	auipc	a5,0x7
    8000098c:	f1c7a783          	lw	a5,-228(a5) # 800078a4 <panicking>
    80000990:	cb91                	beqz	a5,800009a4 <uartputc_sync+0x28>
    push_off();

  if (panicked) {
    80000992:	00007797          	auipc	a5,0x7
    80000996:	f0e7a783          	lw	a5,-242(a5) # 800078a0 <panicked>
    for (;;)
      ;
  }

  // wait for UART to set Transmit Holding Empty in LSR.
  while ((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    8000099a:	10000737          	lui	a4,0x10000
    8000099e:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
  if (panicked) {
    800009a0:	c789                	beqz	a5,800009aa <uartputc_sync+0x2e>
    for (;;)
    800009a2:	a001                	j	800009a2 <uartputc_sync+0x26>
    push_off();
    800009a4:	232000ef          	jal	80000bd6 <push_off>
    800009a8:	b7ed                	j	80000992 <uartputc_sync+0x16>
  while ((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    800009aa:	00074783          	lbu	a5,0(a4)
    800009ae:	0207f793          	andi	a5,a5,32
    800009b2:	dfe5                	beqz	a5,800009aa <uartputc_sync+0x2e>
    ;
  WriteReg(THR, c);
    800009b4:	100007b7          	lui	a5,0x10000
    800009b8:	00978023          	sb	s1,0(a5) # 10000000 <_entry-0x70000000>

  if (panicking == 0)
    800009bc:	00007797          	auipc	a5,0x7
    800009c0:	ee87a783          	lw	a5,-280(a5) # 800078a4 <panicking>
    800009c4:	c791                	beqz	a5,800009d0 <uartputc_sync+0x54>
    pop_off();
}
    800009c6:	60e2                	ld	ra,24(sp)
    800009c8:	6442                	ld	s0,16(sp)
    800009ca:	64a2                	ld	s1,8(sp)
    800009cc:	6105                	addi	sp,sp,32
    800009ce:	8082                	ret
    pop_off();
    800009d0:	28a000ef          	jal	80000c5a <pop_off>
}
    800009d4:	bfcd                	j	800009c6 <uartputc_sync+0x4a>

00000000800009d6 <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    800009d6:	1101                	addi	sp,sp,-32
    800009d8:	ec06                	sd	ra,24(sp)
    800009da:	e822                	sd	s0,16(sp)
    800009dc:	e426                	sd	s1,8(sp)
    800009de:	e04a                	sd	s2,0(sp)
    800009e0:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    800009e2:	100007b7          	lui	a5,0x10000
    800009e6:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>

  acquire(&tx_lock);
    800009ea:	0000f517          	auipc	a0,0xf
    800009ee:	fb650513          	addi	a0,a0,-74 # 8000f9a0 <tx_lock>
    800009f2:	21e000ef          	jal	80000c10 <acquire>
  if (ReadReg(LSR) & LSR_TX_IDLE) {
    800009f6:	100007b7          	lui	a5,0x10000
    800009fa:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    800009fe:	0207f793          	andi	a5,a5,32
    80000a02:	e78d                	bnez	a5,80000a2c <uartintr+0x56>
    // UART finished transmitting; wake up sending thread.
    tx_busy = 0;
    wakeup(&tx_chan);
  }
  release(&tx_lock);
    80000a04:	0000f517          	auipc	a0,0xf
    80000a08:	f9c50513          	addi	a0,a0,-100 # 8000f9a0 <tx_lock>
    80000a0c:	296000ef          	jal	80000ca2 <release>
  if (ReadReg(LSR) & LSR_RX_READY) {
    80000a10:	100004b7          	lui	s1,0x10000
    80000a14:	0495                	addi	s1,s1,5 # 10000005 <_entry-0x6ffffffb>
    return ReadReg(RHR);
    80000a16:	10000937          	lui	s2,0x10000
  if (ReadReg(LSR) & LSR_RX_READY) {
    80000a1a:	0004c783          	lbu	a5,0(s1)
    80000a1e:	8b85                	andi	a5,a5,1
    80000a20:	c38d                	beqz	a5,80000a42 <uartintr+0x6c>
  // read and process incoming characters, if any.
  while (1) {
    int c = uartgetc();
    if (c == -1)
      break;
    consoleintr(c);
    80000a22:	00094503          	lbu	a0,0(s2) # 10000000 <_entry-0x70000000>
    80000a26:	881ff0ef          	jal	800002a6 <consoleintr>
  while (1) {
    80000a2a:	bfc5                	j	80000a1a <uartintr+0x44>
    tx_busy = 0;
    80000a2c:	00007797          	auipc	a5,0x7
    80000a30:	e807a023          	sw	zero,-384(a5) # 800078ac <tx_busy>
    wakeup(&tx_chan);
    80000a34:	00007517          	auipc	a0,0x7
    80000a38:	e7450513          	addi	a0,a0,-396 # 800078a8 <tx_chan>
    80000a3c:	5f0010ef          	jal	8000202c <wakeup>
    80000a40:	b7d1                	j	80000a04 <uartintr+0x2e>
  }
}
    80000a42:	60e2                	ld	ra,24(sp)
    80000a44:	6442                	ld	s0,16(sp)
    80000a46:	64a2                	ld	s1,8(sp)
    80000a48:	6902                	ld	s2,0(sp)
    80000a4a:	6105                	addi	sp,sp,32
    80000a4c:	8082                	ret

0000000080000a4e <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    80000a4e:	1101                	addi	sp,sp,-32
    80000a50:	ec06                	sd	ra,24(sp)
    80000a52:	e822                	sd	s0,16(sp)
    80000a54:	e426                	sd	s1,8(sp)
    80000a56:	e04a                	sd	s2,0(sp)
    80000a58:	1000                	addi	s0,sp,32
  struct run *r;

  if (((uint64)pa % PGSIZE) != 0 || (char *)pa < end || (uint64)pa >= PHYSTOP)
    80000a5a:	00020797          	auipc	a5,0x20
    80000a5e:	38e78793          	addi	a5,a5,910 # 80020de8 <end>
    80000a62:	00f53733          	sltu	a4,a0,a5
    80000a66:	47c5                	li	a5,17
    80000a68:	07ee                	slli	a5,a5,0x1b
    80000a6a:	17fd                	addi	a5,a5,-1
    80000a6c:	00a7b7b3          	sltu	a5,a5,a0
    80000a70:	8fd9                	or	a5,a5,a4
    80000a72:	03451713          	slli	a4,a0,0x34
    80000a76:	8fd9                	or	a5,a5,a4
    80000a78:	eb9d                	bnez	a5,80000aae <kfree+0x60>
    80000a7a:	84aa                	mv	s1,a0
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000a7c:	6605                	lui	a2,0x1
    80000a7e:	4585                	li	a1,1
    80000a80:	268000ef          	jal	80000ce8 <memset>

  r = (struct run *)pa;

  acquire(&kmem.lock);
    80000a84:	0000f917          	auipc	s2,0xf
    80000a88:	f3490913          	addi	s2,s2,-204 # 8000f9b8 <kmem>
    80000a8c:	854a                	mv	a0,s2
    80000a8e:	182000ef          	jal	80000c10 <acquire>
  r->next = kmem.freelist;
    80000a92:	01893783          	ld	a5,24(s2)
    80000a96:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000a98:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000a9c:	854a                	mv	a0,s2
    80000a9e:	204000ef          	jal	80000ca2 <release>
}
    80000aa2:	60e2                	ld	ra,24(sp)
    80000aa4:	6442                	ld	s0,16(sp)
    80000aa6:	64a2                	ld	s1,8(sp)
    80000aa8:	6902                	ld	s2,0(sp)
    80000aaa:	6105                	addi	sp,sp,32
    80000aac:	8082                	ret
    panic("kfree");
    80000aae:	00006517          	auipc	a0,0x6
    80000ab2:	58a50513          	addi	a0,a0,1418 # 80007038 <etext+0x38>
    80000ab6:	d7dff0ef          	jal	80000832 <panic>

0000000080000aba <freerange>:
{
    80000aba:	7179                	addi	sp,sp,-48
    80000abc:	f406                	sd	ra,40(sp)
    80000abe:	f022                	sd	s0,32(sp)
    80000ac0:	ec26                	sd	s1,24(sp)
    80000ac2:	1800                	addi	s0,sp,48
  p = (char *)PGROUNDUP((uint64)pa_start);
    80000ac4:	6785                	lui	a5,0x1
    80000ac6:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000aca:	00e504b3          	add	s1,a0,a4
    80000ace:	777d                	lui	a4,0xfffff
    80000ad0:	8cf9                	and	s1,s1,a4
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000ad2:	94be                	add	s1,s1,a5
    80000ad4:	0295e263          	bltu	a1,s1,80000af8 <freerange+0x3e>
    80000ad8:	e84a                	sd	s2,16(sp)
    80000ada:	e44e                	sd	s3,8(sp)
    80000adc:	e052                	sd	s4,0(sp)
    80000ade:	892e                	mv	s2,a1
    kfree(p);
    80000ae0:	8a3a                	mv	s4,a4
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000ae2:	89be                	mv	s3,a5
    kfree(p);
    80000ae4:	01448533          	add	a0,s1,s4
    80000ae8:	f67ff0ef          	jal	80000a4e <kfree>
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000aec:	94ce                	add	s1,s1,s3
    80000aee:	fe997be3          	bgeu	s2,s1,80000ae4 <freerange+0x2a>
    80000af2:	6942                	ld	s2,16(sp)
    80000af4:	69a2                	ld	s3,8(sp)
    80000af6:	6a02                	ld	s4,0(sp)
}
    80000af8:	70a2                	ld	ra,40(sp)
    80000afa:	7402                	ld	s0,32(sp)
    80000afc:	64e2                	ld	s1,24(sp)
    80000afe:	6145                	addi	sp,sp,48
    80000b00:	8082                	ret

0000000080000b02 <kinit>:
{
    80000b02:	1141                	addi	sp,sp,-16
    80000b04:	e406                	sd	ra,8(sp)
    80000b06:	e022                	sd	s0,0(sp)
    80000b08:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000b0a:	00006597          	auipc	a1,0x6
    80000b0e:	53658593          	addi	a1,a1,1334 # 80007040 <etext+0x40>
    80000b12:	0000f517          	auipc	a0,0xf
    80000b16:	ea650513          	addi	a0,a0,-346 # 8000f9b8 <kmem>
    80000b1a:	076000ef          	jal	80000b90 <initlock>
  freerange(end, (void *)PHYSTOP);
    80000b1e:	45c5                	li	a1,17
    80000b20:	05ee                	slli	a1,a1,0x1b
    80000b22:	00020517          	auipc	a0,0x20
    80000b26:	2c650513          	addi	a0,a0,710 # 80020de8 <end>
    80000b2a:	f91ff0ef          	jal	80000aba <freerange>
}
    80000b2e:	60a2                	ld	ra,8(sp)
    80000b30:	6402                	ld	s0,0(sp)
    80000b32:	0141                	addi	sp,sp,16
    80000b34:	8082                	ret

0000000080000b36 <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000b36:	1101                	addi	sp,sp,-32
    80000b38:	ec06                	sd	ra,24(sp)
    80000b3a:	e822                	sd	s0,16(sp)
    80000b3c:	e426                	sd	s1,8(sp)
    80000b3e:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000b40:	0000f517          	auipc	a0,0xf
    80000b44:	e7850513          	addi	a0,a0,-392 # 8000f9b8 <kmem>
    80000b48:	0c8000ef          	jal	80000c10 <acquire>
  r = kmem.freelist;
    80000b4c:	0000f497          	auipc	s1,0xf
    80000b50:	e844b483          	ld	s1,-380(s1) # 8000f9d0 <kmem+0x18>
  if (r)
    80000b54:	c49d                	beqz	s1,80000b82 <kalloc+0x4c>
    kmem.freelist = r->next;
    80000b56:	609c                	ld	a5,0(s1)
    80000b58:	0000f717          	auipc	a4,0xf
    80000b5c:	e6f73c23          	sd	a5,-392(a4) # 8000f9d0 <kmem+0x18>
  release(&kmem.lock);
    80000b60:	0000f517          	auipc	a0,0xf
    80000b64:	e5850513          	addi	a0,a0,-424 # 8000f9b8 <kmem>
    80000b68:	13a000ef          	jal	80000ca2 <release>

  if (r)
    memset((char *)r, 5, PGSIZE); // fill with junk
    80000b6c:	6605                	lui	a2,0x1
    80000b6e:	4595                	li	a1,5
    80000b70:	8526                	mv	a0,s1
    80000b72:	176000ef          	jal	80000ce8 <memset>
  return (void *)r;
}
    80000b76:	8526                	mv	a0,s1
    80000b78:	60e2                	ld	ra,24(sp)
    80000b7a:	6442                	ld	s0,16(sp)
    80000b7c:	64a2                	ld	s1,8(sp)
    80000b7e:	6105                	addi	sp,sp,32
    80000b80:	8082                	ret
  release(&kmem.lock);
    80000b82:	0000f517          	auipc	a0,0xf
    80000b86:	e3650513          	addi	a0,a0,-458 # 8000f9b8 <kmem>
    80000b8a:	118000ef          	jal	80000ca2 <release>
  if (r)
    80000b8e:	b7e5                	j	80000b76 <kalloc+0x40>

0000000080000b90 <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000b90:	1141                	addi	sp,sp,-16
    80000b92:	e406                	sd	ra,8(sp)
    80000b94:	e022                	sd	s0,0(sp)
    80000b96:	0800                	addi	s0,sp,16
  lk->name = name;
    80000b98:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000b9a:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000b9e:	00053823          	sd	zero,16(a0)
}
    80000ba2:	60a2                	ld	ra,8(sp)
    80000ba4:	6402                	ld	s0,0(sp)
    80000ba6:	0141                	addi	sp,sp,16
    80000ba8:	8082                	ret

0000000080000baa <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000baa:	411c                	lw	a5,0(a0)
    80000bac:	e399                	bnez	a5,80000bb2 <holding+0x8>
    80000bae:	4501                	li	a0,0
  return r;
}
    80000bb0:	8082                	ret
{
    80000bb2:	1101                	addi	sp,sp,-32
    80000bb4:	ec06                	sd	ra,24(sp)
    80000bb6:	e822                	sd	s0,16(sp)
    80000bb8:	e426                	sd	s1,8(sp)
    80000bba:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000bbc:	691c                	ld	a5,16(a0)
    80000bbe:	84be                	mv	s1,a5
    80000bc0:	537000ef          	jal	800018f6 <mycpu>
    80000bc4:	40a48533          	sub	a0,s1,a0
    80000bc8:	00153513          	seqz	a0,a0
}
    80000bcc:	60e2                	ld	ra,24(sp)
    80000bce:	6442                	ld	s0,16(sp)
    80000bd0:	64a2                	ld	s1,8(sp)
    80000bd2:	6105                	addi	sp,sp,32
    80000bd4:	8082                	ret

0000000080000bd6 <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000bd6:	1101                	addi	sp,sp,-32
    80000bd8:	ec06                	sd	ra,24(sp)
    80000bda:	e822                	sd	s0,16(sp)
    80000bdc:	e426                	sd	s1,8(sp)
    80000bde:	1000                	addi	s0,sp,32
  __asm__ __volatile__("csrrc %0, sstatus, %1" : "=r"(x) : "rK"(x) : "memory");
    80000be0:	100177f3          	csrrci	a5,sstatus,2
    80000be4:	84be                	mv	s1,a5
  // disable interrupts to prevent an involuntary context
  // switch while using mycpu().
  uint64 flags = rc_sstatus(SSTATUS_SIE);
  int old = !!(flags & SSTATUS_SIE);

  if (mycpu()->noff == 0)
    80000be6:	511000ef          	jal	800018f6 <mycpu>
    80000bea:	5d3c                	lw	a5,120(a0)
    80000bec:	cb99                	beqz	a5,80000c02 <push_off+0x2c>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000bee:	509000ef          	jal	800018f6 <mycpu>
    80000bf2:	5d3c                	lw	a5,120(a0)
    80000bf4:	2785                	addiw	a5,a5,1
    80000bf6:	dd3c                	sw	a5,120(a0)
}
    80000bf8:	60e2                	ld	ra,24(sp)
    80000bfa:	6442                	ld	s0,16(sp)
    80000bfc:	64a2                	ld	s1,8(sp)
    80000bfe:	6105                	addi	sp,sp,32
    80000c00:	8082                	ret
    mycpu()->intena = old;
    80000c02:	4f5000ef          	jal	800018f6 <mycpu>
  int old = !!(flags & SSTATUS_SIE);
    80000c06:	0014d793          	srli	a5,s1,0x1
    80000c0a:	8b85                	andi	a5,a5,1
    mycpu()->intena = old;
    80000c0c:	dd7c                	sw	a5,124(a0)
    80000c0e:	b7c5                	j	80000bee <push_off+0x18>

0000000080000c10 <acquire>:
{
    80000c10:	1101                	addi	sp,sp,-32
    80000c12:	ec06                	sd	ra,24(sp)
    80000c14:	e822                	sd	s0,16(sp)
    80000c16:	e426                	sd	s1,8(sp)
    80000c18:	1000                	addi	s0,sp,32
    80000c1a:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000c1c:	fbbff0ef          	jal	80000bd6 <push_off>
  if (holding(lk)) {
    80000c20:	8526                	mv	a0,s1
    80000c22:	f89ff0ef          	jal	80000baa <holding>
  while (__atomic_exchange_n(&lk->locked, 1, __ATOMIC_ACQUIRE) != 0)
    80000c26:	4705                	li	a4,1
  if (holding(lk)) {
    80000c28:	ed01                	bnez	a0,80000c40 <acquire+0x30>
  while (__atomic_exchange_n(&lk->locked, 1, __ATOMIC_ACQUIRE) != 0)
    80000c2a:	0ce4a7af          	amoswap.w.aq	a5,a4,(s1)
    80000c2e:	fff5                	bnez	a5,80000c2a <acquire+0x1a>
  lk->cpu = mycpu();
    80000c30:	4c7000ef          	jal	800018f6 <mycpu>
    80000c34:	e888                	sd	a0,16(s1)
}
    80000c36:	60e2                	ld	ra,24(sp)
    80000c38:	6442                	ld	s0,16(sp)
    80000c3a:	64a2                	ld	s1,8(sp)
    80000c3c:	6105                	addi	sp,sp,32
    80000c3e:	8082                	ret
    printk("panic: acquire - lock name: %s\n", lk->name);
    80000c40:	648c                	ld	a1,8(s1)
    80000c42:	00006517          	auipc	a0,0x6
    80000c46:	40650513          	addi	a0,a0,1030 # 80007048 <etext+0x48>
    80000c4a:	8b1ff0ef          	jal	800004fa <printk>
    panic("acquire");
    80000c4e:	00006517          	auipc	a0,0x6
    80000c52:	41a50513          	addi	a0,a0,1050 # 80007068 <etext+0x68>
    80000c56:	bddff0ef          	jal	80000832 <panic>

0000000080000c5a <pop_off>:

void
pop_off(void)
{
    80000c5a:	1141                	addi	sp,sp,-16
    80000c5c:	e406                	sd	ra,8(sp)
    80000c5e:	e022                	sd	s0,0(sp)
    80000c60:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000c62:	495000ef          	jal	800018f6 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80000c66:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000c6a:	8b89                	andi	a5,a5,2
  if (intr_get())
    80000c6c:	ef99                	bnez	a5,80000c8a <pop_off+0x30>
    panic("pop_off - interruptible");
  if (c->noff < 1)
    80000c6e:	5d3c                	lw	a5,120(a0)
    80000c70:	02f05363          	blez	a5,80000c96 <pop_off+0x3c>
    panic("pop_off");
  c->noff -= 1;
    80000c74:	37fd                	addiw	a5,a5,-1
    80000c76:	dd3c                	sw	a5,120(a0)
  if (c->noff == 0 && c->intena)
    80000c78:	e789                	bnez	a5,80000c82 <pop_off+0x28>
    80000c7a:	5d7c                	lw	a5,124(a0)
    80000c7c:	c399                	beqz	a5,80000c82 <pop_off+0x28>
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    80000c7e:	10016073          	csrsi	sstatus,2
    intr_on();
}
    80000c82:	60a2                	ld	ra,8(sp)
    80000c84:	6402                	ld	s0,0(sp)
    80000c86:	0141                	addi	sp,sp,16
    80000c88:	8082                	ret
    panic("pop_off - interruptible");
    80000c8a:	00006517          	auipc	a0,0x6
    80000c8e:	3e650513          	addi	a0,a0,998 # 80007070 <etext+0x70>
    80000c92:	ba1ff0ef          	jal	80000832 <panic>
    panic("pop_off");
    80000c96:	00006517          	auipc	a0,0x6
    80000c9a:	3f250513          	addi	a0,a0,1010 # 80007088 <etext+0x88>
    80000c9e:	b95ff0ef          	jal	80000832 <panic>

0000000080000ca2 <release>:
{
    80000ca2:	1101                	addi	sp,sp,-32
    80000ca4:	ec06                	sd	ra,24(sp)
    80000ca6:	e822                	sd	s0,16(sp)
    80000ca8:	e426                	sd	s1,8(sp)
    80000caa:	1000                	addi	s0,sp,32
    80000cac:	84aa                	mv	s1,a0
  if (!holding(lk)) {
    80000cae:	efdff0ef          	jal	80000baa <holding>
    80000cb2:	cd11                	beqz	a0,80000cce <release+0x2c>
  lk->cpu = 0;
    80000cb4:	0004b823          	sd	zero,16(s1)
  __atomic_store_n(&lk->locked, 0, __ATOMIC_RELEASE);
    80000cb8:	0310000f          	fence	rw,w
    80000cbc:	0004a023          	sw	zero,0(s1)
  pop_off();
    80000cc0:	f9bff0ef          	jal	80000c5a <pop_off>
}
    80000cc4:	60e2                	ld	ra,24(sp)
    80000cc6:	6442                	ld	s0,16(sp)
    80000cc8:	64a2                	ld	s1,8(sp)
    80000cca:	6105                	addi	sp,sp,32
    80000ccc:	8082                	ret
    printk("panic: release - lock name: %s\n", lk->name);
    80000cce:	648c                	ld	a1,8(s1)
    80000cd0:	00006517          	auipc	a0,0x6
    80000cd4:	3c050513          	addi	a0,a0,960 # 80007090 <etext+0x90>
    80000cd8:	823ff0ef          	jal	800004fa <printk>
    panic("release");
    80000cdc:	00006517          	auipc	a0,0x6
    80000ce0:	3d450513          	addi	a0,a0,980 # 800070b0 <etext+0xb0>
    80000ce4:	b4fff0ef          	jal	80000832 <panic>

0000000080000ce8 <memset>:
#include "types.h"

void *
memset(void *dst, int c, uint n)
{
    80000ce8:	1141                	addi	sp,sp,-16
    80000cea:	e406                	sd	ra,8(sp)
    80000cec:	e022                	sd	s0,0(sp)
    80000cee:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
    80000cf0:	ca19                	beqz	a2,80000d06 <memset+0x1e>
    80000cf2:	87aa                	mv	a5,a0
    80000cf4:	1602                	slli	a2,a2,0x20
    80000cf6:	9201                	srli	a2,a2,0x20
    80000cf8:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000cfc:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
    80000d00:	0785                	addi	a5,a5,1
    80000d02:	fee79de3          	bne	a5,a4,80000cfc <memset+0x14>
  }
  return dst;
}
    80000d06:	60a2                	ld	ra,8(sp)
    80000d08:	6402                	ld	s0,0(sp)
    80000d0a:	0141                	addi	sp,sp,16
    80000d0c:	8082                	ret

0000000080000d0e <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000d0e:	1141                	addi	sp,sp,-16
    80000d10:	e406                	sd	ra,8(sp)
    80000d12:	e022                	sd	s0,0(sp)
    80000d14:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while (n-- > 0) {
    80000d16:	ce19                	beqz	a2,80000d34 <memcmp+0x26>
    80000d18:	1602                	slli	a2,a2,0x20
    80000d1a:	9201                	srli	a2,a2,0x20
    80000d1c:	00c506b3          	add	a3,a0,a2
    if (*s1 != *s2)
    80000d20:	00054783          	lbu	a5,0(a0)
    80000d24:	0005c703          	lbu	a4,0(a1)
    80000d28:	00e79b63          	bne	a5,a4,80000d3e <memcmp+0x30>
      return *s1 - *s2;
    s1++, s2++;
    80000d2c:	0505                	addi	a0,a0,1
    80000d2e:	0585                	addi	a1,a1,1
  while (n-- > 0) {
    80000d30:	fed518e3          	bne	a0,a3,80000d20 <memcmp+0x12>
  }

  return 0;
    80000d34:	4501                	li	a0,0
}
    80000d36:	60a2                	ld	ra,8(sp)
    80000d38:	6402                	ld	s0,0(sp)
    80000d3a:	0141                	addi	sp,sp,16
    80000d3c:	8082                	ret
      return *s1 - *s2;
    80000d3e:	40e7853b          	subw	a0,a5,a4
    80000d42:	bfd5                	j	80000d36 <memcmp+0x28>

0000000080000d44 <memmove>:

void *
memmove(void *dst, const void *src, uint n)
{
    80000d44:	1141                	addi	sp,sp,-16
    80000d46:	e406                	sd	ra,8(sp)
    80000d48:	e022                	sd	s0,0(sp)
    80000d4a:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if (n == 0)
    80000d4c:	c61d                	beqz	a2,80000d7a <memmove+0x36>
    return dst;

  s = src;
  d = dst;
  if (s < d && s + n > d) {
    80000d4e:	00a5f963          	bgeu	a1,a0,80000d60 <memmove+0x1c>
    80000d52:	02061693          	slli	a3,a2,0x20
    80000d56:	9281                	srli	a3,a3,0x20
    80000d58:	00d58733          	add	a4,a1,a3
    80000d5c:	02e56363          	bltu	a0,a4,80000d82 <memmove+0x3e>
    s += n;
    d += n;
    while (n-- > 0)
      *--d = *--s;
  } else
    while (n-- > 0)
    80000d60:	1602                	slli	a2,a2,0x20
    80000d62:	9201                	srli	a2,a2,0x20
    80000d64:	00c587b3          	add	a5,a1,a2
{
    80000d68:	872a                	mv	a4,a0
      *d++ = *s++;
    80000d6a:	0585                	addi	a1,a1,1
    80000d6c:	0705                	addi	a4,a4,1
    80000d6e:	fff5c683          	lbu	a3,-1(a1)
    80000d72:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
    80000d76:	fef59ae3          	bne	a1,a5,80000d6a <memmove+0x26>

  return dst;
}
    80000d7a:	60a2                	ld	ra,8(sp)
    80000d7c:	6402                	ld	s0,0(sp)
    80000d7e:	0141                	addi	sp,sp,16
    80000d80:	8082                	ret
    d += n;
    80000d82:	96aa                	add	a3,a3,a0
    while (n-- > 0)
    80000d84:	fff6079b          	addiw	a5,a2,-1 # fff <_entry-0x7ffff001>
    80000d88:	1782                	slli	a5,a5,0x20
    80000d8a:	9381                	srli	a5,a5,0x20
    80000d8c:	fff7c793          	not	a5,a5
    80000d90:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000d92:	177d                	addi	a4,a4,-1
    80000d94:	16fd                	addi	a3,a3,-1
    80000d96:	00074603          	lbu	a2,0(a4)
    80000d9a:	00c68023          	sb	a2,0(a3)
    while (n-- > 0)
    80000d9e:	fee79ae3          	bne	a5,a4,80000d92 <memmove+0x4e>
    80000da2:	bfe1                	j	80000d7a <memmove+0x36>

0000000080000da4 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void *
memcpy(void *dst, const void *src, uint n)
{
    80000da4:	1141                	addi	sp,sp,-16
    80000da6:	e406                	sd	ra,8(sp)
    80000da8:	e022                	sd	s0,0(sp)
    80000daa:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000dac:	f99ff0ef          	jal	80000d44 <memmove>
}
    80000db0:	60a2                	ld	ra,8(sp)
    80000db2:	6402                	ld	s0,0(sp)
    80000db4:	0141                	addi	sp,sp,16
    80000db6:	8082                	ret

0000000080000db8 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000db8:	1141                	addi	sp,sp,-16
    80000dba:	e406                	sd	ra,8(sp)
    80000dbc:	e022                	sd	s0,0(sp)
    80000dbe:	0800                	addi	s0,sp,16
  while (n > 0 && *p && *p == *q)
    80000dc0:	ce01                	beqz	a2,80000dd8 <strncmp+0x20>
    80000dc2:	00054783          	lbu	a5,0(a0)
    80000dc6:	cb99                	beqz	a5,80000ddc <strncmp+0x24>
    80000dc8:	0005c703          	lbu	a4,0(a1)
    80000dcc:	00f71863          	bne	a4,a5,80000ddc <strncmp+0x24>
    n--, p++, q++;
    80000dd0:	367d                	addiw	a2,a2,-1
    80000dd2:	0505                	addi	a0,a0,1
    80000dd4:	0585                	addi	a1,a1,1
  while (n > 0 && *p && *p == *q)
    80000dd6:	f675                	bnez	a2,80000dc2 <strncmp+0xa>
  if (n == 0)
    return 0;
    80000dd8:	4501                	li	a0,0
    80000dda:	a031                	j	80000de6 <strncmp+0x2e>
  return (uchar)*p - (uchar)*q;
    80000ddc:	00054503          	lbu	a0,0(a0)
    80000de0:	0005c783          	lbu	a5,0(a1)
    80000de4:	9d1d                	subw	a0,a0,a5
}
    80000de6:	60a2                	ld	ra,8(sp)
    80000de8:	6402                	ld	s0,0(sp)
    80000dea:	0141                	addi	sp,sp,16
    80000dec:	8082                	ret

0000000080000dee <strncpy>:

char *
strncpy(char *s, const char *t, int n)
{
    80000dee:	1141                	addi	sp,sp,-16
    80000df0:	e406                	sd	ra,8(sp)
    80000df2:	e022                	sd	s0,0(sp)
    80000df4:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while (n-- > 0 && (*s++ = *t++) != 0)
    80000df6:	87aa                	mv	a5,a0
    80000df8:	a011                	j	80000dfc <strncpy+0xe>
    80000dfa:	8636                	mv	a2,a3
    80000dfc:	02c05763          	blez	a2,80000e2a <strncpy+0x3c>
    80000e00:	fff6069b          	addiw	a3,a2,-1
    80000e04:	0785                	addi	a5,a5,1
    80000e06:	0005c703          	lbu	a4,0(a1)
    80000e0a:	fee78fa3          	sb	a4,-1(a5)
    80000e0e:	0585                	addi	a1,a1,1
    80000e10:	f76d                	bnez	a4,80000dfa <strncpy+0xc>
    ;
  while (n-- > 0)
    80000e12:	873e                	mv	a4,a5
    80000e14:	00d05b63          	blez	a3,80000e2a <strncpy+0x3c>
    80000e18:	9fb1                	addw	a5,a5,a2
    80000e1a:	37fd                	addiw	a5,a5,-1
    *s++ = 0;
    80000e1c:	0705                	addi	a4,a4,1
    80000e1e:	fe070fa3          	sb	zero,-1(a4)
  while (n-- > 0)
    80000e22:	40e786bb          	subw	a3,a5,a4
    80000e26:	fed04be3          	bgtz	a3,80000e1c <strncpy+0x2e>
  return os;
}
    80000e2a:	60a2                	ld	ra,8(sp)
    80000e2c:	6402                	ld	s0,0(sp)
    80000e2e:	0141                	addi	sp,sp,16
    80000e30:	8082                	ret

0000000080000e32 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char *
safestrcpy(char *s, const char *t, int n)
{
    80000e32:	1141                	addi	sp,sp,-16
    80000e34:	e406                	sd	ra,8(sp)
    80000e36:	e022                	sd	s0,0(sp)
    80000e38:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if (n <= 0)
    80000e3a:	02c05363          	blez	a2,80000e60 <safestrcpy+0x2e>
    80000e3e:	fff6069b          	addiw	a3,a2,-1
    80000e42:	1682                	slli	a3,a3,0x20
    80000e44:	9281                	srli	a3,a3,0x20
    80000e46:	96ae                	add	a3,a3,a1
    80000e48:	87aa                	mv	a5,a0
    return os;
  while (--n > 0 && (*s++ = *t++) != 0)
    80000e4a:	00d58963          	beq	a1,a3,80000e5c <safestrcpy+0x2a>
    80000e4e:	0585                	addi	a1,a1,1
    80000e50:	0785                	addi	a5,a5,1
    80000e52:	fff5c703          	lbu	a4,-1(a1)
    80000e56:	fee78fa3          	sb	a4,-1(a5)
    80000e5a:	fb65                	bnez	a4,80000e4a <safestrcpy+0x18>
    ;
  *s = 0;
    80000e5c:	00078023          	sb	zero,0(a5)
  return os;
}
    80000e60:	60a2                	ld	ra,8(sp)
    80000e62:	6402                	ld	s0,0(sp)
    80000e64:	0141                	addi	sp,sp,16
    80000e66:	8082                	ret

0000000080000e68 <strlen>:

int
strlen(const char *s)
{
    80000e68:	1141                	addi	sp,sp,-16
    80000e6a:	e406                	sd	ra,8(sp)
    80000e6c:	e022                	sd	s0,0(sp)
    80000e6e:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
    80000e70:	00054783          	lbu	a5,0(a0)
    80000e74:	cf91                	beqz	a5,80000e90 <strlen+0x28>
    80000e76:	00150793          	addi	a5,a0,1
    80000e7a:	86be                	mv	a3,a5
    80000e7c:	0785                	addi	a5,a5,1
    80000e7e:	fff7c703          	lbu	a4,-1(a5)
    80000e82:	ff65                	bnez	a4,80000e7a <strlen+0x12>
    80000e84:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
    80000e88:	60a2                	ld	ra,8(sp)
    80000e8a:	6402                	ld	s0,0(sp)
    80000e8c:	0141                	addi	sp,sp,16
    80000e8e:	8082                	ret
  for (n = 0; s[n]; n++)
    80000e90:	4501                	li	a0,0
    80000e92:	bfdd                	j	80000e88 <strlen+0x20>

0000000080000e94 <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000e94:	1141                	addi	sp,sp,-16
    80000e96:	e406                	sd	ra,8(sp)
    80000e98:	e022                	sd	s0,0(sp)
    80000e9a:	0800                	addi	s0,sp,16
  if (cpuid() == 0) {
    80000e9c:	247000ef          	jal	800018e2 <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();         // first user process

    __atomic_store_n(&started, 1, __ATOMIC_RELEASE);
  } else {
    while (__atomic_load_n(&started, __ATOMIC_ACQUIRE) == 0)
    80000ea0:	00007717          	auipc	a4,0x7
    80000ea4:	a1070713          	addi	a4,a4,-1520 # 800078b0 <started>
  if (cpuid() == 0) {
    80000ea8:	c51d                	beqz	a0,80000ed6 <main+0x42>
    while (__atomic_load_n(&started, __ATOMIC_ACQUIRE) == 0)
    80000eaa:	431c                	lw	a5,0(a4)
    80000eac:	0230000f          	fence	r,rw
    80000eb0:	2781                	sext.w	a5,a5
    80000eb2:	dfe5                	beqz	a5,80000eaa <main+0x16>
      ;

    printk("hart %d starting\n", cpuid());
    80000eb4:	22f000ef          	jal	800018e2 <cpuid>
    80000eb8:	85aa                	mv	a1,a0
    80000eba:	00006517          	auipc	a0,0x6
    80000ebe:	21e50513          	addi	a0,a0,542 # 800070d8 <etext+0xd8>
    80000ec2:	e38ff0ef          	jal	800004fa <printk>
    kvminithart();  // turn on paging
    80000ec6:	082000ef          	jal	80000f48 <kvminithart>
    trapinithart(); // install kernel trap vector
    80000eca:	664010ef          	jal	8000252e <trapinithart>
    plicinithart(); // ask PLIC for device interrupts
    80000ece:	7fa040ef          	jal	800056c8 <plicinithart>
  }

  scheduler();
    80000ed2:	6af000ef          	jal	80001d80 <scheduler>
    consoleinit();
    80000ed6:	d4cff0ef          	jal	80000422 <consoleinit>
    printkinit();
    80000eda:	995ff0ef          	jal	8000086e <printkinit>
    printk("\n");
    80000ede:	00006517          	auipc	a0,0x6
    80000ee2:	1da50513          	addi	a0,a0,474 # 800070b8 <etext+0xb8>
    80000ee6:	e14ff0ef          	jal	800004fa <printk>
    printk("xv6 kernel is booting\n");
    80000eea:	00006517          	auipc	a0,0x6
    80000eee:	1d650513          	addi	a0,a0,470 # 800070c0 <etext+0xc0>
    80000ef2:	e08ff0ef          	jal	800004fa <printk>
    printk("\n");
    80000ef6:	00006517          	auipc	a0,0x6
    80000efa:	1c250513          	addi	a0,a0,450 # 800070b8 <etext+0xb8>
    80000efe:	dfcff0ef          	jal	800004fa <printk>
    kinit();            // physical page allocator
    80000f02:	c01ff0ef          	jal	80000b02 <kinit>
    kvminit();          // create kernel page table
    80000f06:	2c2000ef          	jal	800011c8 <kvminit>
    kvminithart();      // turn on paging
    80000f0a:	03e000ef          	jal	80000f48 <kvminithart>
    procinit();         // process table
    80000f0e:	11d000ef          	jal	8000182a <procinit>
    trapinit();         // trap vectors
    80000f12:	5f8010ef          	jal	8000250a <trapinit>
    trapinithart();     // install kernel trap vector
    80000f16:	618010ef          	jal	8000252e <trapinithart>
    plicinit();         // set up interrupt controller
    80000f1a:	794040ef          	jal	800056ae <plicinit>
    plicinithart();     // ask PLIC for device interrupts
    80000f1e:	7aa040ef          	jal	800056c8 <plicinithart>
    binit();            // buffer cache
    80000f22:	4e5010ef          	jal	80002c06 <binit>
    iinit();            // inode table
    80000f26:	23e020ef          	jal	80003164 <iinit>
    fileinit();         // file table
    80000f2a:	282030ef          	jal	800041ac <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000f2e:	091040ef          	jal	800057be <virtio_disk_init>
    userinit();         // first user process
    80000f32:	4ad000ef          	jal	80001bde <userinit>
    __atomic_store_n(&started, 1, __ATOMIC_RELEASE);
    80000f36:	00007797          	auipc	a5,0x7
    80000f3a:	97a78793          	addi	a5,a5,-1670 # 800078b0 <started>
    80000f3e:	4705                	li	a4,1
    80000f40:	0310000f          	fence	rw,w
    80000f44:	c398                	sw	a4,0(a5)
    80000f46:	b771                	j	80000ed2 <main+0x3e>

0000000080000f48 <kvminithart>:

// Switch the current CPU's h/w page table register to
// the kernel's page table, and enable paging.
void
kvminithart()
{
    80000f48:	1141                	addi	sp,sp,-16
    80000f4a:	e406                	sd	ra,8(sp)
    80000f4c:	e022                	sd	s0,0(sp)
    80000f4e:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero" ::: "memory");
    80000f50:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000f54:	00007797          	auipc	a5,0x7
    80000f58:	9647b783          	ld	a5,-1692(a5) # 800078b8 <kernel_pagetable>
    80000f5c:	83b1                	srli	a5,a5,0xc
    80000f5e:	577d                	li	a4,-1
    80000f60:	177e                	slli	a4,a4,0x3f
    80000f62:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r"(x));
    80000f64:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero" ::: "memory");
    80000f68:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000f6c:	60a2                	ld	ra,8(sp)
    80000f6e:	6402                	ld	s0,0(sp)
    80000f70:	0141                	addi	sp,sp,16
    80000f72:	8082                	ret

0000000080000f74 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000f74:	7139                	addi	sp,sp,-64
    80000f76:	fc06                	sd	ra,56(sp)
    80000f78:	f822                	sd	s0,48(sp)
    80000f7a:	f426                	sd	s1,40(sp)
    80000f7c:	f04a                	sd	s2,32(sp)
    80000f7e:	ec4e                	sd	s3,24(sp)
    80000f80:	e852                	sd	s4,16(sp)
    80000f82:	e456                	sd	s5,8(sp)
    80000f84:	e05a                	sd	s6,0(sp)
    80000f86:	0080                	addi	s0,sp,64
    80000f88:	84aa                	mv	s1,a0
    80000f8a:	89ae                	mv	s3,a1
    80000f8c:	8b32                	mv	s6,a2
  if (va >= MAXVA)
    80000f8e:	57fd                	li	a5,-1
    80000f90:	83e9                	srli	a5,a5,0x1a
    80000f92:	4a79                	li	s4,30
    panic("walk");

  for (int level = 2; level > 0; level--) {
    80000f94:	4ab1                	li	s5,12
  if (va >= MAXVA)
    80000f96:	06b7e363          	bltu	a5,a1,80000ffc <walk+0x88>
    pte_t *pte = &pagetable[PX(level, va)];
    80000f9a:	0149d933          	srl	s2,s3,s4
    80000f9e:	1ff97913          	andi	s2,s2,511
    80000fa2:	090e                	slli	s2,s2,0x3
    80000fa4:	9926                	add	s2,s2,s1
    if (*pte & PTE_V) {
    80000fa6:	00093483          	ld	s1,0(s2)
    80000faa:	0014f793          	andi	a5,s1,1
      pagetable = (pagetable_t)PTE2PA(*pte);
    80000fae:	80a9                	srli	s1,s1,0xa
    80000fb0:	04b2                	slli	s1,s1,0xc
    if (*pte & PTE_V) {
    80000fb2:	e395                	bnez	a5,80000fd6 <walk+0x62>
    } else {
      if (!alloc || (pagetable = (pde_t *)kalloc()) == 0)
    80000fb4:	040b0a63          	beqz	s6,80001008 <walk+0x94>
    80000fb8:	b7fff0ef          	jal	80000b36 <kalloc>
    80000fbc:	84aa                	mv	s1,a0
    80000fbe:	c50d                	beqz	a0,80000fe8 <walk+0x74>
        return 0;
      memset(pagetable, 0, PGSIZE);
    80000fc0:	6605                	lui	a2,0x1
    80000fc2:	4581                	li	a1,0
    80000fc4:	d25ff0ef          	jal	80000ce8 <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80000fc8:	00c4d793          	srli	a5,s1,0xc
    80000fcc:	07aa                	slli	a5,a5,0xa
    80000fce:	0017e793          	ori	a5,a5,1
    80000fd2:	00f93023          	sd	a5,0(s2)
  for (int level = 2; level > 0; level--) {
    80000fd6:	3a5d                	addiw	s4,s4,-9
    80000fd8:	fd5a11e3          	bne	s4,s5,80000f9a <walk+0x26>
    }
  }
  return &pagetable[PX(0, va)];
    80000fdc:	00c9d513          	srli	a0,s3,0xc
    80000fe0:	1ff57513          	andi	a0,a0,511
    80000fe4:	050e                	slli	a0,a0,0x3
    80000fe6:	9526                	add	a0,a0,s1
}
    80000fe8:	70e2                	ld	ra,56(sp)
    80000fea:	7442                	ld	s0,48(sp)
    80000fec:	74a2                	ld	s1,40(sp)
    80000fee:	7902                	ld	s2,32(sp)
    80000ff0:	69e2                	ld	s3,24(sp)
    80000ff2:	6a42                	ld	s4,16(sp)
    80000ff4:	6aa2                	ld	s5,8(sp)
    80000ff6:	6b02                	ld	s6,0(sp)
    80000ff8:	6121                	addi	sp,sp,64
    80000ffa:	8082                	ret
    panic("walk");
    80000ffc:	00006517          	auipc	a0,0x6
    80001000:	0f450513          	addi	a0,a0,244 # 800070f0 <etext+0xf0>
    80001004:	82fff0ef          	jal	80000832 <panic>
        return 0;
    80001008:	4501                	li	a0,0
    8000100a:	bff9                	j	80000fe8 <walk+0x74>

000000008000100c <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if (va >= MAXVA)
    8000100c:	57fd                	li	a5,-1
    8000100e:	83e9                	srli	a5,a5,0x1a
    80001010:	00b7f463          	bgeu	a5,a1,80001018 <walkaddr+0xc>
    return 0;
    80001014:	4501                	li	a0,0
    return 0;
  if ((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80001016:	8082                	ret
{
    80001018:	1141                	addi	sp,sp,-16
    8000101a:	e406                	sd	ra,8(sp)
    8000101c:	e022                	sd	s0,0(sp)
    8000101e:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80001020:	4601                	li	a2,0
    80001022:	f53ff0ef          	jal	80000f74 <walk>
  if (pte == 0)
    80001026:	c519                	beqz	a0,80001034 <walkaddr+0x28>
  if ((*pte & PTE_V) == 0)
    80001028:	6108                	ld	a0,0(a0)
  if ((*pte & PTE_U) == 0)
    8000102a:	01157713          	andi	a4,a0,17
    8000102e:	47c5                	li	a5,17
    80001030:	00f70763          	beq	a4,a5,8000103e <walkaddr+0x32>
    return 0;
    80001034:	4501                	li	a0,0
}
    80001036:	60a2                	ld	ra,8(sp)
    80001038:	6402                	ld	s0,0(sp)
    8000103a:	0141                	addi	sp,sp,16
    8000103c:	8082                	ret
  pa = PTE2PA(*pte);
    8000103e:	8129                	srli	a0,a0,0xa
    80001040:	0532                	slli	a0,a0,0xc
  return pa;
    80001042:	bfd5                	j	80001036 <walkaddr+0x2a>

0000000080001044 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80001044:	715d                	addi	sp,sp,-80
    80001046:	e486                	sd	ra,72(sp)
    80001048:	e0a2                	sd	s0,64(sp)
    8000104a:	fc26                	sd	s1,56(sp)
    8000104c:	f84a                	sd	s2,48(sp)
    8000104e:	f44e                	sd	s3,40(sp)
    80001050:	f052                	sd	s4,32(sp)
    80001052:	ec56                	sd	s5,24(sp)
    80001054:	e85a                	sd	s6,16(sp)
    80001056:	e45e                	sd	s7,8(sp)
    80001058:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if ((va % PGSIZE) != 0)
    8000105a:	03459793          	slli	a5,a1,0x34
    8000105e:	e7b1                	bnez	a5,800010aa <mappages+0x66>
    80001060:	8a2a                	mv	s4,a0
    80001062:	8aba                	mv	s5,a4
    panic("mappages: va not aligned");

  if ((size % PGSIZE) != 0)
    80001064:	03461793          	slli	a5,a2,0x34
    80001068:	e7b9                	bnez	a5,800010b6 <mappages+0x72>
    panic("mappages: size not aligned");

  if (size == 0)
    8000106a:	ce21                	beqz	a2,800010c2 <mappages+0x7e>
    panic("mappages: size");

  a = va;
  last = va + size - PGSIZE;
    8000106c:	77fd                	lui	a5,0xfffff
    8000106e:	963e                	add	a2,a2,a5
    80001070:	00b60933          	add	s2,a2,a1
  a = va;
    80001074:	84ae                	mv	s1,a1
  for (;;) {
    if ((pte = walk(pagetable, a, 1)) == 0)
    80001076:	4b05                	li	s6,1
    80001078:	40b689b3          	sub	s3,a3,a1
    if (*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if (a == last)
      break;
    a += PGSIZE;
    8000107c:	6b85                	lui	s7,0x1
    if ((pte = walk(pagetable, a, 1)) == 0)
    8000107e:	865a                	mv	a2,s6
    80001080:	85a6                	mv	a1,s1
    80001082:	8552                	mv	a0,s4
    80001084:	ef1ff0ef          	jal	80000f74 <walk>
    80001088:	c929                	beqz	a0,800010da <mappages+0x96>
    if (*pte & PTE_V)
    8000108a:	611c                	ld	a5,0(a0)
    8000108c:	8b85                	andi	a5,a5,1
    8000108e:	e3a1                	bnez	a5,800010ce <mappages+0x8a>
    *pte = PA2PTE(pa) | perm | PTE_V;
    80001090:	013487b3          	add	a5,s1,s3
    80001094:	83b1                	srli	a5,a5,0xc
    80001096:	07aa                	slli	a5,a5,0xa
    80001098:	0157e7b3          	or	a5,a5,s5
    8000109c:	0017e793          	ori	a5,a5,1
    800010a0:	e11c                	sd	a5,0(a0)
    if (a == last)
    800010a2:	05248863          	beq	s1,s2,800010f2 <mappages+0xae>
    a += PGSIZE;
    800010a6:	94de                	add	s1,s1,s7
    if ((pte = walk(pagetable, a, 1)) == 0)
    800010a8:	bfd9                	j	8000107e <mappages+0x3a>
    panic("mappages: va not aligned");
    800010aa:	00006517          	auipc	a0,0x6
    800010ae:	04e50513          	addi	a0,a0,78 # 800070f8 <etext+0xf8>
    800010b2:	f80ff0ef          	jal	80000832 <panic>
    panic("mappages: size not aligned");
    800010b6:	00006517          	auipc	a0,0x6
    800010ba:	06250513          	addi	a0,a0,98 # 80007118 <etext+0x118>
    800010be:	f74ff0ef          	jal	80000832 <panic>
    panic("mappages: size");
    800010c2:	00006517          	auipc	a0,0x6
    800010c6:	07650513          	addi	a0,a0,118 # 80007138 <etext+0x138>
    800010ca:	f68ff0ef          	jal	80000832 <panic>
      panic("mappages: remap");
    800010ce:	00006517          	auipc	a0,0x6
    800010d2:	07a50513          	addi	a0,a0,122 # 80007148 <etext+0x148>
    800010d6:	f5cff0ef          	jal	80000832 <panic>
      return -1;
    800010da:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    800010dc:	60a6                	ld	ra,72(sp)
    800010de:	6406                	ld	s0,64(sp)
    800010e0:	74e2                	ld	s1,56(sp)
    800010e2:	7942                	ld	s2,48(sp)
    800010e4:	79a2                	ld	s3,40(sp)
    800010e6:	7a02                	ld	s4,32(sp)
    800010e8:	6ae2                	ld	s5,24(sp)
    800010ea:	6b42                	ld	s6,16(sp)
    800010ec:	6ba2                	ld	s7,8(sp)
    800010ee:	6161                	addi	sp,sp,80
    800010f0:	8082                	ret
  return 0;
    800010f2:	4501                	li	a0,0
    800010f4:	b7e5                	j	800010dc <mappages+0x98>

00000000800010f6 <kvmmap>:
{
    800010f6:	1141                	addi	sp,sp,-16
    800010f8:	e406                	sd	ra,8(sp)
    800010fa:	e022                	sd	s0,0(sp)
    800010fc:	0800                	addi	s0,sp,16
    800010fe:	87b6                	mv	a5,a3
  if (mappages(kpgtbl, va, sz, pa, perm) != 0)
    80001100:	86b2                	mv	a3,a2
    80001102:	863e                	mv	a2,a5
    80001104:	f41ff0ef          	jal	80001044 <mappages>
    80001108:	e509                	bnez	a0,80001112 <kvmmap+0x1c>
}
    8000110a:	60a2                	ld	ra,8(sp)
    8000110c:	6402                	ld	s0,0(sp)
    8000110e:	0141                	addi	sp,sp,16
    80001110:	8082                	ret
    panic("kvmmap");
    80001112:	00006517          	auipc	a0,0x6
    80001116:	04650513          	addi	a0,a0,70 # 80007158 <etext+0x158>
    8000111a:	f18ff0ef          	jal	80000832 <panic>

000000008000111e <kvmmake>:
{
    8000111e:	1101                	addi	sp,sp,-32
    80001120:	ec06                	sd	ra,24(sp)
    80001122:	e822                	sd	s0,16(sp)
    80001124:	e426                	sd	s1,8(sp)
    80001126:	e04a                	sd	s2,0(sp)
    80001128:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t)kalloc();
    8000112a:	a0dff0ef          	jal	80000b36 <kalloc>
    8000112e:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    80001130:	6605                	lui	a2,0x1
    80001132:	4581                	li	a1,0
    80001134:	bb5ff0ef          	jal	80000ce8 <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    80001138:	4719                	li	a4,6
    8000113a:	6685                	lui	a3,0x1
    8000113c:	10000637          	lui	a2,0x10000
    80001140:	85b2                	mv	a1,a2
    80001142:	8526                	mv	a0,s1
    80001144:	fb3ff0ef          	jal	800010f6 <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    80001148:	4719                	li	a4,6
    8000114a:	6685                	lui	a3,0x1
    8000114c:	10001637          	lui	a2,0x10001
    80001150:	85b2                	mv	a1,a2
    80001152:	8526                	mv	a0,s1
    80001154:	fa3ff0ef          	jal	800010f6 <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    80001158:	4719                	li	a4,6
    8000115a:	040006b7          	lui	a3,0x4000
    8000115e:	0c000637          	lui	a2,0xc000
    80001162:	85b2                	mv	a1,a2
    80001164:	8526                	mv	a0,s1
    80001166:	f91ff0ef          	jal	800010f6 <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext - KERNBASE, PTE_R | PTE_X);
    8000116a:	00006917          	auipc	s2,0x6
    8000116e:	e9690913          	addi	s2,s2,-362 # 80007000 <etext>
    80001172:	4729                	li	a4,10
    80001174:	800006b7          	lui	a3,0x80000
    80001178:	96ca                	add	a3,a3,s2
    8000117a:	4605                	li	a2,1
    8000117c:	067e                	slli	a2,a2,0x1f
    8000117e:	85b2                	mv	a1,a2
    80001180:	8526                	mv	a0,s1
    80001182:	f75ff0ef          	jal	800010f6 <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP - (uint64)etext,
    80001186:	4719                	li	a4,6
    80001188:	46c5                	li	a3,17
    8000118a:	06ee                	slli	a3,a3,0x1b
    8000118c:	412686b3          	sub	a3,a3,s2
    80001190:	864a                	mv	a2,s2
    80001192:	85ca                	mv	a1,s2
    80001194:	8526                	mv	a0,s1
    80001196:	f61ff0ef          	jal	800010f6 <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    8000119a:	4729                	li	a4,10
    8000119c:	6685                	lui	a3,0x1
    8000119e:	00005617          	auipc	a2,0x5
    800011a2:	e6260613          	addi	a2,a2,-414 # 80006000 <_trampoline>
    800011a6:	040005b7          	lui	a1,0x4000
    800011aa:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    800011ac:	05b2                	slli	a1,a1,0xc
    800011ae:	8526                	mv	a0,s1
    800011b0:	f47ff0ef          	jal	800010f6 <kvmmap>
  proc_mapstacks(kpgtbl);
    800011b4:	8526                	mv	a0,s1
    800011b6:	5e0000ef          	jal	80001796 <proc_mapstacks>
}
    800011ba:	8526                	mv	a0,s1
    800011bc:	60e2                	ld	ra,24(sp)
    800011be:	6442                	ld	s0,16(sp)
    800011c0:	64a2                	ld	s1,8(sp)
    800011c2:	6902                	ld	s2,0(sp)
    800011c4:	6105                	addi	sp,sp,32
    800011c6:	8082                	ret

00000000800011c8 <kvminit>:
{
    800011c8:	1141                	addi	sp,sp,-16
    800011ca:	e406                	sd	ra,8(sp)
    800011cc:	e022                	sd	s0,0(sp)
    800011ce:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    800011d0:	f4fff0ef          	jal	8000111e <kvmmake>
    800011d4:	00006797          	auipc	a5,0x6
    800011d8:	6ea7b223          	sd	a0,1764(a5) # 800078b8 <kernel_pagetable>
}
    800011dc:	60a2                	ld	ra,8(sp)
    800011de:	6402                	ld	s0,0(sp)
    800011e0:	0141                	addi	sp,sp,16
    800011e2:	8082                	ret

00000000800011e4 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    800011e4:	1101                	addi	sp,sp,-32
    800011e6:	ec06                	sd	ra,24(sp)
    800011e8:	e822                	sd	s0,16(sp)
    800011ea:	e426                	sd	s1,8(sp)
    800011ec:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t)kalloc();
    800011ee:	949ff0ef          	jal	80000b36 <kalloc>
    800011f2:	84aa                	mv	s1,a0
  if (pagetable == 0)
    800011f4:	c509                	beqz	a0,800011fe <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    800011f6:	6605                	lui	a2,0x1
    800011f8:	4581                	li	a1,0
    800011fa:	aefff0ef          	jal	80000ce8 <memset>
  return pagetable;
}
    800011fe:	8526                	mv	a0,s1
    80001200:	60e2                	ld	ra,24(sp)
    80001202:	6442                	ld	s0,16(sp)
    80001204:	64a2                	ld	s1,8(sp)
    80001206:	6105                	addi	sp,sp,32
    80001208:	8082                	ret

000000008000120a <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    8000120a:	7139                	addi	sp,sp,-64
    8000120c:	fc06                	sd	ra,56(sp)
    8000120e:	f822                	sd	s0,48(sp)
    80001210:	0080                	addi	s0,sp,64
  uint64 a;
  pte_t *pte;

  if ((va % PGSIZE) != 0)
    80001212:	03459793          	slli	a5,a1,0x34
    80001216:	e38d                	bnez	a5,80001238 <uvmunmap+0x2e>
    80001218:	f04a                	sd	s2,32(sp)
    8000121a:	ec4e                	sd	s3,24(sp)
    8000121c:	e852                	sd	s4,16(sp)
    8000121e:	e456                	sd	s5,8(sp)
    80001220:	e05a                	sd	s6,0(sp)
    80001222:	8a2a                	mv	s4,a0
    80001224:	892e                	mv	s2,a1
    80001226:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for (a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    80001228:	0632                	slli	a2,a2,0xc
    8000122a:	00b609b3          	add	s3,a2,a1
    8000122e:	6b05                	lui	s6,0x1
    80001230:	0535f963          	bgeu	a1,s3,80001282 <uvmunmap+0x78>
    80001234:	f426                	sd	s1,40(sp)
    80001236:	a015                	j	8000125a <uvmunmap+0x50>
    80001238:	f426                	sd	s1,40(sp)
    8000123a:	f04a                	sd	s2,32(sp)
    8000123c:	ec4e                	sd	s3,24(sp)
    8000123e:	e852                	sd	s4,16(sp)
    80001240:	e456                	sd	s5,8(sp)
    80001242:	e05a                	sd	s6,0(sp)
    panic("uvmunmap: not aligned");
    80001244:	00006517          	auipc	a0,0x6
    80001248:	f1c50513          	addi	a0,a0,-228 # 80007160 <etext+0x160>
    8000124c:	de6ff0ef          	jal	80000832 <panic>
      continue;
    if (do_free) {
      uint64 pa = PTE2PA(*pte);
      kfree((void *)pa);
    }
    *pte = 0;
    80001250:	0004b023          	sd	zero,0(s1)
  for (a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    80001254:	995a                	add	s2,s2,s6
    80001256:	03397563          	bgeu	s2,s3,80001280 <uvmunmap+0x76>
    if ((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
    8000125a:	4601                	li	a2,0
    8000125c:	85ca                	mv	a1,s2
    8000125e:	8552                	mv	a0,s4
    80001260:	d15ff0ef          	jal	80000f74 <walk>
    80001264:	84aa                	mv	s1,a0
    80001266:	d57d                	beqz	a0,80001254 <uvmunmap+0x4a>
    if ((*pte & PTE_V) == 0) // has physical page been allocated?
    80001268:	611c                	ld	a5,0(a0)
    8000126a:	0017f713          	andi	a4,a5,1
    8000126e:	d37d                	beqz	a4,80001254 <uvmunmap+0x4a>
    if (do_free) {
    80001270:	fe0a80e3          	beqz	s5,80001250 <uvmunmap+0x46>
      uint64 pa = PTE2PA(*pte);
    80001274:	83a9                	srli	a5,a5,0xa
      kfree((void *)pa);
    80001276:	00c79513          	slli	a0,a5,0xc
    8000127a:	fd4ff0ef          	jal	80000a4e <kfree>
    8000127e:	bfc9                	j	80001250 <uvmunmap+0x46>
    80001280:	74a2                	ld	s1,40(sp)
    80001282:	7902                	ld	s2,32(sp)
    80001284:	69e2                	ld	s3,24(sp)
    80001286:	6a42                	ld	s4,16(sp)
    80001288:	6aa2                	ld	s5,8(sp)
    8000128a:	6b02                	ld	s6,0(sp)
  }
}
    8000128c:	70e2                	ld	ra,56(sp)
    8000128e:	7442                	ld	s0,48(sp)
    80001290:	6121                	addi	sp,sp,64
    80001292:	8082                	ret

0000000080001294 <uvmdealloc>:
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
  if (newsz >= oldsz)
    80001294:	04b67163          	bgeu	a2,a1,800012d6 <uvmdealloc+0x42>
{
    80001298:	1101                	addi	sp,sp,-32
    8000129a:	ec06                	sd	ra,24(sp)
    8000129c:	e822                	sd	s0,16(sp)
    8000129e:	e426                	sd	s1,8(sp)
    800012a0:	1000                	addi	s0,sp,32
    800012a2:	84b2                	mv	s1,a2
    return oldsz;

  if (PGROUNDUP(newsz) < PGROUNDUP(oldsz)) {
    800012a4:	6785                	lui	a5,0x1
    800012a6:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800012a8:	00f60733          	add	a4,a2,a5
    800012ac:	76fd                	lui	a3,0xfffff
    800012ae:	8f75                	and	a4,a4,a3
    800012b0:	97ae                	add	a5,a5,a1
    800012b2:	8ff5                	and	a5,a5,a3
    800012b4:	00f76863          	bltu	a4,a5,800012c4 <uvmdealloc+0x30>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
    800012b8:	8526                	mv	a0,s1
}
    800012ba:	60e2                	ld	ra,24(sp)
    800012bc:	6442                	ld	s0,16(sp)
    800012be:	64a2                	ld	s1,8(sp)
    800012c0:	6105                	addi	sp,sp,32
    800012c2:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    800012c4:	8f99                	sub	a5,a5,a4
    800012c6:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    800012c8:	4685                	li	a3,1
    800012ca:	0007861b          	sext.w	a2,a5
    800012ce:	85ba                	mv	a1,a4
    800012d0:	f3bff0ef          	jal	8000120a <uvmunmap>
    800012d4:	b7d5                	j	800012b8 <uvmdealloc+0x24>
    return oldsz;
    800012d6:	852e                	mv	a0,a1
}
    800012d8:	8082                	ret

00000000800012da <uvmalloc>:
  if (newsz < oldsz)
    800012da:	08b66e63          	bltu	a2,a1,80001376 <uvmalloc+0x9c>
{
    800012de:	715d                	addi	sp,sp,-80
    800012e0:	e486                	sd	ra,72(sp)
    800012e2:	e0a2                	sd	s0,64(sp)
    800012e4:	f052                	sd	s4,32(sp)
    800012e6:	ec56                	sd	s5,24(sp)
    800012e8:	e45e                	sd	s7,8(sp)
    800012ea:	0880                	addi	s0,sp,80
    800012ec:	8aaa                	mv	s5,a0
    800012ee:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    800012f0:	6785                	lui	a5,0x1
    800012f2:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800012f4:	95be                	add	a1,a1,a5
    800012f6:	77fd                	lui	a5,0xfffff
    800012f8:	8fed                	and	a5,a5,a1
    800012fa:	8bbe                	mv	s7,a5
  for (a = oldsz; a < newsz; a += PGSIZE) {
    800012fc:	04c7f163          	bgeu	a5,a2,8000133e <uvmalloc+0x64>
    80001300:	fc26                	sd	s1,56(sp)
    80001302:	f84a                	sd	s2,48(sp)
    80001304:	f44e                	sd	s3,40(sp)
    80001306:	e85a                	sd	s6,16(sp)
    80001308:	893e                	mv	s2,a5
    memset(mem, 0, PGSIZE);
    8000130a:	6985                	lui	s3,0x1
    if (mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R | PTE_U | xperm) !=
    8000130c:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    80001310:	827ff0ef          	jal	80000b36 <kalloc>
    80001314:	84aa                	mv	s1,a0
    if (mem == 0) {
    80001316:	c515                	beqz	a0,80001342 <uvmalloc+0x68>
    memset(mem, 0, PGSIZE);
    80001318:	864e                	mv	a2,s3
    8000131a:	4581                	li	a1,0
    8000131c:	9cdff0ef          	jal	80000ce8 <memset>
    if (mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R | PTE_U | xperm) !=
    80001320:	875a                	mv	a4,s6
    80001322:	86a6                	mv	a3,s1
    80001324:	864e                	mv	a2,s3
    80001326:	85ca                	mv	a1,s2
    80001328:	8556                	mv	a0,s5
    8000132a:	d1bff0ef          	jal	80001044 <mappages>
    8000132e:	e91d                	bnez	a0,80001364 <uvmalloc+0x8a>
  for (a = oldsz; a < newsz; a += PGSIZE) {
    80001330:	994e                	add	s2,s2,s3
    80001332:	fd496fe3          	bltu	s2,s4,80001310 <uvmalloc+0x36>
    80001336:	74e2                	ld	s1,56(sp)
    80001338:	7942                	ld	s2,48(sp)
    8000133a:	79a2                	ld	s3,40(sp)
    8000133c:	6b42                	ld	s6,16(sp)
  return newsz;
    8000133e:	8552                	mv	a0,s4
    80001340:	a819                	j	80001356 <uvmalloc+0x7c>
      uvmdealloc(pagetable, a, oldsz);
    80001342:	865e                	mv	a2,s7
    80001344:	85ca                	mv	a1,s2
    80001346:	8556                	mv	a0,s5
    80001348:	f4dff0ef          	jal	80001294 <uvmdealloc>
      return 0;
    8000134c:	4501                	li	a0,0
    8000134e:	74e2                	ld	s1,56(sp)
    80001350:	7942                	ld	s2,48(sp)
    80001352:	79a2                	ld	s3,40(sp)
    80001354:	6b42                	ld	s6,16(sp)
}
    80001356:	60a6                	ld	ra,72(sp)
    80001358:	6406                	ld	s0,64(sp)
    8000135a:	7a02                	ld	s4,32(sp)
    8000135c:	6ae2                	ld	s5,24(sp)
    8000135e:	6ba2                	ld	s7,8(sp)
    80001360:	6161                	addi	sp,sp,80
    80001362:	8082                	ret
      kfree(mem);
    80001364:	8526                	mv	a0,s1
    80001366:	ee8ff0ef          	jal	80000a4e <kfree>
      uvmdealloc(pagetable, a, oldsz);
    8000136a:	865e                	mv	a2,s7
    8000136c:	85ca                	mv	a1,s2
    8000136e:	8556                	mv	a0,s5
    80001370:	f25ff0ef          	jal	80001294 <uvmdealloc>
      return 0;
    80001374:	bfe1                	j	8000134c <uvmalloc+0x72>
    return oldsz;
    80001376:	852e                	mv	a0,a1
}
    80001378:	8082                	ret

000000008000137a <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    8000137a:	7179                	addi	sp,sp,-48
    8000137c:	f406                	sd	ra,40(sp)
    8000137e:	f022                	sd	s0,32(sp)
    80001380:	ec26                	sd	s1,24(sp)
    80001382:	e84a                	sd	s2,16(sp)
    80001384:	e44e                	sd	s3,8(sp)
    80001386:	1800                	addi	s0,sp,48
    80001388:	89aa                	mv	s3,a0
  // there are 2^9 = 512 PTEs in a page table.
  for (int i = 0; i < 512; i++) {
    8000138a:	84aa                	mv	s1,a0
    8000138c:	6905                	lui	s2,0x1
    8000138e:	992a                	add	s2,s2,a0
    80001390:	a811                	j	800013a4 <freewalk+0x2a>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
      freewalk((pagetable_t)child);
      pagetable[i] = 0;
    } else if (pte & PTE_V) {
      panic("freewalk: leaf");
    80001392:	00006517          	auipc	a0,0x6
    80001396:	de650513          	addi	a0,a0,-538 # 80007178 <etext+0x178>
    8000139a:	c98ff0ef          	jal	80000832 <panic>
  for (int i = 0; i < 512; i++) {
    8000139e:	04a1                	addi	s1,s1,8
    800013a0:	03248163          	beq	s1,s2,800013c2 <freewalk+0x48>
    pte_t pte = pagetable[i];
    800013a4:	609c                	ld	a5,0(s1)
    if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    800013a6:	0017f713          	andi	a4,a5,1
    800013aa:	db75                	beqz	a4,8000139e <freewalk+0x24>
    800013ac:	00e7f713          	andi	a4,a5,14
    800013b0:	f36d                	bnez	a4,80001392 <freewalk+0x18>
      uint64 child = PTE2PA(pte);
    800013b2:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    800013b4:	00c79513          	slli	a0,a5,0xc
    800013b8:	fc3ff0ef          	jal	8000137a <freewalk>
      pagetable[i] = 0;
    800013bc:	0004b023          	sd	zero,0(s1)
    if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    800013c0:	bff9                	j	8000139e <freewalk+0x24>
    }
  }
  kfree((void *)pagetable);
    800013c2:	854e                	mv	a0,s3
    800013c4:	e8aff0ef          	jal	80000a4e <kfree>
}
    800013c8:	70a2                	ld	ra,40(sp)
    800013ca:	7402                	ld	s0,32(sp)
    800013cc:	64e2                	ld	s1,24(sp)
    800013ce:	6942                	ld	s2,16(sp)
    800013d0:	69a2                	ld	s3,8(sp)
    800013d2:	6145                	addi	sp,sp,48
    800013d4:	8082                	ret

00000000800013d6 <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    800013d6:	1101                	addi	sp,sp,-32
    800013d8:	ec06                	sd	ra,24(sp)
    800013da:	e822                	sd	s0,16(sp)
    800013dc:	e426                	sd	s1,8(sp)
    800013de:	1000                	addi	s0,sp,32
    800013e0:	84aa                	mv	s1,a0
  if (sz > 0)
    800013e2:	e989                	bnez	a1,800013f4 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz) / PGSIZE, 1);
  freewalk(pagetable);
    800013e4:	8526                	mv	a0,s1
    800013e6:	f95ff0ef          	jal	8000137a <freewalk>
}
    800013ea:	60e2                	ld	ra,24(sp)
    800013ec:	6442                	ld	s0,16(sp)
    800013ee:	64a2                	ld	s1,8(sp)
    800013f0:	6105                	addi	sp,sp,32
    800013f2:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz) / PGSIZE, 1);
    800013f4:	6785                	lui	a5,0x1
    800013f6:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800013f8:	95be                	add	a1,a1,a5
    800013fa:	4685                	li	a3,1
    800013fc:	00c5d613          	srli	a2,a1,0xc
    80001400:	4581                	li	a1,0
    80001402:	e09ff0ef          	jal	8000120a <uvmunmap>
    80001406:	bff9                	j	800013e4 <uvmfree+0xe>

0000000080001408 <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for (i = 0; i < sz; i += PGSIZE) {
    80001408:	ca59                	beqz	a2,8000149e <uvmcopy+0x96>
{
    8000140a:	715d                	addi	sp,sp,-80
    8000140c:	e486                	sd	ra,72(sp)
    8000140e:	e0a2                	sd	s0,64(sp)
    80001410:	fc26                	sd	s1,56(sp)
    80001412:	f84a                	sd	s2,48(sp)
    80001414:	f44e                	sd	s3,40(sp)
    80001416:	f052                	sd	s4,32(sp)
    80001418:	ec56                	sd	s5,24(sp)
    8000141a:	e85a                	sd	s6,16(sp)
    8000141c:	e45e                	sd	s7,8(sp)
    8000141e:	0880                	addi	s0,sp,80
    80001420:	8b2a                	mv	s6,a0
    80001422:	8bae                	mv	s7,a1
    80001424:	8ab2                	mv	s5,a2
  for (i = 0; i < sz; i += PGSIZE) {
    80001426:	4481                	li	s1,0
      continue; // physical page hasn't been allocated
    pa = PTE2PA(*pte);
    flags = PTE_FLAGS(*pte);
    if ((mem = kalloc()) == 0)
      goto err;
    memmove(mem, (char *)pa, PGSIZE);
    80001428:	6a05                	lui	s4,0x1
    8000142a:	a021                	j	80001432 <uvmcopy+0x2a>
  for (i = 0; i < sz; i += PGSIZE) {
    8000142c:	94d2                	add	s1,s1,s4
    8000142e:	0554fc63          	bgeu	s1,s5,80001486 <uvmcopy+0x7e>
    if ((pte = walk(old, i, 0)) == 0)
    80001432:	4601                	li	a2,0
    80001434:	85a6                	mv	a1,s1
    80001436:	855a                	mv	a0,s6
    80001438:	b3dff0ef          	jal	80000f74 <walk>
    8000143c:	d965                	beqz	a0,8000142c <uvmcopy+0x24>
    if ((*pte & PTE_V) == 0)
    8000143e:	00053983          	ld	s3,0(a0)
    80001442:	0019f793          	andi	a5,s3,1
    80001446:	d3fd                	beqz	a5,8000142c <uvmcopy+0x24>
    if ((mem = kalloc()) == 0)
    80001448:	eeeff0ef          	jal	80000b36 <kalloc>
    8000144c:	892a                	mv	s2,a0
    8000144e:	c11d                	beqz	a0,80001474 <uvmcopy+0x6c>
    pa = PTE2PA(*pte);
    80001450:	00a9d593          	srli	a1,s3,0xa
    memmove(mem, (char *)pa, PGSIZE);
    80001454:	8652                	mv	a2,s4
    80001456:	05b2                	slli	a1,a1,0xc
    80001458:	8edff0ef          	jal	80000d44 <memmove>
    if (mappages(new, i, PGSIZE, (uint64)mem, flags) != 0) {
    8000145c:	3ff9f713          	andi	a4,s3,1023
    80001460:	86ca                	mv	a3,s2
    80001462:	8652                	mv	a2,s4
    80001464:	85a6                	mv	a1,s1
    80001466:	855e                	mv	a0,s7
    80001468:	bddff0ef          	jal	80001044 <mappages>
    8000146c:	d161                	beqz	a0,8000142c <uvmcopy+0x24>
      kfree(mem);
    8000146e:	854a                	mv	a0,s2
    80001470:	ddeff0ef          	jal	80000a4e <kfree>
    }
  }
  return 0;

err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    80001474:	4685                	li	a3,1
    80001476:	00c4d613          	srli	a2,s1,0xc
    8000147a:	4581                	li	a1,0
    8000147c:	855e                	mv	a0,s7
    8000147e:	d8dff0ef          	jal	8000120a <uvmunmap>
  return -1;
    80001482:	557d                	li	a0,-1
    80001484:	a011                	j	80001488 <uvmcopy+0x80>
  return 0;
    80001486:	4501                	li	a0,0
}
    80001488:	60a6                	ld	ra,72(sp)
    8000148a:	6406                	ld	s0,64(sp)
    8000148c:	74e2                	ld	s1,56(sp)
    8000148e:	7942                	ld	s2,48(sp)
    80001490:	79a2                	ld	s3,40(sp)
    80001492:	7a02                	ld	s4,32(sp)
    80001494:	6ae2                	ld	s5,24(sp)
    80001496:	6b42                	ld	s6,16(sp)
    80001498:	6ba2                	ld	s7,8(sp)
    8000149a:	6161                	addi	sp,sp,80
    8000149c:	8082                	ret
  return 0;
    8000149e:	4501                	li	a0,0
}
    800014a0:	8082                	ret

00000000800014a2 <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    800014a2:	1141                	addi	sp,sp,-16
    800014a4:	e406                	sd	ra,8(sp)
    800014a6:	e022                	sd	s0,0(sp)
    800014a8:	0800                	addi	s0,sp,16
  pte_t *pte;

  pte = walk(pagetable, va, 0);
    800014aa:	4601                	li	a2,0
    800014ac:	ac9ff0ef          	jal	80000f74 <walk>
  if (pte == 0)
    800014b0:	c901                	beqz	a0,800014c0 <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    800014b2:	611c                	ld	a5,0(a0)
    800014b4:	9bbd                	andi	a5,a5,-17
    800014b6:	e11c                	sd	a5,0(a0)
}
    800014b8:	60a2                	ld	ra,8(sp)
    800014ba:	6402                	ld	s0,0(sp)
    800014bc:	0141                	addi	sp,sp,16
    800014be:	8082                	ret
    panic("uvmclear");
    800014c0:	00006517          	auipc	a0,0x6
    800014c4:	cc850513          	addi	a0,a0,-824 # 80007188 <etext+0x188>
    800014c8:	b6aff0ef          	jal	80000832 <panic>

00000000800014cc <ismapped>:
  return mem;
}

int
ismapped(pagetable_t pagetable, uint64 va)
{
    800014cc:	1141                	addi	sp,sp,-16
    800014ce:	e406                	sd	ra,8(sp)
    800014d0:	e022                	sd	s0,0(sp)
    800014d2:	0800                	addi	s0,sp,16
  pte_t *pte = walk(pagetable, va, 0);
    800014d4:	4601                	li	a2,0
    800014d6:	a9fff0ef          	jal	80000f74 <walk>
  if (pte == 0) {
    800014da:	c119                	beqz	a0,800014e0 <ismapped+0x14>
    return 0;
  }
  if (*pte & PTE_V) {
    800014dc:	6108                	ld	a0,0(a0)
    800014de:	8905                	andi	a0,a0,1
    return 1;
  }
  return 0;
}
    800014e0:	60a2                	ld	ra,8(sp)
    800014e2:	6402                	ld	s0,0(sp)
    800014e4:	0141                	addi	sp,sp,16
    800014e6:	8082                	ret

00000000800014e8 <vmfault>:
{
    800014e8:	7179                	addi	sp,sp,-48
    800014ea:	f406                	sd	ra,40(sp)
    800014ec:	f022                	sd	s0,32(sp)
    800014ee:	e052                	sd	s4,0(sp)
    800014f0:	1800                	addi	s0,sp,48
  if (va >= psz)
    800014f2:	00b66d63          	bltu	a2,a1,8000150c <vmfault+0x24>
    return 0;
    800014f6:	4a01                	li	s4,0
}
    800014f8:	8552                	mv	a0,s4
    800014fa:	70a2                	ld	ra,40(sp)
    800014fc:	7402                	ld	s0,32(sp)
    800014fe:	6a02                	ld	s4,0(sp)
    80001500:	6145                	addi	sp,sp,48
    80001502:	8082                	ret
    80001504:	64e2                	ld	s1,24(sp)
    80001506:	6942                	ld	s2,16(sp)
    80001508:	69a2                	ld	s3,8(sp)
    8000150a:	b7f5                	j	800014f6 <vmfault+0xe>
    8000150c:	e84a                	sd	s2,16(sp)
    8000150e:	e44e                	sd	s3,8(sp)
  va = PGROUNDDOWN(va);
    80001510:	77fd                	lui	a5,0xfffff
    80001512:	00f67933          	and	s2,a2,a5
  if (ismapped(pagetable, va)) {
    80001516:	85ca                	mv	a1,s2
    80001518:	89aa                	mv	s3,a0
    8000151a:	fb3ff0ef          	jal	800014cc <ismapped>
    8000151e:	c501                	beqz	a0,80001526 <vmfault+0x3e>
    80001520:	6942                	ld	s2,16(sp)
    80001522:	69a2                	ld	s3,8(sp)
    80001524:	bfc9                	j	800014f6 <vmfault+0xe>
    80001526:	ec26                	sd	s1,24(sp)
  mem = (uint64)kalloc();
    80001528:	e0eff0ef          	jal	80000b36 <kalloc>
    8000152c:	84aa                	mv	s1,a0
  if (mem == 0)
    8000152e:	d979                	beqz	a0,80001504 <vmfault+0x1c>
  mem = (uint64)kalloc();
    80001530:	8a2a                	mv	s4,a0
  memset((void *)mem, 0, PGSIZE);
    80001532:	6605                	lui	a2,0x1
    80001534:	4581                	li	a1,0
    80001536:	fb2ff0ef          	jal	80000ce8 <memset>
  if (mappages(pagetable, va, PGSIZE, mem, PTE_W | PTE_U | PTE_R) != 0) {
    8000153a:	4759                	li	a4,22
    8000153c:	86a6                	mv	a3,s1
    8000153e:	6605                	lui	a2,0x1
    80001540:	85ca                	mv	a1,s2
    80001542:	854e                	mv	a0,s3
    80001544:	b01ff0ef          	jal	80001044 <mappages>
    80001548:	e509                	bnez	a0,80001552 <vmfault+0x6a>
    8000154a:	64e2                	ld	s1,24(sp)
    8000154c:	6942                	ld	s2,16(sp)
    8000154e:	69a2                	ld	s3,8(sp)
    80001550:	b765                	j	800014f8 <vmfault+0x10>
    kfree((void *)mem);
    80001552:	8526                	mv	a0,s1
    80001554:	cfaff0ef          	jal	80000a4e <kfree>
    return 0;
    80001558:	64e2                	ld	s1,24(sp)
    8000155a:	6942                	ld	s2,16(sp)
    8000155c:	69a2                	ld	s3,8(sp)
    8000155e:	bf61                	j	800014f6 <vmfault+0xe>

0000000080001560 <copyout>:
  while (len > 0) {
    80001560:	cf55                	beqz	a4,8000161c <copyout+0xbc>
{
    80001562:	7159                	addi	sp,sp,-112
    80001564:	f486                	sd	ra,104(sp)
    80001566:	f0a2                	sd	s0,96(sp)
    80001568:	eca6                	sd	s1,88(sp)
    8000156a:	e8ca                	sd	s2,80(sp)
    8000156c:	e4ce                	sd	s3,72(sp)
    8000156e:	e0d2                	sd	s4,64(sp)
    80001570:	fc56                	sd	s5,56(sp)
    80001572:	f85a                	sd	s6,48(sp)
    80001574:	f45e                	sd	s7,40(sp)
    80001576:	f062                	sd	s8,32(sp)
    80001578:	ec66                	sd	s9,24(sp)
    8000157a:	e86a                	sd	s10,16(sp)
    8000157c:	e46e                	sd	s11,8(sp)
    8000157e:	1880                	addi	s0,sp,112
    80001580:	8baa                	mv	s7,a0
    80001582:	8dae                	mv	s11,a1
    80001584:	84b2                	mv	s1,a2
    80001586:	8b36                	mv	s6,a3
    80001588:	8aba                	mv	s5,a4
    va0 = PGROUNDDOWN(dstva);
    8000158a:	7d7d                	lui	s10,0xfffff
    if (va0 >= MAXVA)
    8000158c:	5cfd                	li	s9,-1
    8000158e:	01acdc93          	srli	s9,s9,0x1a
    n = PGSIZE - (dstva - va0);
    80001592:	6c05                	lui	s8,0x1
    80001594:	a089                	j	800015d6 <copyout+0x76>
      return -1;
    80001596:	557d                	li	a0,-1
}
    80001598:	70a6                	ld	ra,104(sp)
    8000159a:	7406                	ld	s0,96(sp)
    8000159c:	64e6                	ld	s1,88(sp)
    8000159e:	6946                	ld	s2,80(sp)
    800015a0:	69a6                	ld	s3,72(sp)
    800015a2:	6a06                	ld	s4,64(sp)
    800015a4:	7ae2                	ld	s5,56(sp)
    800015a6:	7b42                	ld	s6,48(sp)
    800015a8:	7ba2                	ld	s7,40(sp)
    800015aa:	7c02                	ld	s8,32(sp)
    800015ac:	6ce2                	ld	s9,24(sp)
    800015ae:	6d42                	ld	s10,16(sp)
    800015b0:	6da2                	ld	s11,8(sp)
    800015b2:	6165                	addi	sp,sp,112
    800015b4:	8082                	ret
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    800015b6:	03449513          	slli	a0,s1,0x34
    800015ba:	9151                	srli	a0,a0,0x34
    800015bc:	0009061b          	sext.w	a2,s2
    800015c0:	85da                	mv	a1,s6
    800015c2:	954e                	add	a0,a0,s3
    800015c4:	f80ff0ef          	jal	80000d44 <memmove>
    len -= n;
    800015c8:	412a8ab3          	sub	s5,s5,s2
    src += n;
    800015cc:	9b4a                	add	s6,s6,s2
    dstva = va0 + PGSIZE;
    800015ce:	018a04b3          	add	s1,s4,s8
  while (len > 0) {
    800015d2:	040a8363          	beqz	s5,80001618 <copyout+0xb8>
    va0 = PGROUNDDOWN(dstva);
    800015d6:	01a4fa33          	and	s4,s1,s10
    if (va0 >= MAXVA)
    800015da:	fb4ceee3          	bltu	s9,s4,80001596 <copyout+0x36>
    pa0 = walkaddr(pagetable, va0);
    800015de:	85d2                	mv	a1,s4
    800015e0:	855e                	mv	a0,s7
    800015e2:	a2bff0ef          	jal	8000100c <walkaddr>
    800015e6:	89aa                	mv	s3,a0
    if (pa0 == 0) {
    800015e8:	e909                	bnez	a0,800015fa <copyout+0x9a>
      if ((pa0 = vmfault(pagetable, psz, va0, 0)) == 0) {
    800015ea:	4681                	li	a3,0
    800015ec:	8652                	mv	a2,s4
    800015ee:	85ee                	mv	a1,s11
    800015f0:	855e                	mv	a0,s7
    800015f2:	ef7ff0ef          	jal	800014e8 <vmfault>
    800015f6:	89aa                	mv	s3,a0
    800015f8:	dd59                	beqz	a0,80001596 <copyout+0x36>
    pte = walk(pagetable, va0, 0);
    800015fa:	4601                	li	a2,0
    800015fc:	85d2                	mv	a1,s4
    800015fe:	855e                	mv	a0,s7
    80001600:	975ff0ef          	jal	80000f74 <walk>
    if ((*pte & PTE_W) == 0)
    80001604:	611c                	ld	a5,0(a0)
    80001606:	8b91                	andi	a5,a5,4
    80001608:	d7d9                	beqz	a5,80001596 <copyout+0x36>
    n = PGSIZE - (dstva - va0);
    8000160a:	409a0933          	sub	s2,s4,s1
    8000160e:	9962                	add	s2,s2,s8
    if (n > len)
    80001610:	fb2af3e3          	bgeu	s5,s2,800015b6 <copyout+0x56>
    80001614:	8956                	mv	s2,s5
    80001616:	b745                	j	800015b6 <copyout+0x56>
  return 0;
    80001618:	4501                	li	a0,0
    8000161a:	bfbd                	j	80001598 <copyout+0x38>
    8000161c:	4501                	li	a0,0
}
    8000161e:	8082                	ret

0000000080001620 <copyin>:
  while (len > 0) {
    80001620:	cf49                	beqz	a4,800016ba <copyin+0x9a>
{
    80001622:	711d                	addi	sp,sp,-96
    80001624:	ec86                	sd	ra,88(sp)
    80001626:	e8a2                	sd	s0,80(sp)
    80001628:	e4a6                	sd	s1,72(sp)
    8000162a:	e0ca                	sd	s2,64(sp)
    8000162c:	fc4e                	sd	s3,56(sp)
    8000162e:	f852                	sd	s4,48(sp)
    80001630:	f456                	sd	s5,40(sp)
    80001632:	f05a                	sd	s6,32(sp)
    80001634:	ec5e                	sd	s7,24(sp)
    80001636:	e862                	sd	s8,16(sp)
    80001638:	e466                	sd	s9,8(sp)
    8000163a:	e06a                	sd	s10,0(sp)
    8000163c:	1080                	addi	s0,sp,96
    8000163e:	8baa                	mv	s7,a0
    80001640:	8cae                	mv	s9,a1
    80001642:	8ab2                	mv	s5,a2
    80001644:	84b6                	mv	s1,a3
    80001646:	89ba                	mv	s3,a4
    va0 = PGROUNDDOWN(srcva);
    80001648:	7c7d                	lui	s8,0xfffff
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    8000164a:	4d05                	li	s10,1
    n = PGSIZE - (srcva - va0);
    8000164c:	6b05                	lui	s6,0x1
    8000164e:	a03d                	j	8000167c <copyin+0x5c>
    80001650:	409a0933          	sub	s2,s4,s1
    80001654:	995a                	add	s2,s2,s6
    if (n > len)
    80001656:	0129f363          	bgeu	s3,s2,8000165c <copyin+0x3c>
    8000165a:	894e                	mv	s2,s3
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    8000165c:	03449593          	slli	a1,s1,0x34
    80001660:	91d1                	srli	a1,a1,0x34
    80001662:	0009061b          	sext.w	a2,s2
    80001666:	95aa                	add	a1,a1,a0
    80001668:	8556                	mv	a0,s5
    8000166a:	edaff0ef          	jal	80000d44 <memmove>
    len -= n;
    8000166e:	412989b3          	sub	s3,s3,s2
    dst += n;
    80001672:	9aca                	add	s5,s5,s2
    srcva = va0 + PGSIZE;
    80001674:	016a04b3          	add	s1,s4,s6
  while (len > 0) {
    80001678:	02098263          	beqz	s3,8000169c <copyin+0x7c>
    va0 = PGROUNDDOWN(srcva);
    8000167c:	0184fa33          	and	s4,s1,s8
    pa0 = walkaddr(pagetable, va0);
    80001680:	85d2                	mv	a1,s4
    80001682:	855e                	mv	a0,s7
    80001684:	989ff0ef          	jal	8000100c <walkaddr>
    if (pa0 == 0) {
    80001688:	f561                	bnez	a0,80001650 <copyin+0x30>
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    8000168a:	86ea                	mv	a3,s10
    8000168c:	8652                	mv	a2,s4
    8000168e:	85e6                	mv	a1,s9
    80001690:	855e                	mv	a0,s7
    80001692:	e57ff0ef          	jal	800014e8 <vmfault>
    80001696:	fd4d                	bnez	a0,80001650 <copyin+0x30>
        return -1;
    80001698:	557d                	li	a0,-1
    8000169a:	a011                	j	8000169e <copyin+0x7e>
  return 0;
    8000169c:	4501                	li	a0,0
}
    8000169e:	60e6                	ld	ra,88(sp)
    800016a0:	6446                	ld	s0,80(sp)
    800016a2:	64a6                	ld	s1,72(sp)
    800016a4:	6906                	ld	s2,64(sp)
    800016a6:	79e2                	ld	s3,56(sp)
    800016a8:	7a42                	ld	s4,48(sp)
    800016aa:	7aa2                	ld	s5,40(sp)
    800016ac:	7b02                	ld	s6,32(sp)
    800016ae:	6be2                	ld	s7,24(sp)
    800016b0:	6c42                	ld	s8,16(sp)
    800016b2:	6ca2                	ld	s9,8(sp)
    800016b4:	6d02                	ld	s10,0(sp)
    800016b6:	6125                	addi	sp,sp,96
    800016b8:	8082                	ret
  return 0;
    800016ba:	4501                	li	a0,0
}
    800016bc:	8082                	ret

00000000800016be <copyinstr>:
  while (got_null == 0 && max > 0) {
    800016be:	c771                	beqz	a4,8000178a <copyinstr+0xcc>
{
    800016c0:	711d                	addi	sp,sp,-96
    800016c2:	ec86                	sd	ra,88(sp)
    800016c4:	e8a2                	sd	s0,80(sp)
    800016c6:	e4a6                	sd	s1,72(sp)
    800016c8:	e0ca                	sd	s2,64(sp)
    800016ca:	fc4e                	sd	s3,56(sp)
    800016cc:	f852                	sd	s4,48(sp)
    800016ce:	f456                	sd	s5,40(sp)
    800016d0:	f05a                	sd	s6,32(sp)
    800016d2:	ec5e                	sd	s7,24(sp)
    800016d4:	e862                	sd	s8,16(sp)
    800016d6:	e466                	sd	s9,8(sp)
    800016d8:	1080                	addi	s0,sp,96
    800016da:	8b2a                	mv	s6,a0
    800016dc:	8c2e                	mv	s8,a1
    800016de:	8932                	mv	s2,a2
    800016e0:	84b6                	mv	s1,a3
    800016e2:	8a3a                	mv	s4,a4
    va0 = PGROUNDDOWN(srcva);
    800016e4:	7bfd                	lui	s7,0xfffff
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    800016e6:	4c85                	li	s9,1
    n = PGSIZE - (srcva - va0);
    800016e8:	6a85                	lui	s5,0x1
    800016ea:	a881                	j	8000173a <copyinstr+0x7c>
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    800016ec:	86e6                	mv	a3,s9
    800016ee:	864e                	mv	a2,s3
    800016f0:	85e2                	mv	a1,s8
    800016f2:	855a                	mv	a0,s6
    800016f4:	df5ff0ef          	jal	800014e8 <vmfault>
    800016f8:	e921                	bnez	a0,80001748 <copyinstr+0x8a>
        return -1;
    800016fa:	557d                	li	a0,-1
    800016fc:	a801                	j	8000170c <copyinstr+0x4e>
        *dst = '\0';
    800016fe:	00078023          	sb	zero,0(a5) # fffffffffffff000 <end+0xffffffff7ffde218>
        got_null = 1;
    80001702:	4785                	li	a5,1
  if (got_null) {
    80001704:	0017c793          	xori	a5,a5,1
    80001708:	40f0053b          	negw	a0,a5
}
    8000170c:	60e6                	ld	ra,88(sp)
    8000170e:	6446                	ld	s0,80(sp)
    80001710:	64a6                	ld	s1,72(sp)
    80001712:	6906                	ld	s2,64(sp)
    80001714:	79e2                	ld	s3,56(sp)
    80001716:	7a42                	ld	s4,48(sp)
    80001718:	7aa2                	ld	s5,40(sp)
    8000171a:	7b02                	ld	s6,32(sp)
    8000171c:	6be2                	ld	s7,24(sp)
    8000171e:	6c42                	ld	s8,16(sp)
    80001720:	6ca2                	ld	s9,8(sp)
    80001722:	6125                	addi	sp,sp,96
    80001724:	8082                	ret
    80001726:	fffa0713          	addi	a4,s4,-1 # fff <_entry-0x7ffff001>
    8000172a:	974a                	add	a4,a4,s2
      --max;
    8000172c:	40a70a33          	sub	s4,a4,a0
    srcva = va0 + PGSIZE;
    80001730:	015984b3          	add	s1,s3,s5
  while (got_null == 0 && max > 0) {
    80001734:	04e50563          	beq	a0,a4,8000177e <copyinstr+0xc0>
{
    80001738:	893e                	mv	s2,a5
    va0 = PGROUNDDOWN(srcva);
    8000173a:	0174f9b3          	and	s3,s1,s7
    pa0 = walkaddr(pagetable, va0);
    8000173e:	85ce                	mv	a1,s3
    80001740:	855a                	mv	a0,s6
    80001742:	8cbff0ef          	jal	8000100c <walkaddr>
    if (pa0 == 0) {
    80001746:	d15d                	beqz	a0,800016ec <copyinstr+0x2e>
    n = PGSIZE - (srcva - va0);
    80001748:	40998633          	sub	a2,s3,s1
    8000174c:	9656                	add	a2,a2,s5
    if (n > max)
    8000174e:	00ca7363          	bgeu	s4,a2,80001754 <copyinstr+0x96>
    80001752:	8652                	mv	a2,s4
    while (n > 0) {
    80001754:	c61d                	beqz	a2,80001782 <copyinstr+0xc4>
    char *p = (char *)(pa0 + (srcva - va0));
    80001756:	03449593          	slli	a1,s1,0x34
    8000175a:	91d1                	srli	a1,a1,0x34
    8000175c:	95aa                	add	a1,a1,a0
    8000175e:	87ca                	mv	a5,s2
      if (*p == '\0') {
    80001760:	412585b3          	sub	a1,a1,s2
    while (n > 0) {
    80001764:	964a                	add	a2,a2,s2
    80001766:	853e                	mv	a0,a5
      if (*p == '\0') {
    80001768:	00f58733          	add	a4,a1,a5
    8000176c:	00074683          	lbu	a3,0(a4)
    80001770:	d6d9                	beqz	a3,800016fe <copyinstr+0x40>
        *dst = *p;
    80001772:	00d78023          	sb	a3,0(a5)
      dst++;
    80001776:	0785                	addi	a5,a5,1
    while (n > 0) {
    80001778:	fec797e3          	bne	a5,a2,80001766 <copyinstr+0xa8>
    8000177c:	b76d                	j	80001726 <copyinstr+0x68>
    srcva = va0 + PGSIZE;
    8000177e:	4781                	li	a5,0
    80001780:	b751                	j	80001704 <copyinstr+0x46>
    80001782:	6485                	lui	s1,0x1
    80001784:	94ce                	add	s1,s1,s3
    80001786:	87ca                	mv	a5,s2
    80001788:	bf45                	j	80001738 <copyinstr+0x7a>
    8000178a:	4781                	li	a5,0
  if (got_null) {
    8000178c:	0017c793          	xori	a5,a5,1
    80001790:	40f0053b          	negw	a0,a5
}
    80001794:	8082                	ret

0000000080001796 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    80001796:	715d                	addi	sp,sp,-80
    80001798:	e486                	sd	ra,72(sp)
    8000179a:	e0a2                	sd	s0,64(sp)
    8000179c:	fc26                	sd	s1,56(sp)
    8000179e:	f84a                	sd	s2,48(sp)
    800017a0:	f44e                	sd	s3,40(sp)
    800017a2:	f052                	sd	s4,32(sp)
    800017a4:	ec56                	sd	s5,24(sp)
    800017a6:	e85a                	sd	s6,16(sp)
    800017a8:	e45e                	sd	s7,8(sp)
    800017aa:	0880                	addi	s0,sp,80
    800017ac:	8aaa                	mv	s5,a0
    800017ae:	4481                	li	s1,0

  for (p = proc; p < &proc[NPROC]; p++) {
    char *pa = kalloc();
    if (pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int)(p - proc));
    800017b0:	ff4df937          	lui	s2,0xff4df
    800017b4:	9bd90913          	addi	s2,s2,-1603 # ffffffffff4de9bd <end+0xffffffff7f4bdbd5>
    800017b8:	0936                	slli	s2,s2,0xd
    800017ba:	6f590913          	addi	s2,s2,1781
    800017be:	0936                	slli	s2,s2,0xd
    800017c0:	bd390913          	addi	s2,s2,-1069
    800017c4:	0932                	slli	s2,s2,0xc
    800017c6:	7a790913          	addi	s2,s2,1959
    800017ca:	040009b7          	lui	s3,0x4000
    800017ce:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    800017d0:	09b2                	slli	s3,s3,0xc
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    800017d2:	4b99                	li	s7,6
    800017d4:	6b05                	lui	s6,0x1
  for (p = proc; p < &proc[NPROC]; p++) {
    800017d6:	6a19                	lui	s4,0x6
    800017d8:	c00a0a13          	addi	s4,s4,-1024 # 5c00 <_entry-0x7fffa400>
    char *pa = kalloc();
    800017dc:	b5aff0ef          	jal	80000b36 <kalloc>
    800017e0:	862a                	mv	a2,a0
    if (pa == 0)
    800017e2:	cd15                	beqz	a0,8000181e <proc_mapstacks+0x88>
    uint64 va = KSTACK((int)(p - proc));
    800017e4:	4044d593          	srai	a1,s1,0x4
    800017e8:	032585b3          	mul	a1,a1,s2
    800017ec:	05b6                	slli	a1,a1,0xd
    800017ee:	6789                	lui	a5,0x2
    800017f0:	9dbd                	addw	a1,a1,a5
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    800017f2:	875e                	mv	a4,s7
    800017f4:	86da                	mv	a3,s6
    800017f6:	40b985b3          	sub	a1,s3,a1
    800017fa:	8556                	mv	a0,s5
    800017fc:	8fbff0ef          	jal	800010f6 <kvmmap>
  for (p = proc; p < &proc[NPROC]; p++) {
    80001800:	17048493          	addi	s1,s1,368 # 1170 <_entry-0x7fffee90>
    80001804:	fd449ce3          	bne	s1,s4,800017dc <proc_mapstacks+0x46>
  }
}
    80001808:	60a6                	ld	ra,72(sp)
    8000180a:	6406                	ld	s0,64(sp)
    8000180c:	74e2                	ld	s1,56(sp)
    8000180e:	7942                	ld	s2,48(sp)
    80001810:	79a2                	ld	s3,40(sp)
    80001812:	7a02                	ld	s4,32(sp)
    80001814:	6ae2                	ld	s5,24(sp)
    80001816:	6b42                	ld	s6,16(sp)
    80001818:	6ba2                	ld	s7,8(sp)
    8000181a:	6161                	addi	sp,sp,80
    8000181c:	8082                	ret
      panic("kalloc");
    8000181e:	00006517          	auipc	a0,0x6
    80001822:	97a50513          	addi	a0,a0,-1670 # 80007198 <etext+0x198>
    80001826:	80cff0ef          	jal	80000832 <panic>

000000008000182a <procinit>:

// initialize the proc table.
void
procinit(void)
{
    8000182a:	7139                	addi	sp,sp,-64
    8000182c:	fc06                	sd	ra,56(sp)
    8000182e:	f822                	sd	s0,48(sp)
    80001830:	f426                	sd	s1,40(sp)
    80001832:	f04a                	sd	s2,32(sp)
    80001834:	ec4e                	sd	s3,24(sp)
    80001836:	e852                	sd	s4,16(sp)
    80001838:	e456                	sd	s5,8(sp)
    8000183a:	e05a                	sd	s6,0(sp)
    8000183c:	0080                	addi	s0,sp,64
  struct proc *p;

  initlock(&pid_lock, "nextpid");
    8000183e:	00006597          	auipc	a1,0x6
    80001842:	96258593          	addi	a1,a1,-1694 # 800071a0 <etext+0x1a0>
    80001846:	0000e517          	auipc	a0,0xe
    8000184a:	19250513          	addi	a0,a0,402 # 8000f9d8 <pid_lock>
    8000184e:	b42ff0ef          	jal	80000b90 <initlock>
  initlock(&wait_lock, "wait_lock");
    80001852:	00006597          	auipc	a1,0x6
    80001856:	95658593          	addi	a1,a1,-1706 # 800071a8 <etext+0x1a8>
    8000185a:	0000e517          	auipc	a0,0xe
    8000185e:	19650513          	addi	a0,a0,406 # 8000f9f0 <wait_lock>
    80001862:	b2eff0ef          	jal	80000b90 <initlock>
    80001866:	4901                	li	s2,0
  for (p = proc; p < &proc[NPROC]; p++) {
    80001868:	0000e497          	auipc	s1,0xe
    8000186c:	5a048493          	addi	s1,s1,1440 # 8000fe08 <proc>
    initlock(&p->lock, "proc");
    80001870:	00006a97          	auipc	s5,0x6
    80001874:	948a8a93          	addi	s5,s5,-1720 # 800071b8 <etext+0x1b8>
    p->state = UNUSED;
    p->kstack = KSTACK((int)(p - proc));
    80001878:	ff4df9b7          	lui	s3,0xff4df
    8000187c:	9bd98993          	addi	s3,s3,-1603 # ffffffffff4de9bd <end+0xffffffff7f4bdbd5>
    80001880:	09b6                	slli	s3,s3,0xd
    80001882:	6f598993          	addi	s3,s3,1781
    80001886:	09b6                	slli	s3,s3,0xd
    80001888:	bd398993          	addi	s3,s3,-1069
    8000188c:	09b2                	slli	s3,s3,0xc
    8000188e:	7a798993          	addi	s3,s3,1959
    80001892:	04000a37          	lui	s4,0x4000
    80001896:	1a7d                	addi	s4,s4,-1 # 3ffffff <_entry-0x7c000001>
    80001898:	0a32                	slli	s4,s4,0xc
  for (p = proc; p < &proc[NPROC]; p++) {
    8000189a:	00014b17          	auipc	s6,0x14
    8000189e:	16eb0b13          	addi	s6,s6,366 # 80015a08 <tickslock>
    initlock(&p->lock, "proc");
    800018a2:	85d6                	mv	a1,s5
    800018a4:	8526                	mv	a0,s1
    800018a6:	aeaff0ef          	jal	80000b90 <initlock>
    p->state = UNUSED;
    800018aa:	0004ac23          	sw	zero,24(s1)
    p->kstack = KSTACK((int)(p - proc));
    800018ae:	40495793          	srai	a5,s2,0x4
    800018b2:	033787b3          	mul	a5,a5,s3
    800018b6:	07b6                	slli	a5,a5,0xd
    800018b8:	6709                	lui	a4,0x2
    800018ba:	9fb9                	addw	a5,a5,a4
    800018bc:	40fa07b3          	sub	a5,s4,a5
    800018c0:	e0bc                	sd	a5,64(s1)
  for (p = proc; p < &proc[NPROC]; p++) {
    800018c2:	17048493          	addi	s1,s1,368
    800018c6:	17090913          	addi	s2,s2,368
    800018ca:	fd649ce3          	bne	s1,s6,800018a2 <procinit+0x78>
  }
}
    800018ce:	70e2                	ld	ra,56(sp)
    800018d0:	7442                	ld	s0,48(sp)
    800018d2:	74a2                	ld	s1,40(sp)
    800018d4:	7902                	ld	s2,32(sp)
    800018d6:	69e2                	ld	s3,24(sp)
    800018d8:	6a42                	ld	s4,16(sp)
    800018da:	6aa2                	ld	s5,8(sp)
    800018dc:	6b02                	ld	s6,0(sp)
    800018de:	6121                	addi	sp,sp,64
    800018e0:	8082                	ret

00000000800018e2 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    800018e2:	1141                	addi	sp,sp,-16
    800018e4:	e406                	sd	ra,8(sp)
    800018e6:	e022                	sd	s0,0(sp)
    800018e8:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r"(x));
    800018ea:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    800018ec:	2501                	sext.w	a0,a0
    800018ee:	60a2                	ld	ra,8(sp)
    800018f0:	6402                	ld	s0,0(sp)
    800018f2:	0141                	addi	sp,sp,16
    800018f4:	8082                	ret

00000000800018f6 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu *
mycpu(void)
{
    800018f6:	1141                	addi	sp,sp,-16
    800018f8:	e406                	sd	ra,8(sp)
    800018fa:	e022                	sd	s0,0(sp)
    800018fc:	0800                	addi	s0,sp,16
    800018fe:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    80001900:	2781                	sext.w	a5,a5
    80001902:	079e                	slli	a5,a5,0x7
  return c;
}
    80001904:	0000e517          	auipc	a0,0xe
    80001908:	10450513          	addi	a0,a0,260 # 8000fa08 <cpus>
    8000190c:	953e                	add	a0,a0,a5
    8000190e:	60a2                	ld	ra,8(sp)
    80001910:	6402                	ld	s0,0(sp)
    80001912:	0141                	addi	sp,sp,16
    80001914:	8082                	ret

0000000080001916 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc *
myproc(void)
{
    80001916:	1101                	addi	sp,sp,-32
    80001918:	ec06                	sd	ra,24(sp)
    8000191a:	e822                	sd	s0,16(sp)
    8000191c:	e426                	sd	s1,8(sp)
    8000191e:	1000                	addi	s0,sp,32
  push_off();
    80001920:	ab6ff0ef          	jal	80000bd6 <push_off>
    80001924:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80001926:	2781                	sext.w	a5,a5
    80001928:	079e                	slli	a5,a5,0x7
    8000192a:	0000e717          	auipc	a4,0xe
    8000192e:	0ae70713          	addi	a4,a4,174 # 8000f9d8 <pid_lock>
    80001932:	97ba                	add	a5,a5,a4
    80001934:	7b9c                	ld	a5,48(a5)
    80001936:	84be                	mv	s1,a5
  pop_off();
    80001938:	b22ff0ef          	jal	80000c5a <pop_off>
  return p;
}
    8000193c:	8526                	mv	a0,s1
    8000193e:	60e2                	ld	ra,24(sp)
    80001940:	6442                	ld	s0,16(sp)
    80001942:	64a2                	ld	s1,8(sp)
    80001944:	6105                	addi	sp,sp,32
    80001946:	8082                	ret

0000000080001948 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80001948:	7179                	addi	sp,sp,-48
    8000194a:	f406                	sd	ra,40(sp)
    8000194c:	f022                	sd	s0,32(sp)
    8000194e:	ec26                	sd	s1,24(sp)
    80001950:	1800                	addi	s0,sp,48
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();
    80001952:	fc5ff0ef          	jal	80001916 <myproc>
    80001956:	84aa                	mv	s1,a0

  // Still holding p->lock from scheduler.
  release(&p->lock);
    80001958:	b4aff0ef          	jal	80000ca2 <release>

  if (first) {
    8000195c:	00006797          	auipc	a5,0x6
    80001960:	f347a783          	lw	a5,-204(a5) # 80007890 <first.1>
    80001964:	cf85                	beqz	a5,8000199c <forkret+0x54>
    first = 0;
    80001966:	00006797          	auipc	a5,0x6
    8000196a:	f207a523          	sw	zero,-214(a5) # 80007890 <first.1>

    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);
    8000196e:	4505                	li	a0,1
    80001970:	4f9010ef          	jal	80003668 <fsinit>

    // We can invoke kexec() now that file system is initialized.
    // Put the return value (argc) of kexec into a0.
    p->trapframe->a0 = kexec("/init", (char *[]){"/init", 0});
    80001974:	00006797          	auipc	a5,0x6
    80001978:	84c78793          	addi	a5,a5,-1972 # 800071c0 <etext+0x1c0>
    8000197c:	fcf43823          	sd	a5,-48(s0)
    80001980:	fc043c23          	sd	zero,-40(s0)
    80001984:	fd040593          	addi	a1,s0,-48
    80001988:	853e                	mv	a0,a5
    8000198a:	77f020ef          	jal	80004908 <kexec>
    8000198e:	6cbc                	ld	a5,88(s1)
    80001990:	fba8                	sd	a0,112(a5)
    if (p->trapframe->a0 == -1) {
    80001992:	6cbc                	ld	a5,88(s1)
    80001994:	7bb8                	ld	a4,112(a5)
    80001996:	57fd                	li	a5,-1
    80001998:	02f70d63          	beq	a4,a5,800019d2 <forkret+0x8a>
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
    8000199c:	3af000ef          	jal	8000254a <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    800019a0:	68a8                	ld	a0,80(s1)
    800019a2:	8131                	srli	a0,a0,0xc
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    800019a4:	04000737          	lui	a4,0x4000
    800019a8:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    800019aa:	0732                	slli	a4,a4,0xc
    800019ac:	00004797          	auipc	a5,0x4
    800019b0:	6f078793          	addi	a5,a5,1776 # 8000609c <userret>
    800019b4:	00004697          	auipc	a3,0x4
    800019b8:	64c68693          	addi	a3,a3,1612 # 80006000 <_trampoline>
    800019bc:	8f95                	sub	a5,a5,a3
    800019be:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    800019c0:	577d                	li	a4,-1
    800019c2:	177e                	slli	a4,a4,0x3f
    800019c4:	8d59                	or	a0,a0,a4
    800019c6:	9782                	jalr	a5
}
    800019c8:	70a2                	ld	ra,40(sp)
    800019ca:	7402                	ld	s0,32(sp)
    800019cc:	64e2                	ld	s1,24(sp)
    800019ce:	6145                	addi	sp,sp,48
    800019d0:	8082                	ret
      panic("exec");
    800019d2:	00005517          	auipc	a0,0x5
    800019d6:	7f650513          	addi	a0,a0,2038 # 800071c8 <etext+0x1c8>
    800019da:	e59fe0ef          	jal	80000832 <panic>

00000000800019de <allocpid>:
{
    800019de:	1101                	addi	sp,sp,-32
    800019e0:	ec06                	sd	ra,24(sp)
    800019e2:	e822                	sd	s0,16(sp)
    800019e4:	e426                	sd	s1,8(sp)
    800019e6:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    800019e8:	0000e517          	auipc	a0,0xe
    800019ec:	ff050513          	addi	a0,a0,-16 # 8000f9d8 <pid_lock>
    800019f0:	a20ff0ef          	jal	80000c10 <acquire>
  pid = nextpid;
    800019f4:	00006797          	auipc	a5,0x6
    800019f8:	ea078793          	addi	a5,a5,-352 # 80007894 <nextpid>
    800019fc:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    800019fe:	0014871b          	addiw	a4,s1,1
    80001a02:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80001a04:	0000e517          	auipc	a0,0xe
    80001a08:	fd450513          	addi	a0,a0,-44 # 8000f9d8 <pid_lock>
    80001a0c:	a96ff0ef          	jal	80000ca2 <release>
}
    80001a10:	8526                	mv	a0,s1
    80001a12:	60e2                	ld	ra,24(sp)
    80001a14:	6442                	ld	s0,16(sp)
    80001a16:	64a2                	ld	s1,8(sp)
    80001a18:	6105                	addi	sp,sp,32
    80001a1a:	8082                	ret

0000000080001a1c <proc_pagetable>:
{
    80001a1c:	1101                	addi	sp,sp,-32
    80001a1e:	ec06                	sd	ra,24(sp)
    80001a20:	e822                	sd	s0,16(sp)
    80001a22:	e426                	sd	s1,8(sp)
    80001a24:	e04a                	sd	s2,0(sp)
    80001a26:	1000                	addi	s0,sp,32
    80001a28:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80001a2a:	fbaff0ef          	jal	800011e4 <uvmcreate>
    80001a2e:	84aa                	mv	s1,a0
  if (pagetable == 0)
    80001a30:	cd05                	beqz	a0,80001a68 <proc_pagetable+0x4c>
  if (mappages(pagetable, TRAMPOLINE, PGSIZE, (uint64)trampoline,
    80001a32:	4729                	li	a4,10
    80001a34:	00004697          	auipc	a3,0x4
    80001a38:	5cc68693          	addi	a3,a3,1484 # 80006000 <_trampoline>
    80001a3c:	6605                	lui	a2,0x1
    80001a3e:	040005b7          	lui	a1,0x4000
    80001a42:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a44:	05b2                	slli	a1,a1,0xc
    80001a46:	dfeff0ef          	jal	80001044 <mappages>
    80001a4a:	02054663          	bltz	a0,80001a76 <proc_pagetable+0x5a>
  if (mappages(pagetable, TRAPFRAME, PGSIZE, (uint64)(p->trapframe),
    80001a4e:	4719                	li	a4,6
    80001a50:	05893683          	ld	a3,88(s2)
    80001a54:	6605                	lui	a2,0x1
    80001a56:	020005b7          	lui	a1,0x2000
    80001a5a:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001a5c:	05b6                	slli	a1,a1,0xd
    80001a5e:	8526                	mv	a0,s1
    80001a60:	de4ff0ef          	jal	80001044 <mappages>
    80001a64:	00054f63          	bltz	a0,80001a82 <proc_pagetable+0x66>
}
    80001a68:	8526                	mv	a0,s1
    80001a6a:	60e2                	ld	ra,24(sp)
    80001a6c:	6442                	ld	s0,16(sp)
    80001a6e:	64a2                	ld	s1,8(sp)
    80001a70:	6902                	ld	s2,0(sp)
    80001a72:	6105                	addi	sp,sp,32
    80001a74:	8082                	ret
    uvmfree(pagetable, 0);
    80001a76:	4581                	li	a1,0
    80001a78:	8526                	mv	a0,s1
    80001a7a:	95dff0ef          	jal	800013d6 <uvmfree>
    return 0;
    80001a7e:	4481                	li	s1,0
    80001a80:	b7e5                	j	80001a68 <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a82:	4681                	li	a3,0
    80001a84:	4605                	li	a2,1
    80001a86:	040005b7          	lui	a1,0x4000
    80001a8a:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a8c:	05b2                	slli	a1,a1,0xc
    80001a8e:	8526                	mv	a0,s1
    80001a90:	f7aff0ef          	jal	8000120a <uvmunmap>
    uvmfree(pagetable, 0);
    80001a94:	4581                	li	a1,0
    80001a96:	8526                	mv	a0,s1
    80001a98:	93fff0ef          	jal	800013d6 <uvmfree>
    return 0;
    80001a9c:	b7cd                	j	80001a7e <proc_pagetable+0x62>

0000000080001a9e <proc_freepagetable>:
{
    80001a9e:	1101                	addi	sp,sp,-32
    80001aa0:	ec06                	sd	ra,24(sp)
    80001aa2:	e822                	sd	s0,16(sp)
    80001aa4:	e426                	sd	s1,8(sp)
    80001aa6:	e04a                	sd	s2,0(sp)
    80001aa8:	1000                	addi	s0,sp,32
    80001aaa:	84aa                	mv	s1,a0
    80001aac:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001aae:	4681                	li	a3,0
    80001ab0:	4605                	li	a2,1
    80001ab2:	040005b7          	lui	a1,0x4000
    80001ab6:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001ab8:	05b2                	slli	a1,a1,0xc
    80001aba:	f50ff0ef          	jal	8000120a <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001abe:	4681                	li	a3,0
    80001ac0:	4605                	li	a2,1
    80001ac2:	020005b7          	lui	a1,0x2000
    80001ac6:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001ac8:	05b6                	slli	a1,a1,0xd
    80001aca:	8526                	mv	a0,s1
    80001acc:	f3eff0ef          	jal	8000120a <uvmunmap>
  uvmfree(pagetable, sz);
    80001ad0:	85ca                	mv	a1,s2
    80001ad2:	8526                	mv	a0,s1
    80001ad4:	903ff0ef          	jal	800013d6 <uvmfree>
}
    80001ad8:	60e2                	ld	ra,24(sp)
    80001ada:	6442                	ld	s0,16(sp)
    80001adc:	64a2                	ld	s1,8(sp)
    80001ade:	6902                	ld	s2,0(sp)
    80001ae0:	6105                	addi	sp,sp,32
    80001ae2:	8082                	ret

0000000080001ae4 <freeproc>:
{
    80001ae4:	1101                	addi	sp,sp,-32
    80001ae6:	ec06                	sd	ra,24(sp)
    80001ae8:	e822                	sd	s0,16(sp)
    80001aea:	e426                	sd	s1,8(sp)
    80001aec:	1000                	addi	s0,sp,32
    80001aee:	84aa                	mv	s1,a0
  if (p->trapframe)
    80001af0:	6d28                	ld	a0,88(a0)
    80001af2:	c119                	beqz	a0,80001af8 <freeproc+0x14>
    kfree((void *)p->trapframe);
    80001af4:	f5bfe0ef          	jal	80000a4e <kfree>
  p->trapframe = 0;
    80001af8:	0404bc23          	sd	zero,88(s1)
  if (p->pagetable)
    80001afc:	68a8                	ld	a0,80(s1)
    80001afe:	c501                	beqz	a0,80001b06 <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001b00:	64ac                	ld	a1,72(s1)
    80001b02:	f9dff0ef          	jal	80001a9e <proc_freepagetable>
  p->pagetable = 0;
    80001b06:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001b0a:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001b0e:	0204a823          	sw	zero,48(s1)
  p->name[0] = 0;
    80001b12:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001b16:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001b1a:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001b1e:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001b22:	0004ac23          	sw	zero,24(s1)
}
    80001b26:	60e2                	ld	ra,24(sp)
    80001b28:	6442                	ld	s0,16(sp)
    80001b2a:	64a2                	ld	s1,8(sp)
    80001b2c:	6105                	addi	sp,sp,32
    80001b2e:	8082                	ret

0000000080001b30 <allocproc>:
{
    80001b30:	1101                	addi	sp,sp,-32
    80001b32:	ec06                	sd	ra,24(sp)
    80001b34:	e822                	sd	s0,16(sp)
    80001b36:	e426                	sd	s1,8(sp)
    80001b38:	e04a                	sd	s2,0(sp)
    80001b3a:	1000                	addi	s0,sp,32
  for (p = proc; p < &proc[NPROC]; p++) {
    80001b3c:	0000e497          	auipc	s1,0xe
    80001b40:	2cc48493          	addi	s1,s1,716 # 8000fe08 <proc>
    80001b44:	00014917          	auipc	s2,0x14
    80001b48:	ec490913          	addi	s2,s2,-316 # 80015a08 <tickslock>
    acquire(&p->lock);
    80001b4c:	8526                	mv	a0,s1
    80001b4e:	8c2ff0ef          	jal	80000c10 <acquire>
    if (p->state == UNUSED) {
    80001b52:	4c9c                	lw	a5,24(s1)
    80001b54:	cb91                	beqz	a5,80001b68 <allocproc+0x38>
      release(&p->lock);
    80001b56:	8526                	mv	a0,s1
    80001b58:	94aff0ef          	jal	80000ca2 <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    80001b5c:	17048493          	addi	s1,s1,368
    80001b60:	ff2496e3          	bne	s1,s2,80001b4c <allocproc+0x1c>
  return 0;
    80001b64:	4481                	li	s1,0
    80001b66:	a0a9                	j	80001bb0 <allocproc+0x80>
  p->pid = allocpid();
    80001b68:	e77ff0ef          	jal	800019de <allocpid>
    80001b6c:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001b6e:	4785                	li	a5,1
    80001b70:	cc9c                	sw	a5,24(s1)
  p->priority =50; // default priority for new processes
    80001b72:	03200793          	li	a5,50
    80001b76:	16f4a423          	sw	a5,360(s1)
  if ((p->trapframe = (struct trapframe *)kalloc()) == 0) {
    80001b7a:	fbdfe0ef          	jal	80000b36 <kalloc>
    80001b7e:	892a                	mv	s2,a0
    80001b80:	eca8                	sd	a0,88(s1)
    80001b82:	cd15                	beqz	a0,80001bbe <allocproc+0x8e>
  p->pagetable = proc_pagetable(p);
    80001b84:	8526                	mv	a0,s1
    80001b86:	e97ff0ef          	jal	80001a1c <proc_pagetable>
    80001b8a:	892a                	mv	s2,a0
    80001b8c:	e8a8                	sd	a0,80(s1)
  if (p->pagetable == 0) {
    80001b8e:	c121                	beqz	a0,80001bce <allocproc+0x9e>
  memset(&p->context, 0, sizeof(p->context));
    80001b90:	07000613          	li	a2,112
    80001b94:	4581                	li	a1,0
    80001b96:	06048513          	addi	a0,s1,96
    80001b9a:	94eff0ef          	jal	80000ce8 <memset>
  p->context.ra = (uint64)forkret;
    80001b9e:	00000797          	auipc	a5,0x0
    80001ba2:	daa78793          	addi	a5,a5,-598 # 80001948 <forkret>
    80001ba6:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001ba8:	60bc                	ld	a5,64(s1)
    80001baa:	6705                	lui	a4,0x1
    80001bac:	97ba                	add	a5,a5,a4
    80001bae:	f4bc                	sd	a5,104(s1)
}
    80001bb0:	8526                	mv	a0,s1
    80001bb2:	60e2                	ld	ra,24(sp)
    80001bb4:	6442                	ld	s0,16(sp)
    80001bb6:	64a2                	ld	s1,8(sp)
    80001bb8:	6902                	ld	s2,0(sp)
    80001bba:	6105                	addi	sp,sp,32
    80001bbc:	8082                	ret
    freeproc(p);
    80001bbe:	8526                	mv	a0,s1
    80001bc0:	f25ff0ef          	jal	80001ae4 <freeproc>
    release(&p->lock);
    80001bc4:	8526                	mv	a0,s1
    80001bc6:	8dcff0ef          	jal	80000ca2 <release>
    return 0;
    80001bca:	84ca                	mv	s1,s2
    80001bcc:	b7d5                	j	80001bb0 <allocproc+0x80>
    freeproc(p);
    80001bce:	8526                	mv	a0,s1
    80001bd0:	f15ff0ef          	jal	80001ae4 <freeproc>
    release(&p->lock);
    80001bd4:	8526                	mv	a0,s1
    80001bd6:	8ccff0ef          	jal	80000ca2 <release>
    return 0;
    80001bda:	84ca                	mv	s1,s2
    80001bdc:	bfd1                	j	80001bb0 <allocproc+0x80>

0000000080001bde <userinit>:
{
    80001bde:	1101                	addi	sp,sp,-32
    80001be0:	ec06                	sd	ra,24(sp)
    80001be2:	e822                	sd	s0,16(sp)
    80001be4:	e426                	sd	s1,8(sp)
    80001be6:	1000                	addi	s0,sp,32
  p = allocproc();
    80001be8:	f49ff0ef          	jal	80001b30 <allocproc>
    80001bec:	84aa                	mv	s1,a0
  initproc = p;
    80001bee:	00006797          	auipc	a5,0x6
    80001bf2:	cca7bd23          	sd	a0,-806(a5) # 800078c8 <initproc>
  p->cwd = namei("/");
    80001bf6:	00005517          	auipc	a0,0x5
    80001bfa:	5da50513          	addi	a0,a0,1498 # 800071d0 <etext+0x1d0>
    80001bfe:	7d3010ef          	jal	80003bd0 <namei>
    80001c02:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001c06:	478d                	li	a5,3
    80001c08:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001c0a:	8526                	mv	a0,s1
    80001c0c:	896ff0ef          	jal	80000ca2 <release>
}
    80001c10:	60e2                	ld	ra,24(sp)
    80001c12:	6442                	ld	s0,16(sp)
    80001c14:	64a2                	ld	s1,8(sp)
    80001c16:	6105                	addi	sp,sp,32
    80001c18:	8082                	ret

0000000080001c1a <growproc>:
{
    80001c1a:	1101                	addi	sp,sp,-32
    80001c1c:	ec06                	sd	ra,24(sp)
    80001c1e:	e822                	sd	s0,16(sp)
    80001c20:	e426                	sd	s1,8(sp)
    80001c22:	e04a                	sd	s2,0(sp)
    80001c24:	1000                	addi	s0,sp,32
    80001c26:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001c28:	cefff0ef          	jal	80001916 <myproc>
    80001c2c:	892a                	mv	s2,a0
  sz = p->sz;
    80001c2e:	652c                	ld	a1,72(a0)
  if (n > 0) {
    80001c30:	02905b63          	blez	s1,80001c66 <growproc+0x4c>
    if (sz + n > TRAPFRAME) {
    80001c34:	00b48633          	add	a2,s1,a1
    80001c38:	020007b7          	lui	a5,0x2000
    80001c3c:	17fd                	addi	a5,a5,-1 # 1ffffff <_entry-0x7e000001>
    80001c3e:	07b6                	slli	a5,a5,0xd
    80001c40:	02c7e163          	bltu	a5,a2,80001c62 <growproc+0x48>
    if ((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001c44:	4691                	li	a3,4
    80001c46:	6928                	ld	a0,80(a0)
    80001c48:	e92ff0ef          	jal	800012da <uvmalloc>
    80001c4c:	85aa                	mv	a1,a0
    80001c4e:	c911                	beqz	a0,80001c62 <growproc+0x48>
  p->sz = sz;
    80001c50:	04b93423          	sd	a1,72(s2)
  return 0;
    80001c54:	4501                	li	a0,0
}
    80001c56:	60e2                	ld	ra,24(sp)
    80001c58:	6442                	ld	s0,16(sp)
    80001c5a:	64a2                	ld	s1,8(sp)
    80001c5c:	6902                	ld	s2,0(sp)
    80001c5e:	6105                	addi	sp,sp,32
    80001c60:	8082                	ret
      return -1;
    80001c62:	557d                	li	a0,-1
    80001c64:	bfcd                	j	80001c56 <growproc+0x3c>
  } else if (n < 0) {
    80001c66:	fe04d5e3          	bgez	s1,80001c50 <growproc+0x36>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001c6a:	00b48633          	add	a2,s1,a1
    80001c6e:	6928                	ld	a0,80(a0)
    80001c70:	e24ff0ef          	jal	80001294 <uvmdealloc>
    80001c74:	85aa                	mv	a1,a0
    80001c76:	bfe9                	j	80001c50 <growproc+0x36>

0000000080001c78 <kfork>:
{
    80001c78:	7139                	addi	sp,sp,-64
    80001c7a:	fc06                	sd	ra,56(sp)
    80001c7c:	f822                	sd	s0,48(sp)
    80001c7e:	f426                	sd	s1,40(sp)
    80001c80:	e456                	sd	s5,8(sp)
    80001c82:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001c84:	c93ff0ef          	jal	80001916 <myproc>
    80001c88:	8aaa                	mv	s5,a0
  if ((np = allocproc()) == 0) {
    80001c8a:	ea7ff0ef          	jal	80001b30 <allocproc>
    80001c8e:	c92d                	beqz	a0,80001d00 <kfork+0x88>
    80001c90:	e852                	sd	s4,16(sp)
    80001c92:	8a2a                	mv	s4,a0
  if (uvmcopy(p->pagetable, np->pagetable, p->sz) < 0) {
    80001c94:	048ab603          	ld	a2,72(s5)
    80001c98:	692c                	ld	a1,80(a0)
    80001c9a:	050ab503          	ld	a0,80(s5)
    80001c9e:	f6aff0ef          	jal	80001408 <uvmcopy>
    80001ca2:	04054863          	bltz	a0,80001cf2 <kfork+0x7a>
    80001ca6:	f04a                	sd	s2,32(sp)
    80001ca8:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001caa:	048ab783          	ld	a5,72(s5)
    80001cae:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001cb2:	058ab683          	ld	a3,88(s5)
    80001cb6:	87b6                	mv	a5,a3
    80001cb8:	058a3703          	ld	a4,88(s4)
    80001cbc:	12068693          	addi	a3,a3,288
    80001cc0:	6388                	ld	a0,0(a5)
    80001cc2:	678c                	ld	a1,8(a5)
    80001cc4:	6b90                	ld	a2,16(a5)
    80001cc6:	e308                	sd	a0,0(a4)
    80001cc8:	e70c                	sd	a1,8(a4)
    80001cca:	eb10                	sd	a2,16(a4)
    80001ccc:	6f90                	ld	a2,24(a5)
    80001cce:	ef10                	sd	a2,24(a4)
    80001cd0:	02078793          	addi	a5,a5,32
    80001cd4:	02070713          	addi	a4,a4,32 # 1020 <_entry-0x7fffefe0>
    80001cd8:	fed794e3          	bne	a5,a3,80001cc0 <kfork+0x48>
  np->trapframe->a0 = 0;
    80001cdc:	058a3783          	ld	a5,88(s4)
    80001ce0:	0607b823          	sd	zero,112(a5)
  for (i = 0; i < NOFILE; i++)
    80001ce4:	0d0a8493          	addi	s1,s5,208
    80001ce8:	0d0a0913          	addi	s2,s4,208
    80001cec:	150a8993          	addi	s3,s5,336
    80001cf0:	a831                	j	80001d0c <kfork+0x94>
    freeproc(np);
    80001cf2:	8552                	mv	a0,s4
    80001cf4:	df1ff0ef          	jal	80001ae4 <freeproc>
    release(&np->lock);
    80001cf8:	8552                	mv	a0,s4
    80001cfa:	fa9fe0ef          	jal	80000ca2 <release>
    return -1;
    80001cfe:	6a42                	ld	s4,16(sp)
    return -1;
    80001d00:	54fd                	li	s1,-1
    80001d02:	a885                	j	80001d72 <kfork+0xfa>
  for (i = 0; i < NOFILE; i++)
    80001d04:	04a1                	addi	s1,s1,8
    80001d06:	0921                	addi	s2,s2,8
    80001d08:	01348963          	beq	s1,s3,80001d1a <kfork+0xa2>
    if (p->ofile[i])
    80001d0c:	6088                	ld	a0,0(s1)
    80001d0e:	d97d                	beqz	a0,80001d04 <kfork+0x8c>
      np->ofile[i] = filedup(p->ofile[i]);
    80001d10:	51e020ef          	jal	8000422e <filedup>
    80001d14:	00a93023          	sd	a0,0(s2)
    80001d18:	b7f5                	j	80001d04 <kfork+0x8c>
  np->cwd = idup(p->cwd);
    80001d1a:	150ab503          	ld	a0,336(s5)
    80001d1e:	5d8010ef          	jal	800032f6 <idup>
    80001d22:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001d26:	4641                	li	a2,16
    80001d28:	158a8593          	addi	a1,s5,344
    80001d2c:	158a0513          	addi	a0,s4,344
    80001d30:	902ff0ef          	jal	80000e32 <safestrcpy>
  pid = np->pid;
    80001d34:	030a2483          	lw	s1,48(s4)
  release(&np->lock);
    80001d38:	8552                	mv	a0,s4
    80001d3a:	f69fe0ef          	jal	80000ca2 <release>
  acquire(&wait_lock);
    80001d3e:	0000e517          	auipc	a0,0xe
    80001d42:	cb250513          	addi	a0,a0,-846 # 8000f9f0 <wait_lock>
    80001d46:	ecbfe0ef          	jal	80000c10 <acquire>
  np->parent = p;
    80001d4a:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001d4e:	0000e517          	auipc	a0,0xe
    80001d52:	ca250513          	addi	a0,a0,-862 # 8000f9f0 <wait_lock>
    80001d56:	f4dfe0ef          	jal	80000ca2 <release>
  acquire(&np->lock);
    80001d5a:	8552                	mv	a0,s4
    80001d5c:	eb5fe0ef          	jal	80000c10 <acquire>
  np->state = RUNNABLE;
    80001d60:	478d                	li	a5,3
    80001d62:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001d66:	8552                	mv	a0,s4
    80001d68:	f3bfe0ef          	jal	80000ca2 <release>
    80001d6c:	7902                	ld	s2,32(sp)
    80001d6e:	69e2                	ld	s3,24(sp)
    80001d70:	6a42                	ld	s4,16(sp)
}
    80001d72:	8526                	mv	a0,s1
    80001d74:	70e2                	ld	ra,56(sp)
    80001d76:	7442                	ld	s0,48(sp)
    80001d78:	74a2                	ld	s1,40(sp)
    80001d7a:	6aa2                	ld	s5,8(sp)
    80001d7c:	6121                	addi	sp,sp,64
    80001d7e:	8082                	ret

0000000080001d80 <scheduler>:
{
    80001d80:	7119                	addi	sp,sp,-128
    80001d82:	fc86                	sd	ra,120(sp)
    80001d84:	f8a2                	sd	s0,112(sp)
    80001d86:	f4a6                	sd	s1,104(sp)
    80001d88:	f0ca                	sd	s2,96(sp)
    80001d8a:	ecce                	sd	s3,88(sp)
    80001d8c:	e8d2                	sd	s4,80(sp)
    80001d8e:	e4d6                	sd	s5,72(sp)
    80001d90:	e0da                	sd	s6,64(sp)
    80001d92:	fc5e                	sd	s7,56(sp)
    80001d94:	f862                	sd	s8,48(sp)
    80001d96:	f466                	sd	s9,40(sp)
    80001d98:	f06a                	sd	s10,32(sp)
    80001d9a:	ec6e                	sd	s11,24(sp)
    80001d9c:	0100                	addi	s0,sp,128
    80001d9e:	8792                	mv	a5,tp
  int id = r_tp();
    80001da0:	2781                	sext.w	a5,a5
    80001da2:	f8f43023          	sd	a5,-128(s0)
  c->proc = 0;
    80001da6:	00779713          	slli	a4,a5,0x7
    80001daa:	0000e797          	auipc	a5,0xe
    80001dae:	c2e78793          	addi	a5,a5,-978 # 8000f9d8 <pid_lock>
    80001db2:	97ba                	add	a5,a5,a4
    80001db4:	0207b823          	sd	zero,48(a5)
        swtch(&c->context, &best_p->context);
    80001db8:	0000e797          	auipc	a5,0xe
    80001dbc:	c5878793          	addi	a5,a5,-936 # 8000fa10 <cpus+0x8>
    80001dc0:	97ba                	add	a5,a5,a4
    80001dc2:	f8f43423          	sd	a5,-120(s0)
      p = &proc[idx];
    80001dc6:	0000ea17          	auipc	s4,0xe
    80001dca:	042a0a13          	addi	s4,s4,66 # 8000fe08 <proc>
    for(int i = 0; i < NPROC; i++) {
    80001dce:	04000c93          	li	s9,64
    80001dd2:	a0dd                	j	80001eb8 <scheduler+0x138>
        if(p->priority < highest_priority) {
    80001dd4:	16892783          	lw	a5,360(s2)
    80001dd8:	05a7da63          	bge	a5,s10,80001e2c <scheduler+0xac>
          if(best_p && best_p != p) {
    80001ddc:	016037b3          	snez	a5,s6
    80001de0:	41690733          	sub	a4,s2,s6
    80001de4:	00e03733          	snez	a4,a4
    80001de8:	8ff9                	and	a5,a5,a4
    80001dea:	eba5                	bnez	a5,80001e5a <scheduler+0xda>
          highest_priority = p->priority;
    80001dec:	035487b3          	mul	a5,s1,s5
    80001df0:	97d2                	add	a5,a5,s4
    80001df2:	1687ad03          	lw	s10,360(a5)
          best_index = idx;
    80001df6:	8da6                	mv	s11,s1
          best_p = p;
    80001df8:	8b4a                	mv	s6,s2
    for(int i = 0; i < NPROC; i++) {
    80001dfa:	2985                	addiw	s3,s3,1
    80001dfc:	07998363          	beq	s3,s9,80001e62 <scheduler+0xe2>
      int idx = (last_chosen_index + i) % NPROC;
    80001e00:	000c2483          	lw	s1,0(s8) # fffffffffffff000 <end+0xffffffff7ffde218>
    80001e04:	013484bb          	addw	s1,s1,s3
    80001e08:	41f4d79b          	sraiw	a5,s1,0x1f
    80001e0c:	01a7d79b          	srliw	a5,a5,0x1a
    80001e10:	9cbd                	addw	s1,s1,a5
    80001e12:	03f4f493          	andi	s1,s1,63
    80001e16:	9c9d                	subw	s1,s1,a5
      p = &proc[idx];
    80001e18:	03548933          	mul	s2,s1,s5
    80001e1c:	9952                	add	s2,s2,s4
      acquire(&p->lock);
    80001e1e:	854a                	mv	a0,s2
    80001e20:	df1fe0ef          	jal	80000c10 <acquire>
      if(p->state == RUNNABLE) {
    80001e24:	01892783          	lw	a5,24(s2)
    80001e28:	fb7786e3          	beq	a5,s7,80001dd4 <scheduler+0x54>
      if (best_p != p) {
    80001e2c:	fd6907e3          	beq	s2,s6,80001dfa <scheduler+0x7a>
        release(&p->lock);
    80001e30:	854a                	mv	a0,s2
    80001e32:	e71fe0ef          	jal	80000ca2 <release>
    for(int i = 0; i < NPROC; i++) {
    80001e36:	2985                	addiw	s3,s3,1
    80001e38:	fd9994e3          	bne	s3,s9,80001e00 <scheduler+0x80>
    if(best_p) {
    80001e3c:	020b1363          	bnez	s6,80001e62 <scheduler+0xe2>
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    80001e40:	10016073          	csrsi	sstatus,2
    for(int i = 0; i < NPROC; i++) {
    80001e44:	4981                	li	s3,0
    int best_index = 0;
    80001e46:	4d81                	li	s11,0
    int highest_priority = 201;
    80001e48:	0c900d13          	li	s10,201
    struct proc *best_p = 0;
    80001e4c:	4b01                	li	s6,0
      int idx = (last_chosen_index + i) % NPROC;
    80001e4e:	00006c17          	auipc	s8,0x6
    80001e52:	a72c0c13          	addi	s8,s8,-1422 # 800078c0 <last_chosen_index.2>
      if(p->state == RUNNABLE) {
    80001e56:	4b8d                	li	s7,3
    80001e58:	b765                	j	80001e00 <scheduler+0x80>
            release(&best_p->lock);
    80001e5a:	855a                	mv	a0,s6
    80001e5c:	e47fe0ef          	jal	80000ca2 <release>
    80001e60:	b771                	j	80001dec <scheduler+0x6c>
      if(best_p->state == RUNNABLE) {
    80001e62:	018b2703          	lw	a4,24(s6)
    80001e66:	478d                	li	a5,3
    80001e68:	04f71563          	bne	a4,a5,80001eb2 <scheduler+0x132>
        last_chosen_index = (best_index + 1) % NPROC;
    80001e6c:	2d85                	addiw	s11,s11,1
    80001e6e:	41fdd71b          	sraiw	a4,s11,0x1f
    80001e72:	01a7571b          	srliw	a4,a4,0x1a
    80001e76:	01b707bb          	addw	a5,a4,s11
    80001e7a:	03f7f793          	andi	a5,a5,63
    80001e7e:	9f99                	subw	a5,a5,a4
    80001e80:	00006717          	auipc	a4,0x6
    80001e84:	a4f72023          	sw	a5,-1472(a4) # 800078c0 <last_chosen_index.2>
        best_p->state = RUNNING;
    80001e88:	4791                	li	a5,4
    80001e8a:	00fb2c23          	sw	a5,24(s6)
        c->proc = best_p;
    80001e8e:	f8043783          	ld	a5,-128(s0)
    80001e92:	079e                	slli	a5,a5,0x7
    80001e94:	0000e497          	auipc	s1,0xe
    80001e98:	b4448493          	addi	s1,s1,-1212 # 8000f9d8 <pid_lock>
    80001e9c:	94be                	add	s1,s1,a5
    80001e9e:	0364b823          	sd	s6,48(s1)
        swtch(&c->context, &best_p->context);
    80001ea2:	060b0593          	addi	a1,s6,96
    80001ea6:	f8843503          	ld	a0,-120(s0)
    80001eaa:	5f6000ef          	jal	800024a0 <swtch>
        c->proc = 0;
    80001eae:	0204b823          	sd	zero,48(s1)
      release(&best_p->lock);
    80001eb2:	855a                	mv	a0,s6
    80001eb4:	deffe0ef          	jal	80000ca2 <release>
      p = &proc[idx];
    80001eb8:	17000a93          	li	s5,368
    80001ebc:	b751                	j	80001e40 <scheduler+0xc0>

0000000080001ebe <sched>:
{
    80001ebe:	7179                	addi	sp,sp,-48
    80001ec0:	f406                	sd	ra,40(sp)
    80001ec2:	f022                	sd	s0,32(sp)
    80001ec4:	ec26                	sd	s1,24(sp)
    80001ec6:	e84a                	sd	s2,16(sp)
    80001ec8:	e44e                	sd	s3,8(sp)
    80001eca:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001ecc:	a4bff0ef          	jal	80001916 <myproc>
    80001ed0:	84aa                	mv	s1,a0
  if (!holding(&p->lock))
    80001ed2:	cd9fe0ef          	jal	80000baa <holding>
    80001ed6:	c92d                	beqz	a0,80001f48 <sched+0x8a>
  asm volatile("mv %0, tp" : "=r"(x));
    80001ed8:	8792                	mv	a5,tp
  if (mycpu()->noff != 1)
    80001eda:	2781                	sext.w	a5,a5
    80001edc:	079e                	slli	a5,a5,0x7
    80001ede:	0000e717          	auipc	a4,0xe
    80001ee2:	afa70713          	addi	a4,a4,-1286 # 8000f9d8 <pid_lock>
    80001ee6:	97ba                	add	a5,a5,a4
    80001ee8:	0a87a703          	lw	a4,168(a5)
    80001eec:	4785                	li	a5,1
    80001eee:	06f71363          	bne	a4,a5,80001f54 <sched+0x96>
  if (p->state == RUNNING)
    80001ef2:	4c98                	lw	a4,24(s1)
    80001ef4:	4791                	li	a5,4
    80001ef6:	06f70563          	beq	a4,a5,80001f60 <sched+0xa2>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80001efa:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001efe:	8b89                	andi	a5,a5,2
  if (intr_get())
    80001f00:	e7b5                	bnez	a5,80001f6c <sched+0xae>
  asm volatile("mv %0, tp" : "=r"(x));
    80001f02:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80001f04:	0000e917          	auipc	s2,0xe
    80001f08:	ad490913          	addi	s2,s2,-1324 # 8000f9d8 <pid_lock>
    80001f0c:	2781                	sext.w	a5,a5
    80001f0e:	079e                	slli	a5,a5,0x7
    80001f10:	97ca                	add	a5,a5,s2
    80001f12:	0ac7a983          	lw	s3,172(a5)
    80001f16:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001f18:	2781                	sext.w	a5,a5
    80001f1a:	079e                	slli	a5,a5,0x7
    80001f1c:	0000e597          	auipc	a1,0xe
    80001f20:	af458593          	addi	a1,a1,-1292 # 8000fa10 <cpus+0x8>
    80001f24:	95be                	add	a1,a1,a5
    80001f26:	06048513          	addi	a0,s1,96
    80001f2a:	576000ef          	jal	800024a0 <swtch>
    80001f2e:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001f30:	2781                	sext.w	a5,a5
    80001f32:	079e                	slli	a5,a5,0x7
    80001f34:	993e                	add	s2,s2,a5
    80001f36:	0b392623          	sw	s3,172(s2)
}
    80001f3a:	70a2                	ld	ra,40(sp)
    80001f3c:	7402                	ld	s0,32(sp)
    80001f3e:	64e2                	ld	s1,24(sp)
    80001f40:	6942                	ld	s2,16(sp)
    80001f42:	69a2                	ld	s3,8(sp)
    80001f44:	6145                	addi	sp,sp,48
    80001f46:	8082                	ret
    panic("sched p->lock");
    80001f48:	00005517          	auipc	a0,0x5
    80001f4c:	29050513          	addi	a0,a0,656 # 800071d8 <etext+0x1d8>
    80001f50:	8e3fe0ef          	jal	80000832 <panic>
    panic("sched locks");
    80001f54:	00005517          	auipc	a0,0x5
    80001f58:	29450513          	addi	a0,a0,660 # 800071e8 <etext+0x1e8>
    80001f5c:	8d7fe0ef          	jal	80000832 <panic>
    panic("sched RUNNING");
    80001f60:	00005517          	auipc	a0,0x5
    80001f64:	29850513          	addi	a0,a0,664 # 800071f8 <etext+0x1f8>
    80001f68:	8cbfe0ef          	jal	80000832 <panic>
    panic("sched interruptible");
    80001f6c:	00005517          	auipc	a0,0x5
    80001f70:	29c50513          	addi	a0,a0,668 # 80007208 <etext+0x208>
    80001f74:	8bffe0ef          	jal	80000832 <panic>

0000000080001f78 <yield>:
{
    80001f78:	1101                	addi	sp,sp,-32
    80001f7a:	ec06                	sd	ra,24(sp)
    80001f7c:	e822                	sd	s0,16(sp)
    80001f7e:	e426                	sd	s1,8(sp)
    80001f80:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001f82:	995ff0ef          	jal	80001916 <myproc>
    80001f86:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001f88:	c89fe0ef          	jal	80000c10 <acquire>
  p->state = RUNNABLE;
    80001f8c:	478d                	li	a5,3
    80001f8e:	cc9c                	sw	a5,24(s1)
  sched();
    80001f90:	f2fff0ef          	jal	80001ebe <sched>
  release(&p->lock);
    80001f94:	8526                	mv	a0,s1
    80001f96:	d0dfe0ef          	jal	80000ca2 <release>
}
    80001f9a:	60e2                	ld	ra,24(sp)
    80001f9c:	6442                	ld	s0,16(sp)
    80001f9e:	64a2                	ld	s1,8(sp)
    80001fa0:	6105                	addi	sp,sp,32
    80001fa2:	8082                	ret

0000000080001fa4 <sleep_prepare>:

// Register current process as waiting for wakeups on chan.
void
sleep_prepare(void *chan)
{
    80001fa4:	1101                	addi	sp,sp,-32
    80001fa6:	ec06                	sd	ra,24(sp)
    80001fa8:	e822                	sd	s0,16(sp)
    80001faa:	e426                	sd	s1,8(sp)
    80001fac:	e04a                	sd	s2,0(sp)
    80001fae:	1000                	addi	s0,sp,32
    80001fb0:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001fb2:	965ff0ef          	jal	80001916 <myproc>
    80001fb6:	892a                	mv	s2,a0

  acquire(&p->lock);
    80001fb8:	c59fe0ef          	jal	80000c10 <acquire>
  if (chan == 0)
    80001fbc:	cc81                	beqz	s1,80001fd4 <sleep_prepare+0x30>
    panic("sleep_prepare: zero chan");
  p->chan = chan;
    80001fbe:	02993023          	sd	s1,32(s2)
  release(&p->lock);
    80001fc2:	854a                	mv	a0,s2
    80001fc4:	cdffe0ef          	jal	80000ca2 <release>
}
    80001fc8:	60e2                	ld	ra,24(sp)
    80001fca:	6442                	ld	s0,16(sp)
    80001fcc:	64a2                	ld	s1,8(sp)
    80001fce:	6902                	ld	s2,0(sp)
    80001fd0:	6105                	addi	sp,sp,32
    80001fd2:	8082                	ret
    panic("sleep_prepare: zero chan");
    80001fd4:	00005517          	auipc	a0,0x5
    80001fd8:	24c50513          	addi	a0,a0,588 # 80007220 <etext+0x220>
    80001fdc:	857fe0ef          	jal	80000832 <panic>

0000000080001fe0 <sleep>:
// If the channel registered by sleep_prepare() has been woken up in
// the meantime, do not go to sleep, and instead return immediately.

void
sleep(void *chan, struct spinlock *lk)
{
    80001fe0:	7179                	addi	sp,sp,-48
    80001fe2:	f406                	sd	ra,40(sp)
    80001fe4:	f022                	sd	s0,32(sp)
    80001fe6:	ec26                	sd	s1,24(sp)
    80001fe8:	e84a                	sd	s2,16(sp)
    80001fea:	e44e                	sd	s3,8(sp)
    80001fec:	1800                	addi	s0,sp,48
    80001fee:	89aa                	mv	s3,a0
    80001ff0:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001ff2:	925ff0ef          	jal	80001916 <myproc>
    80001ff6:	84aa                	mv	s1,a0

  // Must acquire p->lock before releasing lk to prevent missing a wakeup
  acquire(&p->lock); 
    80001ff8:	c19fe0ef          	jal	80000c10 <acquire>
  release(lk);
    80001ffc:	854a                	mv	a0,s2
    80001ffe:	ca5fe0ef          	jal	80000ca2 <release>

  // Go to sleep safely
  p->chan = chan;
    80002002:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    80002006:	4789                	li	a5,2
    80002008:	cc9c                	sw	a5,24(s1)

  sched();
    8000200a:	eb5ff0ef          	jal	80001ebe <sched>

  // Re-acquire original states upon waking up
  p->chan = 0;
    8000200e:	0204b023          	sd	zero,32(s1)
  release(&p->lock);
    80002012:	8526                	mv	a0,s1
    80002014:	c8ffe0ef          	jal	80000ca2 <release>
  acquire(lk);
    80002018:	854a                	mv	a0,s2
    8000201a:	bf7fe0ef          	jal	80000c10 <acquire>
}
    8000201e:	70a2                	ld	ra,40(sp)
    80002020:	7402                	ld	s0,32(sp)
    80002022:	64e2                	ld	s1,24(sp)
    80002024:	6942                	ld	s2,16(sp)
    80002026:	69a2                	ld	s3,8(sp)
    80002028:	6145                	addi	sp,sp,48
    8000202a:	8082                	ret

000000008000202c <wakeup>:

// Wake up all processes sleeping on channel chan.

void
wakeup(void *chan)
{
    8000202c:	7139                	addi	sp,sp,-64
    8000202e:	fc06                	sd	ra,56(sp)
    80002030:	f822                	sd	s0,48(sp)
    80002032:	f426                	sd	s1,40(sp)
    80002034:	f04a                	sd	s2,32(sp)
    80002036:	ec4e                	sd	s3,24(sp)
    80002038:	e852                	sd	s4,16(sp)
    8000203a:	e456                	sd	s5,8(sp)
    8000203c:	0080                	addi	s0,sp,64
    8000203e:	8a2a                	mv	s4,a0
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    80002040:	0000e497          	auipc	s1,0xe
    80002044:	dc848493          	addi	s1,s1,-568 # 8000fe08 <proc>
      acquire(&p->lock);
      if (p->state == SLEEPING && p->chan == chan) {
    80002048:	4909                	li	s2,2
          p->priority = 0;
        }
        

        // Move back to scheduler pool
        p->state = RUNNABLE;
    8000204a:	4a8d                	li	s5,3
  for (p = proc; p < &proc[NPROC]; p++) {
    8000204c:	00014997          	auipc	s3,0x14
    80002050:	9bc98993          	addi	s3,s3,-1604 # 80015a08 <tickslock>
    80002054:	a829                	j	8000206e <wakeup+0x42>
        if (p->priority >= 2) {
    80002056:	3779                	addiw	a4,a4,-2
    80002058:	16e4a423          	sw	a4,360(s1)
        p->state = RUNNABLE;
    8000205c:	0154ac23          	sw	s5,24(s1)
      }
      release(&p->lock);
    80002060:	8526                	mv	a0,s1
    80002062:	c41fe0ef          	jal	80000ca2 <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    80002066:	17048493          	addi	s1,s1,368
    8000206a:	03348563          	beq	s1,s3,80002094 <wakeup+0x68>
      acquire(&p->lock);
    8000206e:	8526                	mv	a0,s1
    80002070:	ba1fe0ef          	jal	80000c10 <acquire>
      if (p->state == SLEEPING && p->chan == chan) {
    80002074:	4c9c                	lw	a5,24(s1)
    80002076:	ff2795e3          	bne	a5,s2,80002060 <wakeup+0x34>
    8000207a:	709c                	ld	a5,32(s1)
    8000207c:	ff4792e3          	bne	a5,s4,80002060 <wakeup+0x34>
        p->chan = 0;
    80002080:	0204b023          	sd	zero,32(s1)
        if (p->priority >= 2) {
    80002084:	1684a783          	lw	a5,360(s1)
    80002088:	873e                	mv	a4,a5
    8000208a:	2781                	sext.w	a5,a5
    8000208c:	fd27d5e3          	bge	a5,s2,80002056 <wakeup+0x2a>
    80002090:	4709                	li	a4,2
    80002092:	b7d1                	j	80002056 <wakeup+0x2a>
    
  }
}
    80002094:	70e2                	ld	ra,56(sp)
    80002096:	7442                	ld	s0,48(sp)
    80002098:	74a2                	ld	s1,40(sp)
    8000209a:	7902                	ld	s2,32(sp)
    8000209c:	69e2                	ld	s3,24(sp)
    8000209e:	6a42                	ld	s4,16(sp)
    800020a0:	6aa2                	ld	s5,8(sp)
    800020a2:	6121                	addi	sp,sp,64
    800020a4:	8082                	ret

00000000800020a6 <reparent>:
{
    800020a6:	7179                	addi	sp,sp,-48
    800020a8:	f406                	sd	ra,40(sp)
    800020aa:	f022                	sd	s0,32(sp)
    800020ac:	ec26                	sd	s1,24(sp)
    800020ae:	e84a                	sd	s2,16(sp)
    800020b0:	e44e                	sd	s3,8(sp)
    800020b2:	e052                	sd	s4,0(sp)
    800020b4:	1800                	addi	s0,sp,48
    800020b6:	892a                	mv	s2,a0
  for (pp = proc; pp < &proc[NPROC]; pp++) {
    800020b8:	0000e497          	auipc	s1,0xe
    800020bc:	d5048493          	addi	s1,s1,-688 # 8000fe08 <proc>
      pp->parent = initproc;
    800020c0:	00006a17          	auipc	s4,0x6
    800020c4:	808a0a13          	addi	s4,s4,-2040 # 800078c8 <initproc>
  for (pp = proc; pp < &proc[NPROC]; pp++) {
    800020c8:	00014997          	auipc	s3,0x14
    800020cc:	94098993          	addi	s3,s3,-1728 # 80015a08 <tickslock>
    800020d0:	a029                	j	800020da <reparent+0x34>
    800020d2:	17048493          	addi	s1,s1,368
    800020d6:	01348b63          	beq	s1,s3,800020ec <reparent+0x46>
    if (pp->parent == p) {
    800020da:	7c9c                	ld	a5,56(s1)
    800020dc:	ff279be3          	bne	a5,s2,800020d2 <reparent+0x2c>
      pp->parent = initproc;
    800020e0:	000a3503          	ld	a0,0(s4)
    800020e4:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    800020e6:	f47ff0ef          	jal	8000202c <wakeup>
    800020ea:	b7e5                	j	800020d2 <reparent+0x2c>
}
    800020ec:	70a2                	ld	ra,40(sp)
    800020ee:	7402                	ld	s0,32(sp)
    800020f0:	64e2                	ld	s1,24(sp)
    800020f2:	6942                	ld	s2,16(sp)
    800020f4:	69a2                	ld	s3,8(sp)
    800020f6:	6a02                	ld	s4,0(sp)
    800020f8:	6145                	addi	sp,sp,48
    800020fa:	8082                	ret

00000000800020fc <kexit>:
{
    800020fc:	7179                	addi	sp,sp,-48
    800020fe:	f406                	sd	ra,40(sp)
    80002100:	f022                	sd	s0,32(sp)
    80002102:	ec26                	sd	s1,24(sp)
    80002104:	e84a                	sd	s2,16(sp)
    80002106:	e44e                	sd	s3,8(sp)
    80002108:	e052                	sd	s4,0(sp)
    8000210a:	1800                	addi	s0,sp,48
    8000210c:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    8000210e:	809ff0ef          	jal	80001916 <myproc>
    80002112:	89aa                	mv	s3,a0
  if (p == initproc)
    80002114:	00005797          	auipc	a5,0x5
    80002118:	7b47b783          	ld	a5,1972(a5) # 800078c8 <initproc>
    8000211c:	0d050493          	addi	s1,a0,208
    80002120:	15050913          	addi	s2,a0,336
    80002124:	00a79b63          	bne	a5,a0,8000213a <kexit+0x3e>
    panic("init exiting");
    80002128:	00005517          	auipc	a0,0x5
    8000212c:	11850513          	addi	a0,a0,280 # 80007240 <etext+0x240>
    80002130:	f02fe0ef          	jal	80000832 <panic>
  for (int fd = 0; fd < NOFILE; fd++) {
    80002134:	04a1                	addi	s1,s1,8
    80002136:	01248963          	beq	s1,s2,80002148 <kexit+0x4c>
    if (p->ofile[fd]) {
    8000213a:	6088                	ld	a0,0(s1)
    8000213c:	dd65                	beqz	a0,80002134 <kexit+0x38>
      fileclose(f);
    8000213e:	136020ef          	jal	80004274 <fileclose>
      p->ofile[fd] = 0;
    80002142:	0004b023          	sd	zero,0(s1)
    80002146:	b7fd                	j	80002134 <kexit+0x38>
  begin_op();
    80002148:	467010ef          	jal	80003dae <begin_op>
  iput(p->cwd);
    8000214c:	1509b503          	ld	a0,336(s3)
    80002150:	35e010ef          	jal	800034ae <iput>
  end_op();
    80002154:	4ef010ef          	jal	80003e42 <end_op>
  p->cwd = 0;
    80002158:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    8000215c:	0000e517          	auipc	a0,0xe
    80002160:	89450513          	addi	a0,a0,-1900 # 8000f9f0 <wait_lock>
    80002164:	aadfe0ef          	jal	80000c10 <acquire>
  reparent(p);
    80002168:	854e                	mv	a0,s3
    8000216a:	f3dff0ef          	jal	800020a6 <reparent>
  wakeup(p->parent);
    8000216e:	0389b503          	ld	a0,56(s3)
    80002172:	ebbff0ef          	jal	8000202c <wakeup>
  acquire(&p->lock);
    80002176:	854e                	mv	a0,s3
    80002178:	a99fe0ef          	jal	80000c10 <acquire>
  p->xstate = status;
    8000217c:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    80002180:	4795                	li	a5,5
    80002182:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    80002186:	0000e517          	auipc	a0,0xe
    8000218a:	86a50513          	addi	a0,a0,-1942 # 8000f9f0 <wait_lock>
    8000218e:	b15fe0ef          	jal	80000ca2 <release>
  sched();
    80002192:	d2dff0ef          	jal	80001ebe <sched>
  panic("zombie exit");
    80002196:	00005517          	auipc	a0,0x5
    8000219a:	0ba50513          	addi	a0,a0,186 # 80007250 <etext+0x250>
    8000219e:	e94fe0ef          	jal	80000832 <panic>

00000000800021a2 <kkill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kkill(int pid)
{
    800021a2:	7179                	addi	sp,sp,-48
    800021a4:	f406                	sd	ra,40(sp)
    800021a6:	f022                	sd	s0,32(sp)
    800021a8:	ec26                	sd	s1,24(sp)
    800021aa:	e84a                	sd	s2,16(sp)
    800021ac:	e44e                	sd	s3,8(sp)
    800021ae:	1800                	addi	s0,sp,48
    800021b0:	892a                	mv	s2,a0
  struct proc *p;

  if (pid == 0)
    return -1;

  for (p = proc; p < &proc[NPROC]; p++) {
    800021b2:	0000e497          	auipc	s1,0xe
    800021b6:	c5648493          	addi	s1,s1,-938 # 8000fe08 <proc>
    800021ba:	00014997          	auipc	s3,0x14
    800021be:	84e98993          	addi	s3,s3,-1970 # 80015a08 <tickslock>
  if (pid == 0)
    800021c2:	cd11                	beqz	a0,800021de <kkill+0x3c>
    acquire(&p->lock);
    800021c4:	8526                	mv	a0,s1
    800021c6:	a4bfe0ef          	jal	80000c10 <acquire>
    if (p->pid == pid) {
    800021ca:	589c                	lw	a5,48(s1)
    800021cc:	01278b63          	beq	a5,s2,800021e2 <kkill+0x40>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    800021d0:	8526                	mv	a0,s1
    800021d2:	ad1fe0ef          	jal	80000ca2 <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    800021d6:	17048493          	addi	s1,s1,368
    800021da:	ff3495e3          	bne	s1,s3,800021c4 <kkill+0x22>
    return -1;
    800021de:	557d                	li	a0,-1
    800021e0:	a819                	j	800021f6 <kkill+0x54>
      p->killed = 1;
    800021e2:	4785                	li	a5,1
    800021e4:	d49c                	sw	a5,40(s1)
      if (p->state == SLEEPING) {
    800021e6:	4c98                	lw	a4,24(s1)
    800021e8:	4789                	li	a5,2
    800021ea:	00f70d63          	beq	a4,a5,80002204 <kkill+0x62>
      release(&p->lock);
    800021ee:	8526                	mv	a0,s1
    800021f0:	ab3fe0ef          	jal	80000ca2 <release>
      return 0;
    800021f4:	4501                	li	a0,0
  }
  return -1;
}
    800021f6:	70a2                	ld	ra,40(sp)
    800021f8:	7402                	ld	s0,32(sp)
    800021fa:	64e2                	ld	s1,24(sp)
    800021fc:	6942                	ld	s2,16(sp)
    800021fe:	69a2                	ld	s3,8(sp)
    80002200:	6145                	addi	sp,sp,48
    80002202:	8082                	ret
        if(p->priority >=2) {
    80002204:	1684a783          	lw	a5,360(s1)
    80002208:	873e                	mv	a4,a5
    8000220a:	2781                	sext.w	a5,a5
    8000220c:	4689                	li	a3,2
    8000220e:	00d7d363          	bge	a5,a3,80002214 <kkill+0x72>
    80002212:	4709                	li	a4,2
    80002214:	3779                	addiw	a4,a4,-2
    80002216:	16e4a423          	sw	a4,360(s1)
        p->state = RUNNABLE;
    8000221a:	478d                	li	a5,3
    8000221c:	cc9c                	sw	a5,24(s1)
    8000221e:	bfc1                	j	800021ee <kkill+0x4c>

0000000080002220 <setkilled>:

void
setkilled(struct proc *p)
{
    80002220:	1101                	addi	sp,sp,-32
    80002222:	ec06                	sd	ra,24(sp)
    80002224:	e822                	sd	s0,16(sp)
    80002226:	e426                	sd	s1,8(sp)
    80002228:	1000                	addi	s0,sp,32
    8000222a:	84aa                	mv	s1,a0
  acquire(&p->lock);
    8000222c:	9e5fe0ef          	jal	80000c10 <acquire>
  p->killed = 1;
    80002230:	4785                	li	a5,1
    80002232:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    80002234:	8526                	mv	a0,s1
    80002236:	a6dfe0ef          	jal	80000ca2 <release>
}
    8000223a:	60e2                	ld	ra,24(sp)
    8000223c:	6442                	ld	s0,16(sp)
    8000223e:	64a2                	ld	s1,8(sp)
    80002240:	6105                	addi	sp,sp,32
    80002242:	8082                	ret

0000000080002244 <killed>:

int
killed(struct proc *p)
{
    80002244:	1101                	addi	sp,sp,-32
    80002246:	ec06                	sd	ra,24(sp)
    80002248:	e822                	sd	s0,16(sp)
    8000224a:	e426                	sd	s1,8(sp)
    8000224c:	e04a                	sd	s2,0(sp)
    8000224e:	1000                	addi	s0,sp,32
    80002250:	84aa                	mv	s1,a0
  int k;

  acquire(&p->lock);
    80002252:	9bffe0ef          	jal	80000c10 <acquire>
  k = p->killed;
    80002256:	549c                	lw	a5,40(s1)
    80002258:	893e                	mv	s2,a5
  release(&p->lock);
    8000225a:	8526                	mv	a0,s1
    8000225c:	a47fe0ef          	jal	80000ca2 <release>
  return k;
}
    80002260:	854a                	mv	a0,s2
    80002262:	60e2                	ld	ra,24(sp)
    80002264:	6442                	ld	s0,16(sp)
    80002266:	64a2                	ld	s1,8(sp)
    80002268:	6902                	ld	s2,0(sp)
    8000226a:	6105                	addi	sp,sp,32
    8000226c:	8082                	ret

000000008000226e <kwait>:
{
    8000226e:	715d                	addi	sp,sp,-80
    80002270:	e486                	sd	ra,72(sp)
    80002272:	e0a2                	sd	s0,64(sp)
    80002274:	fc26                	sd	s1,56(sp)
    80002276:	f84a                	sd	s2,48(sp)
    80002278:	f44e                	sd	s3,40(sp)
    8000227a:	f052                	sd	s4,32(sp)
    8000227c:	ec56                	sd	s5,24(sp)
    8000227e:	e85a                	sd	s6,16(sp)
    80002280:	e45e                	sd	s7,8(sp)
    80002282:	0880                	addi	s0,sp,80
    80002284:	8baa                	mv	s7,a0
  struct proc *p = myproc();
    80002286:	e90ff0ef          	jal	80001916 <myproc>
    8000228a:	892a                	mv	s2,a0
  acquire(&wait_lock); // Keep wait_lock held while scanning
    8000228c:	0000d517          	auipc	a0,0xd
    80002290:	76450513          	addi	a0,a0,1892 # 8000f9f0 <wait_lock>
    80002294:	97dfe0ef          	jal	80000c10 <acquire>
        if (pp->state == ZOMBIE) {
    80002298:	4a15                	li	s4,5
        havekids = 1;
    8000229a:	4a85                	li	s5,1
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    8000229c:	00013997          	auipc	s3,0x13
    800022a0:	76c98993          	addi	s3,s3,1900 # 80015a08 <tickslock>
    sleep(p, &wait_lock); 
    800022a4:	0000db17          	auipc	s6,0xd
    800022a8:	74cb0b13          	addi	s6,s6,1868 # 8000f9f0 <wait_lock>
    800022ac:	a045                	j	8000234c <kwait+0xde>
          pid = pp->pid;
    800022ae:	0304a983          	lw	s3,48(s1)
          if (addr != 0 &&
    800022b2:	000b8e63          	beqz	s7,800022ce <kwait+0x60>
              copyout(p->pagetable, p->sz, addr, (char *)&pp->xstate,
    800022b6:	4711                	li	a4,4
    800022b8:	02c48693          	addi	a3,s1,44
    800022bc:	865e                	mv	a2,s7
    800022be:	04893583          	ld	a1,72(s2)
    800022c2:	05093503          	ld	a0,80(s2)
    800022c6:	a9aff0ef          	jal	80001560 <copyout>
          if (addr != 0 &&
    800022ca:	02054c63          	bltz	a0,80002302 <kwait+0x94>
          pp->parent = 0;
    800022ce:	0204bc23          	sd	zero,56(s1)
          freeproc(pp);
    800022d2:	8526                	mv	a0,s1
    800022d4:	811ff0ef          	jal	80001ae4 <freeproc>
          release(&pp->lock);
    800022d8:	8526                	mv	a0,s1
    800022da:	9c9fe0ef          	jal	80000ca2 <release>
          release(&wait_lock);
    800022de:	0000d517          	auipc	a0,0xd
    800022e2:	71250513          	addi	a0,a0,1810 # 8000f9f0 <wait_lock>
    800022e6:	9bdfe0ef          	jal	80000ca2 <release>
}
    800022ea:	854e                	mv	a0,s3
    800022ec:	60a6                	ld	ra,72(sp)
    800022ee:	6406                	ld	s0,64(sp)
    800022f0:	74e2                	ld	s1,56(sp)
    800022f2:	7942                	ld	s2,48(sp)
    800022f4:	79a2                	ld	s3,40(sp)
    800022f6:	7a02                	ld	s4,32(sp)
    800022f8:	6ae2                	ld	s5,24(sp)
    800022fa:	6b42                	ld	s6,16(sp)
    800022fc:	6ba2                	ld	s7,8(sp)
    800022fe:	6161                	addi	sp,sp,80
    80002300:	8082                	ret
            release(&pp->lock);
    80002302:	8526                	mv	a0,s1
    80002304:	99ffe0ef          	jal	80000ca2 <release>
            release(&wait_lock);
    80002308:	0000d517          	auipc	a0,0xd
    8000230c:	6e850513          	addi	a0,a0,1768 # 8000f9f0 <wait_lock>
    80002310:	993fe0ef          	jal	80000ca2 <release>
            return -1;
    80002314:	a881                	j	80002364 <kwait+0xf6>
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    80002316:	17048493          	addi	s1,s1,368
    8000231a:	03348063          	beq	s1,s3,8000233a <kwait+0xcc>
      if (pp->parent == p) {
    8000231e:	7c9c                	ld	a5,56(s1)
    80002320:	ff279be3          	bne	a5,s2,80002316 <kwait+0xa8>
        acquire(&pp->lock);
    80002324:	8526                	mv	a0,s1
    80002326:	8ebfe0ef          	jal	80000c10 <acquire>
        if (pp->state == ZOMBIE) {
    8000232a:	4c9c                	lw	a5,24(s1)
    8000232c:	f94781e3          	beq	a5,s4,800022ae <kwait+0x40>
        release(&pp->lock);
    80002330:	8526                	mv	a0,s1
    80002332:	971fe0ef          	jal	80000ca2 <release>
        havekids = 1;
    80002336:	8756                	mv	a4,s5
    80002338:	bff9                	j	80002316 <kwait+0xa8>
    if (!havekids || killed(p)) {
    8000233a:	cf19                	beqz	a4,80002358 <kwait+0xea>
    8000233c:	854a                	mv	a0,s2
    8000233e:	f07ff0ef          	jal	80002244 <killed>
    80002342:	e919                	bnez	a0,80002358 <kwait+0xea>
    sleep(p, &wait_lock); 
    80002344:	85da                	mv	a1,s6
    80002346:	854a                	mv	a0,s2
    80002348:	c99ff0ef          	jal	80001fe0 <sleep>
    havekids = 0;
    8000234c:	4701                	li	a4,0
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    8000234e:	0000e497          	auipc	s1,0xe
    80002352:	aba48493          	addi	s1,s1,-1350 # 8000fe08 <proc>
    80002356:	b7e1                	j	8000231e <kwait+0xb0>
      release(&wait_lock);
    80002358:	0000d517          	auipc	a0,0xd
    8000235c:	69850513          	addi	a0,a0,1688 # 8000f9f0 <wait_lock>
    80002360:	943fe0ef          	jal	80000ca2 <release>
            return -1;
    80002364:	59fd                	li	s3,-1
    80002366:	b751                	j	800022ea <kwait+0x7c>

0000000080002368 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    80002368:	7179                	addi	sp,sp,-48
    8000236a:	f406                	sd	ra,40(sp)
    8000236c:	f022                	sd	s0,32(sp)
    8000236e:	ec26                	sd	s1,24(sp)
    80002370:	e84a                	sd	s2,16(sp)
    80002372:	e44e                	sd	s3,8(sp)
    80002374:	e052                	sd	s4,0(sp)
    80002376:	1800                	addi	s0,sp,48
    80002378:	84aa                	mv	s1,a0
    8000237a:	8a2e                	mv	s4,a1
    8000237c:	89b2                	mv	s3,a2
    8000237e:	8936                	mv	s2,a3
  struct proc *p = myproc();
    80002380:	d96ff0ef          	jal	80001916 <myproc>
  if (user_dst) {
    80002384:	c085                	beqz	s1,800023a4 <either_copyout+0x3c>
    return copyout(p->pagetable, p->sz, dst, src, len);
    80002386:	874a                	mv	a4,s2
    80002388:	86ce                	mv	a3,s3
    8000238a:	8652                	mv	a2,s4
    8000238c:	652c                	ld	a1,72(a0)
    8000238e:	6928                	ld	a0,80(a0)
    80002390:	9d0ff0ef          	jal	80001560 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    80002394:	70a2                	ld	ra,40(sp)
    80002396:	7402                	ld	s0,32(sp)
    80002398:	64e2                	ld	s1,24(sp)
    8000239a:	6942                	ld	s2,16(sp)
    8000239c:	69a2                	ld	s3,8(sp)
    8000239e:	6a02                	ld	s4,0(sp)
    800023a0:	6145                	addi	sp,sp,48
    800023a2:	8082                	ret
    memmove((char *)dst, src, len);
    800023a4:	0009061b          	sext.w	a2,s2
    800023a8:	85ce                	mv	a1,s3
    800023aa:	8552                	mv	a0,s4
    800023ac:	999fe0ef          	jal	80000d44 <memmove>
    return 0;
    800023b0:	8526                	mv	a0,s1
    800023b2:	b7cd                	j	80002394 <either_copyout+0x2c>

00000000800023b4 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    800023b4:	7179                	addi	sp,sp,-48
    800023b6:	f406                	sd	ra,40(sp)
    800023b8:	f022                	sd	s0,32(sp)
    800023ba:	ec26                	sd	s1,24(sp)
    800023bc:	e84a                	sd	s2,16(sp)
    800023be:	e44e                	sd	s3,8(sp)
    800023c0:	e052                	sd	s4,0(sp)
    800023c2:	1800                	addi	s0,sp,48
    800023c4:	8a2a                	mv	s4,a0
    800023c6:	84ae                	mv	s1,a1
    800023c8:	89b2                	mv	s3,a2
    800023ca:	8936                	mv	s2,a3
  struct proc *p = myproc();
    800023cc:	d4aff0ef          	jal	80001916 <myproc>
  if (user_src) {
    800023d0:	c085                	beqz	s1,800023f0 <either_copyin+0x3c>
    return copyin(p->pagetable, p->sz, dst, src, len);
    800023d2:	874a                	mv	a4,s2
    800023d4:	86ce                	mv	a3,s3
    800023d6:	8652                	mv	a2,s4
    800023d8:	652c                	ld	a1,72(a0)
    800023da:	6928                	ld	a0,80(a0)
    800023dc:	a44ff0ef          	jal	80001620 <copyin>
  } else {
    memmove(dst, (char *)src, len);
    return 0;
  }
}
    800023e0:	70a2                	ld	ra,40(sp)
    800023e2:	7402                	ld	s0,32(sp)
    800023e4:	64e2                	ld	s1,24(sp)
    800023e6:	6942                	ld	s2,16(sp)
    800023e8:	69a2                	ld	s3,8(sp)
    800023ea:	6a02                	ld	s4,0(sp)
    800023ec:	6145                	addi	sp,sp,48
    800023ee:	8082                	ret
    memmove(dst, (char *)src, len);
    800023f0:	0009061b          	sext.w	a2,s2
    800023f4:	85ce                	mv	a1,s3
    800023f6:	8552                	mv	a0,s4
    800023f8:	94dfe0ef          	jal	80000d44 <memmove>
    return 0;
    800023fc:	8526                	mv	a0,s1
    800023fe:	b7cd                	j	800023e0 <either_copyin+0x2c>

0000000080002400 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    80002400:	715d                	addi	sp,sp,-80
    80002402:	e486                	sd	ra,72(sp)
    80002404:	e0a2                	sd	s0,64(sp)
    80002406:	fc26                	sd	s1,56(sp)
    80002408:	f84a                	sd	s2,48(sp)
    8000240a:	f44e                	sd	s3,40(sp)
    8000240c:	f052                	sd	s4,32(sp)
    8000240e:	ec56                	sd	s5,24(sp)
    80002410:	e85a                	sd	s6,16(sp)
    80002412:	e45e                	sd	s7,8(sp)
    80002414:	0880                	addi	s0,sp,80
    // clang-format on
  };
  struct proc *p;
  char *state;

  printk("\n");
    80002416:	00005517          	auipc	a0,0x5
    8000241a:	ca250513          	addi	a0,a0,-862 # 800070b8 <etext+0xb8>
    8000241e:	8dcfe0ef          	jal	800004fa <printk>
  for (p = proc; p < &proc[NPROC]; p++) {
    80002422:	0000e497          	auipc	s1,0xe
    80002426:	b3e48493          	addi	s1,s1,-1218 # 8000ff60 <proc+0x158>
    8000242a:	00013917          	auipc	s2,0x13
    8000242e:	73690913          	addi	s2,s2,1846 # 80015b60 <bcache+0x140>
    if (p->state == UNUSED)
      continue;
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002432:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    80002434:	00005a97          	auipc	s5,0x5
    80002438:	e2ca8a93          	addi	s5,s5,-468 # 80007260 <etext+0x260>
    printk("%d %s %s", p->pid, state, p->name);
    8000243c:	00005a17          	auipc	s4,0x5
    80002440:	e2ca0a13          	addi	s4,s4,-468 # 80007268 <etext+0x268>
    printk("\n");
    80002444:	00005997          	auipc	s3,0x5
    80002448:	c7498993          	addi	s3,s3,-908 # 800070b8 <etext+0xb8>
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    8000244c:	00005b97          	auipc	s7,0x5
    80002450:	33cb8b93          	addi	s7,s7,828 # 80007788 <states.0>
    80002454:	a829                	j	8000246e <procdump+0x6e>
    printk("%d %s %s", p->pid, state, p->name);
    80002456:	ed86a583          	lw	a1,-296(a3)
    8000245a:	8552                	mv	a0,s4
    8000245c:	89efe0ef          	jal	800004fa <printk>
    printk("\n");
    80002460:	854e                	mv	a0,s3
    80002462:	898fe0ef          	jal	800004fa <printk>
  for (p = proc; p < &proc[NPROC]; p++) {
    80002466:	17048493          	addi	s1,s1,368
    8000246a:	03248063          	beq	s1,s2,8000248a <procdump+0x8a>
    if (p->state == UNUSED)
    8000246e:	86a6                	mv	a3,s1
    80002470:	ec04a783          	lw	a5,-320(s1)
    80002474:	dbed                	beqz	a5,80002466 <procdump+0x66>
      state = "???";
    80002476:	8656                	mv	a2,s5
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002478:	fcfb6fe3          	bltu	s6,a5,80002456 <procdump+0x56>
    8000247c:	02079713          	slli	a4,a5,0x20
    80002480:	01d75793          	srli	a5,a4,0x1d
    80002484:	97de                	add	a5,a5,s7
    80002486:	6390                	ld	a2,0(a5)
      state = states[p->state];
    80002488:	b7f9                	j	80002456 <procdump+0x56>
  }
}
    8000248a:	60a6                	ld	ra,72(sp)
    8000248c:	6406                	ld	s0,64(sp)
    8000248e:	74e2                	ld	s1,56(sp)
    80002490:	7942                	ld	s2,48(sp)
    80002492:	79a2                	ld	s3,40(sp)
    80002494:	7a02                	ld	s4,32(sp)
    80002496:	6ae2                	ld	s5,24(sp)
    80002498:	6b42                	ld	s6,16(sp)
    8000249a:	6ba2                	ld	s7,8(sp)
    8000249c:	6161                	addi	sp,sp,80
    8000249e:	8082                	ret

00000000800024a0 <swtch>:
# Save current registers in old. Load from new.	


.globl swtch
swtch:
        sd ra, 0(a0)
    800024a0:	00153023          	sd	ra,0(a0)
        sd sp, 8(a0)
    800024a4:	00253423          	sd	sp,8(a0)
        sd s0, 16(a0)
    800024a8:	e900                	sd	s0,16(a0)
        sd s1, 24(a0)
    800024aa:	ed04                	sd	s1,24(a0)
        sd s2, 32(a0)
    800024ac:	03253023          	sd	s2,32(a0)
        sd s3, 40(a0)
    800024b0:	03353423          	sd	s3,40(a0)
        sd s4, 48(a0)
    800024b4:	03453823          	sd	s4,48(a0)
        sd s5, 56(a0)
    800024b8:	03553c23          	sd	s5,56(a0)
        sd s6, 64(a0)
    800024bc:	05653023          	sd	s6,64(a0)
        sd s7, 72(a0)
    800024c0:	05753423          	sd	s7,72(a0)
        sd s8, 80(a0)
    800024c4:	05853823          	sd	s8,80(a0)
        sd s9, 88(a0)
    800024c8:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    800024cc:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    800024d0:	07b53423          	sd	s11,104(a0)

        ld ra, 0(a1)
    800024d4:	0005b083          	ld	ra,0(a1)
        ld sp, 8(a1)
    800024d8:	0085b103          	ld	sp,8(a1)
        ld s0, 16(a1)
    800024dc:	6980                	ld	s0,16(a1)
        ld s1, 24(a1)
    800024de:	6d84                	ld	s1,24(a1)
        ld s2, 32(a1)
    800024e0:	0205b903          	ld	s2,32(a1)
        ld s3, 40(a1)
    800024e4:	0285b983          	ld	s3,40(a1)
        ld s4, 48(a1)
    800024e8:	0305ba03          	ld	s4,48(a1)
        ld s5, 56(a1)
    800024ec:	0385ba83          	ld	s5,56(a1)
        ld s6, 64(a1)
    800024f0:	0405bb03          	ld	s6,64(a1)
        ld s7, 72(a1)
    800024f4:	0485bb83          	ld	s7,72(a1)
        ld s8, 80(a1)
    800024f8:	0505bc03          	ld	s8,80(a1)
        ld s9, 88(a1)
    800024fc:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    80002500:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    80002504:	0685bd83          	ld	s11,104(a1)
        
        ret
    80002508:	8082                	ret

000000008000250a <trapinit>:

extern int devintr();

void
trapinit(void)
{
    8000250a:	1141                	addi	sp,sp,-16
    8000250c:	e406                	sd	ra,8(sp)
    8000250e:	e022                	sd	s0,0(sp)
    80002510:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    80002512:	00005597          	auipc	a1,0x5
    80002516:	d9658593          	addi	a1,a1,-618 # 800072a8 <etext+0x2a8>
    8000251a:	00013517          	auipc	a0,0x13
    8000251e:	4ee50513          	addi	a0,a0,1262 # 80015a08 <tickslock>
    80002522:	e6efe0ef          	jal	80000b90 <initlock>
}
    80002526:	60a2                	ld	ra,8(sp)
    80002528:	6402                	ld	s0,0(sp)
    8000252a:	0141                	addi	sp,sp,16
    8000252c:	8082                	ret

000000008000252e <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    8000252e:	1141                	addi	sp,sp,-16
    80002530:	e406                	sd	ra,8(sp)
    80002532:	e022                	sd	s0,0(sp)
    80002534:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r"(x));
    80002536:	00003797          	auipc	a5,0x3
    8000253a:	11a78793          	addi	a5,a5,282 # 80005650 <kernelvec>
    8000253e:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    80002542:	60a2                	ld	ra,8(sp)
    80002544:	6402                	ld	s0,0(sp)
    80002546:	0141                	addi	sp,sp,16
    80002548:	8082                	ret

000000008000254a <prepare_return>:
//
// set up trapframe and control registers for a return to user space
//
void
prepare_return(void)
{
    8000254a:	1141                	addi	sp,sp,-16
    8000254c:	e406                	sd	ra,8(sp)
    8000254e:	e022                	sd	s0,0(sp)
    80002550:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80002552:	bc4ff0ef          	jal	80001916 <myproc>
  __asm__ __volatile__("csrc sstatus, %0" ::"rK"(x) : "memory");
    80002556:	10017073          	csrci	sstatus,2
  // kerneltrap() to usertrap(). because a trap from kernel
  // code to usertrap would be a disaster, turn off interrupts.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    8000255a:	04000737          	lui	a4,0x4000
    8000255e:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    80002560:	0732                	slli	a4,a4,0xc
    80002562:	00004797          	auipc	a5,0x4
    80002566:	a9e78793          	addi	a5,a5,-1378 # 80006000 <_trampoline>
    8000256a:	00004697          	auipc	a3,0x4
    8000256e:	a9668693          	addi	a3,a3,-1386 # 80006000 <_trampoline>
    80002572:	8f95                	sub	a5,a5,a3
    80002574:	97ba                	add	a5,a5,a4
  asm volatile("csrw stvec, %0" : : "r"(x));
    80002576:	10579073          	csrw	stvec,a5
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    8000257a:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, satp" : "=r"(x));
    8000257c:	18002773          	csrr	a4,satp
    80002580:	e398                	sd	a4,0(a5)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    80002582:	6d38                	ld	a4,88(a0)
    80002584:	613c                	ld	a5,64(a0)
    80002586:	6685                	lui	a3,0x1
    80002588:	97b6                	add	a5,a5,a3
    8000258a:	e71c                	sd	a5,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    8000258c:	6d3c                	ld	a5,88(a0)
    8000258e:	00000717          	auipc	a4,0x0
    80002592:	0f470713          	addi	a4,a4,244 # 80002682 <usertrap>
    80002596:	eb98                	sd	a4,16(a5)
  p->trapframe->kernel_hartid = r_tp(); // hartid for cpuid()
    80002598:	6d3c                	ld	a5,88(a0)
  asm volatile("mv %0, tp" : "=r"(x));
    8000259a:	8712                	mv	a4,tp
    8000259c:	f398                	sd	a4,32(a5)
  asm volatile("csrr %0, sstatus" : "=r"(x));
    8000259e:	100027f3          	csrr	a5,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.

  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    800025a2:	eff7f793          	andi	a5,a5,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    800025a6:	0207e793          	ori	a5,a5,32
  asm volatile("csrw sstatus, %0" : : "r"(x));
    800025aa:	10079073          	csrw	sstatus,a5
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    800025ae:	6d3c                	ld	a5,88(a0)
  asm volatile("csrw sepc, %0" : : "r"(x));
    800025b0:	6f9c                	ld	a5,24(a5)
    800025b2:	14179073          	csrw	sepc,a5
}
    800025b6:	60a2                	ld	ra,8(sp)
    800025b8:	6402                	ld	s0,0(sp)
    800025ba:	0141                	addi	sp,sp,16
    800025bc:	8082                	ret

00000000800025be <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    800025be:	1141                	addi	sp,sp,-16
    800025c0:	e406                	sd	ra,8(sp)
    800025c2:	e022                	sd	s0,0(sp)
    800025c4:	0800                	addi	s0,sp,16
  if (cpuid() == 0) {
    800025c6:	b1cff0ef          	jal	800018e2 <cpuid>
    800025ca:	cd11                	beqz	a0,800025e6 <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r"(x));
    800025cc:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    800025d0:	000f4737          	lui	a4,0xf4
    800025d4:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    800025d8:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r"(x));
    800025da:	14d79073          	csrw	stimecmp,a5
}
    800025de:	60a2                	ld	ra,8(sp)
    800025e0:	6402                	ld	s0,0(sp)
    800025e2:	0141                	addi	sp,sp,16
    800025e4:	8082                	ret
    acquire(&tickslock);
    800025e6:	00013517          	auipc	a0,0x13
    800025ea:	42250513          	addi	a0,a0,1058 # 80015a08 <tickslock>
    800025ee:	e22fe0ef          	jal	80000c10 <acquire>
    ticks++;
    800025f2:	00005717          	auipc	a4,0x5
    800025f6:	2de70713          	addi	a4,a4,734 # 800078d0 <ticks>
    800025fa:	431c                	lw	a5,0(a4)
    800025fc:	2785                	addiw	a5,a5,1
    800025fe:	c31c                	sw	a5,0(a4)
    wakeup(&ticks);
    80002600:	853a                	mv	a0,a4
    80002602:	a2bff0ef          	jal	8000202c <wakeup>
    release(&tickslock);
    80002606:	00013517          	auipc	a0,0x13
    8000260a:	40250513          	addi	a0,a0,1026 # 80015a08 <tickslock>
    8000260e:	e94fe0ef          	jal	80000ca2 <release>
    80002612:	bf6d                	j	800025cc <clockintr+0xe>

0000000080002614 <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    80002614:	1101                	addi	sp,sp,-32
    80002616:	ec06                	sd	ra,24(sp)
    80002618:	e822                	sd	s0,16(sp)
    8000261a:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r"(x));
    8000261c:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if (scause == 0x8000000000000009L) {
    80002620:	57fd                	li	a5,-1
    80002622:	17fe                	slli	a5,a5,0x3f
    80002624:	07a5                	addi	a5,a5,9
    80002626:	00f70c63          	beq	a4,a5,8000263e <devintr+0x2a>
    // now allowed to interrupt again.
    if (irq)
      plic_complete(irq);

    return 1;
  } else if (scause == 0x8000000000000005L) {
    8000262a:	57fd                	li	a5,-1
    8000262c:	17fe                	slli	a5,a5,0x3f
    8000262e:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    80002630:	4501                	li	a0,0
  } else if (scause == 0x8000000000000005L) {
    80002632:	04f70463          	beq	a4,a5,8000267a <devintr+0x66>
  }
}
    80002636:	60e2                	ld	ra,24(sp)
    80002638:	6442                	ld	s0,16(sp)
    8000263a:	6105                	addi	sp,sp,32
    8000263c:	8082                	ret
    8000263e:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    80002640:	0be030ef          	jal	800056fe <plic_claim>
    80002644:	84aa                	mv	s1,a0
    if (irq == UART0_IRQ) {
    80002646:	47a9                	li	a5,10
    80002648:	02f50363          	beq	a0,a5,8000266e <devintr+0x5a>
    } else if (irq == VIRTIO0_IRQ) {
    8000264c:	4785                	li	a5,1
    8000264e:	02f50363          	beq	a0,a5,80002674 <devintr+0x60>
    } else if (irq) {
    80002652:	c919                	beqz	a0,80002668 <devintr+0x54>
      printk("unexpected interrupt irq=%d\n", irq);
    80002654:	85aa                	mv	a1,a0
    80002656:	00005517          	auipc	a0,0x5
    8000265a:	c5a50513          	addi	a0,a0,-934 # 800072b0 <etext+0x2b0>
    8000265e:	e9dfd0ef          	jal	800004fa <printk>
      plic_complete(irq);
    80002662:	8526                	mv	a0,s1
    80002664:	0bc030ef          	jal	80005720 <plic_complete>
    return 1;
    80002668:	4505                	li	a0,1
    8000266a:	64a2                	ld	s1,8(sp)
    8000266c:	b7e9                	j	80002636 <devintr+0x22>
      uartintr();
    8000266e:	b68fe0ef          	jal	800009d6 <uartintr>
    if (irq)
    80002672:	bfc5                	j	80002662 <devintr+0x4e>
      virtio_disk_intr();
    80002674:	524030ef          	jal	80005b98 <virtio_disk_intr>
    if (irq)
    80002678:	b7ed                	j	80002662 <devintr+0x4e>
    clockintr();
    8000267a:	f45ff0ef          	jal	800025be <clockintr>
    return 2;
    8000267e:	4509                	li	a0,2
    80002680:	bf5d                	j	80002636 <devintr+0x22>

0000000080002682 <usertrap>:
{
    80002682:	1101                	addi	sp,sp,-32
    80002684:	ec06                	sd	ra,24(sp)
    80002686:	e822                	sd	s0,16(sp)
    80002688:	e426                	sd	s1,8(sp)
    8000268a:	e04a                	sd	s2,0(sp)
    8000268c:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r"(x));
    8000268e:	100027f3          	csrr	a5,sstatus
  if ((r_sstatus() & SSTATUS_SPP) != 0)
    80002692:	1007f793          	andi	a5,a5,256
    80002696:	eba5                	bnez	a5,80002706 <usertrap+0x84>
  asm volatile("csrw stvec, %0" : : "r"(x));
    80002698:	00003797          	auipc	a5,0x3
    8000269c:	fb878793          	addi	a5,a5,-72 # 80005650 <kernelvec>
    800026a0:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    800026a4:	a72ff0ef          	jal	80001916 <myproc>
    800026a8:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    800026aa:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r"(x));
    800026ac:	14102773          	csrr	a4,sepc
    800026b0:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r"(x));
    800026b2:	14202773          	csrr	a4,scause
  if (r_scause() == 8) {
    800026b6:	47a1                	li	a5,8
    800026b8:	04f70d63          	beq	a4,a5,80002712 <usertrap+0x90>
  } else if ((which_dev = devintr()) != 0) {
    800026bc:	f59ff0ef          	jal	80002614 <devintr>
    800026c0:	892a                	mv	s2,a0
    800026c2:	e54d                	bnez	a0,8000276c <usertrap+0xea>
    800026c4:	14202773          	csrr	a4,scause
  } else if ((r_scause() == 15 || r_scause() == 13) &&
    800026c8:	47bd                	li	a5,15
    800026ca:	08f70463          	beq	a4,a5,80002752 <usertrap+0xd0>
    800026ce:	14202773          	csrr	a4,scause
    800026d2:	47b5                	li	a5,13
    800026d4:	06f70f63          	beq	a4,a5,80002752 <usertrap+0xd0>
    800026d8:	142025f3          	csrr	a1,scause
    printk("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    800026dc:	5890                	lw	a2,48(s1)
    800026de:	00005517          	auipc	a0,0x5
    800026e2:	c1250513          	addi	a0,a0,-1006 # 800072f0 <etext+0x2f0>
    800026e6:	e15fd0ef          	jal	800004fa <printk>
  asm volatile("csrr %0, sepc" : "=r"(x));
    800026ea:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r"(x));
    800026ee:	14302673          	csrr	a2,stval
    printk("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    800026f2:	00005517          	auipc	a0,0x5
    800026f6:	c2e50513          	addi	a0,a0,-978 # 80007320 <etext+0x320>
    800026fa:	e01fd0ef          	jal	800004fa <printk>
    setkilled(p);
    800026fe:	8526                	mv	a0,s1
    80002700:	b21ff0ef          	jal	80002220 <setkilled>
    80002704:	a015                	j	80002728 <usertrap+0xa6>
    panic("usertrap: not from user mode");
    80002706:	00005517          	auipc	a0,0x5
    8000270a:	bca50513          	addi	a0,a0,-1078 # 800072d0 <etext+0x2d0>
    8000270e:	924fe0ef          	jal	80000832 <panic>
    if (killed(p))
    80002712:	b33ff0ef          	jal	80002244 <killed>
    80002716:	e915                	bnez	a0,8000274a <usertrap+0xc8>
    p->trapframe->epc += 4;
    80002718:	6cb8                	ld	a4,88(s1)
    8000271a:	6f1c                	ld	a5,24(a4)
    8000271c:	0791                	addi	a5,a5,4
    8000271e:	ef1c                	sd	a5,24(a4)
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    80002720:	10016073          	csrsi	sstatus,2
    syscall();
    80002724:	290000ef          	jal	800029b4 <syscall>
  if (killed(p))
    80002728:	8526                	mv	a0,s1
    8000272a:	b1bff0ef          	jal	80002244 <killed>
    8000272e:	e521                	bnez	a0,80002776 <usertrap+0xf4>
  prepare_return();
    80002730:	e1bff0ef          	jal	8000254a <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    80002734:	68a8                	ld	a0,80(s1)
    80002736:	8131                	srli	a0,a0,0xc
    80002738:	57fd                	li	a5,-1
    8000273a:	17fe                	slli	a5,a5,0x3f
    8000273c:	8d5d                	or	a0,a0,a5
}
    8000273e:	60e2                	ld	ra,24(sp)
    80002740:	6442                	ld	s0,16(sp)
    80002742:	64a2                	ld	s1,8(sp)
    80002744:	6902                	ld	s2,0(sp)
    80002746:	6105                	addi	sp,sp,32
    80002748:	8082                	ret
      kexit(-1);
    8000274a:	557d                	li	a0,-1
    8000274c:	9b1ff0ef          	jal	800020fc <kexit>
    80002750:	b7e1                	j	80002718 <usertrap+0x96>
  asm volatile("csrr %0, stval" : "=r"(x));
    80002752:	14302673          	csrr	a2,stval
  asm volatile("csrr %0, scause" : "=r"(x));
    80002756:	142026f3          	csrr	a3,scause
             vmfault(p->pagetable, p->sz, r_stval(),
    8000275a:	16cd                	addi	a3,a3,-13 # ff3 <_entry-0x7ffff00d>
    8000275c:	0016b693          	seqz	a3,a3
    80002760:	64ac                	ld	a1,72(s1)
    80002762:	68a8                	ld	a0,80(s1)
    80002764:	d85fe0ef          	jal	800014e8 <vmfault>
  } else if ((r_scause() == 15 || r_scause() == 13) &&
    80002768:	f161                	bnez	a0,80002728 <usertrap+0xa6>
    8000276a:	b7bd                	j	800026d8 <usertrap+0x56>
  if (killed(p))
    8000276c:	8526                	mv	a0,s1
    8000276e:	ad7ff0ef          	jal	80002244 <killed>
    80002772:	c511                	beqz	a0,8000277e <usertrap+0xfc>
    80002774:	a011                	j	80002778 <usertrap+0xf6>
    80002776:	4901                	li	s2,0
    kexit(-1);
    80002778:	557d                	li	a0,-1
    8000277a:	983ff0ef          	jal	800020fc <kexit>
  if (which_dev == 2) {
    8000277e:	4789                	li	a5,2
    80002780:	faf918e3          	bne	s2,a5,80002730 <usertrap+0xae>
    acquire(&p->lock);
    80002784:	8526                	mv	a0,s1
    80002786:	c8afe0ef          	jal	80000c10 <acquire>
    if (p->priority <= 198) {
    8000278a:	1684a783          	lw	a5,360(s1)
    8000278e:	873e                	mv	a4,a5
    80002790:	2781                	sext.w	a5,a5
    80002792:	0c600693          	li	a3,198
    80002796:	00f6d463          	bge	a3,a5,8000279e <usertrap+0x11c>
    8000279a:	0c600713          	li	a4,198
    8000279e:	2709                	addiw	a4,a4,2
    800027a0:	16e4a423          	sw	a4,360(s1)
    release(&p->lock);
    800027a4:	8526                	mv	a0,s1
    800027a6:	cfcfe0ef          	jal	80000ca2 <release>
    yield();
    800027aa:	fceff0ef          	jal	80001f78 <yield>
    800027ae:	b749                	j	80002730 <usertrap+0xae>

00000000800027b0 <kerneltrap>:
{
    800027b0:	7179                	addi	sp,sp,-48
    800027b2:	f406                	sd	ra,40(sp)
    800027b4:	f022                	sd	s0,32(sp)
    800027b6:	ec26                	sd	s1,24(sp)
    800027b8:	e84a                	sd	s2,16(sp)
    800027ba:	e44e                	sd	s3,8(sp)
    800027bc:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r"(x));
    800027be:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r"(x));
    800027c2:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r"(x));
    800027c6:	142027f3          	csrr	a5,scause
    800027ca:	89be                	mv	s3,a5
  if ((sstatus & SSTATUS_SPP) == 0)
    800027cc:	1004f793          	andi	a5,s1,256
    800027d0:	c795                	beqz	a5,800027fc <kerneltrap+0x4c>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    800027d2:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    800027d6:	8b89                	andi	a5,a5,2
  if (intr_get() != 0)
    800027d8:	eb85                	bnez	a5,80002808 <kerneltrap+0x58>
  if ((which_dev = devintr()) == 0) {
    800027da:	e3bff0ef          	jal	80002614 <devintr>
    800027de:	c91d                	beqz	a0,80002814 <kerneltrap+0x64>
  if (which_dev == 2 && myproc() != 0) {
    800027e0:	4789                	li	a5,2
    800027e2:	04f50a63          	beq	a0,a5,80002836 <kerneltrap+0x86>
  asm volatile("csrw sepc, %0" : : "r"(x));
    800027e6:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r"(x));
    800027ea:	10049073          	csrw	sstatus,s1
}
    800027ee:	70a2                	ld	ra,40(sp)
    800027f0:	7402                	ld	s0,32(sp)
    800027f2:	64e2                	ld	s1,24(sp)
    800027f4:	6942                	ld	s2,16(sp)
    800027f6:	69a2                	ld	s3,8(sp)
    800027f8:	6145                	addi	sp,sp,48
    800027fa:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    800027fc:	00005517          	auipc	a0,0x5
    80002800:	b4c50513          	addi	a0,a0,-1204 # 80007348 <etext+0x348>
    80002804:	82efe0ef          	jal	80000832 <panic>
    panic("kerneltrap: interrupts enabled");
    80002808:	00005517          	auipc	a0,0x5
    8000280c:	b6850513          	addi	a0,a0,-1176 # 80007370 <etext+0x370>
    80002810:	822fe0ef          	jal	80000832 <panic>
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002814:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r"(x));
    80002818:	143026f3          	csrr	a3,stval
    printk("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(),
    8000281c:	85ce                	mv	a1,s3
    8000281e:	00005517          	auipc	a0,0x5
    80002822:	b7250513          	addi	a0,a0,-1166 # 80007390 <etext+0x390>
    80002826:	cd5fd0ef          	jal	800004fa <printk>
    panic("kerneltrap");
    8000282a:	00005517          	auipc	a0,0x5
    8000282e:	b8e50513          	addi	a0,a0,-1138 # 800073b8 <etext+0x3b8>
    80002832:	800fe0ef          	jal	80000832 <panic>
  if (which_dev == 2 && myproc() != 0) {
    80002836:	8e0ff0ef          	jal	80001916 <myproc>
    8000283a:	d555                	beqz	a0,800027e6 <kerneltrap+0x36>
    struct proc *p = myproc();
    8000283c:	8daff0ef          	jal	80001916 <myproc>
    80002840:	89aa                	mv	s3,a0
    acquire(&p->lock);
    80002842:	bcefe0ef          	jal	80000c10 <acquire>
    if(p->priority <= 198) {
    80002846:	1689a783          	lw	a5,360(s3)
    8000284a:	873e                	mv	a4,a5
    8000284c:	2781                	sext.w	a5,a5
    8000284e:	0c600693          	li	a3,198
    80002852:	00f6d463          	bge	a3,a5,8000285a <kerneltrap+0xaa>
    80002856:	0c600713          	li	a4,198
    8000285a:	2709                	addiw	a4,a4,2
    8000285c:	16e9a423          	sw	a4,360(s3)
    release(&p->lock);
    80002860:	854e                	mv	a0,s3
    80002862:	c40fe0ef          	jal	80000ca2 <release>
	yield();
    80002866:	f12ff0ef          	jal	80001f78 <yield>
    8000286a:	bfb5                	j	800027e6 <kerneltrap+0x36>

000000008000286c <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    8000286c:	1101                	addi	sp,sp,-32
    8000286e:	ec06                	sd	ra,24(sp)
    80002870:	e822                	sd	s0,16(sp)
    80002872:	e426                	sd	s1,8(sp)
    80002874:	1000                	addi	s0,sp,32
    80002876:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80002878:	89eff0ef          	jal	80001916 <myproc>
  switch (n) {
    8000287c:	4795                	li	a5,5
    8000287e:	0497e163          	bltu	a5,s1,800028c0 <argraw+0x54>
    80002882:	048a                	slli	s1,s1,0x2
    80002884:	00005717          	auipc	a4,0x5
    80002888:	f3470713          	addi	a4,a4,-204 # 800077b8 <states.0+0x30>
    8000288c:	94ba                	add	s1,s1,a4
    8000288e:	409c                	lw	a5,0(s1)
    80002890:	97ba                	add	a5,a5,a4
    80002892:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80002894:	6d3c                	ld	a5,88(a0)
    80002896:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80002898:	60e2                	ld	ra,24(sp)
    8000289a:	6442                	ld	s0,16(sp)
    8000289c:	64a2                	ld	s1,8(sp)
    8000289e:	6105                	addi	sp,sp,32
    800028a0:	8082                	ret
    return p->trapframe->a1;
    800028a2:	6d3c                	ld	a5,88(a0)
    800028a4:	7fa8                	ld	a0,120(a5)
    800028a6:	bfcd                	j	80002898 <argraw+0x2c>
    return p->trapframe->a2;
    800028a8:	6d3c                	ld	a5,88(a0)
    800028aa:	63c8                	ld	a0,128(a5)
    800028ac:	b7f5                	j	80002898 <argraw+0x2c>
    return p->trapframe->a3;
    800028ae:	6d3c                	ld	a5,88(a0)
    800028b0:	67c8                	ld	a0,136(a5)
    800028b2:	b7dd                	j	80002898 <argraw+0x2c>
    return p->trapframe->a4;
    800028b4:	6d3c                	ld	a5,88(a0)
    800028b6:	6bc8                	ld	a0,144(a5)
    800028b8:	b7c5                	j	80002898 <argraw+0x2c>
    return p->trapframe->a5;
    800028ba:	6d3c                	ld	a5,88(a0)
    800028bc:	6fc8                	ld	a0,152(a5)
    800028be:	bfe9                	j	80002898 <argraw+0x2c>
  panic("argraw");
    800028c0:	00005517          	auipc	a0,0x5
    800028c4:	b0850513          	addi	a0,a0,-1272 # 800073c8 <etext+0x3c8>
    800028c8:	f6bfd0ef          	jal	80000832 <panic>

00000000800028cc <fetchaddr>:
{
    800028cc:	1101                	addi	sp,sp,-32
    800028ce:	ec06                	sd	ra,24(sp)
    800028d0:	e822                	sd	s0,16(sp)
    800028d2:	e426                	sd	s1,8(sp)
    800028d4:	e04a                	sd	s2,0(sp)
    800028d6:	1000                	addi	s0,sp,32
    800028d8:	84aa                	mv	s1,a0
    800028da:	892e                	mv	s2,a1
  struct proc *p = myproc();
    800028dc:	83aff0ef          	jal	80001916 <myproc>
  if (addr >= p->sz ||
    800028e0:	652c                	ld	a1,72(a0)
    800028e2:	02b4f663          	bgeu	s1,a1,8000290e <fetchaddr+0x42>
      addr + sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    800028e6:	00848793          	addi	a5,s1,8
  if (addr >= p->sz ||
    800028ea:	02f5e263          	bltu	a1,a5,8000290e <fetchaddr+0x42>
  if (copyin(p->pagetable, p->sz, (char *)ip, addr, sizeof(*ip)) != 0)
    800028ee:	4721                	li	a4,8
    800028f0:	86a6                	mv	a3,s1
    800028f2:	864a                	mv	a2,s2
    800028f4:	6928                	ld	a0,80(a0)
    800028f6:	d2bfe0ef          	jal	80001620 <copyin>
    800028fa:	00a03533          	snez	a0,a0
    800028fe:	40a0053b          	negw	a0,a0
}
    80002902:	60e2                	ld	ra,24(sp)
    80002904:	6442                	ld	s0,16(sp)
    80002906:	64a2                	ld	s1,8(sp)
    80002908:	6902                	ld	s2,0(sp)
    8000290a:	6105                	addi	sp,sp,32
    8000290c:	8082                	ret
    return -1;
    8000290e:	557d                	li	a0,-1
    80002910:	bfcd                	j	80002902 <fetchaddr+0x36>

0000000080002912 <fetchstr>:
{
    80002912:	7179                	addi	sp,sp,-48
    80002914:	f406                	sd	ra,40(sp)
    80002916:	f022                	sd	s0,32(sp)
    80002918:	ec26                	sd	s1,24(sp)
    8000291a:	e84a                	sd	s2,16(sp)
    8000291c:	e44e                	sd	s3,8(sp)
    8000291e:	1800                	addi	s0,sp,48
    80002920:	89aa                	mv	s3,a0
    80002922:	84ae                	mv	s1,a1
    80002924:	8932                	mv	s2,a2
  struct proc *p = myproc();
    80002926:	ff1fe0ef          	jal	80001916 <myproc>
  if (copyinstr(p->pagetable, p->sz, buf, addr, max) < 0)
    8000292a:	874a                	mv	a4,s2
    8000292c:	86ce                	mv	a3,s3
    8000292e:	8626                	mv	a2,s1
    80002930:	652c                	ld	a1,72(a0)
    80002932:	6928                	ld	a0,80(a0)
    80002934:	d8bfe0ef          	jal	800016be <copyinstr>
    80002938:	00054c63          	bltz	a0,80002950 <fetchstr+0x3e>
  return strlen(buf);
    8000293c:	8526                	mv	a0,s1
    8000293e:	d2afe0ef          	jal	80000e68 <strlen>
}
    80002942:	70a2                	ld	ra,40(sp)
    80002944:	7402                	ld	s0,32(sp)
    80002946:	64e2                	ld	s1,24(sp)
    80002948:	6942                	ld	s2,16(sp)
    8000294a:	69a2                	ld	s3,8(sp)
    8000294c:	6145                	addi	sp,sp,48
    8000294e:	8082                	ret
    return -1;
    80002950:	557d                	li	a0,-1
    80002952:	bfc5                	j	80002942 <fetchstr+0x30>

0000000080002954 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80002954:	1101                	addi	sp,sp,-32
    80002956:	ec06                	sd	ra,24(sp)
    80002958:	e822                	sd	s0,16(sp)
    8000295a:	e426                	sd	s1,8(sp)
    8000295c:	1000                	addi	s0,sp,32
    8000295e:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002960:	f0dff0ef          	jal	8000286c <argraw>
    80002964:	c088                	sw	a0,0(s1)
}
    80002966:	60e2                	ld	ra,24(sp)
    80002968:	6442                	ld	s0,16(sp)
    8000296a:	64a2                	ld	s1,8(sp)
    8000296c:	6105                	addi	sp,sp,32
    8000296e:	8082                	ret

0000000080002970 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80002970:	1101                	addi	sp,sp,-32
    80002972:	ec06                	sd	ra,24(sp)
    80002974:	e822                	sd	s0,16(sp)
    80002976:	e426                	sd	s1,8(sp)
    80002978:	1000                	addi	s0,sp,32
    8000297a:	84ae                	mv	s1,a1
  *ip = argraw(n);
    8000297c:	ef1ff0ef          	jal	8000286c <argraw>
    80002980:	e088                	sd	a0,0(s1)
}
    80002982:	60e2                	ld	ra,24(sp)
    80002984:	6442                	ld	s0,16(sp)
    80002986:	64a2                	ld	s1,8(sp)
    80002988:	6105                	addi	sp,sp,32
    8000298a:	8082                	ret

000000008000298c <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (not including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    8000298c:	1101                	addi	sp,sp,-32
    8000298e:	ec06                	sd	ra,24(sp)
    80002990:	e822                	sd	s0,16(sp)
    80002992:	e426                	sd	s1,8(sp)
    80002994:	e04a                	sd	s2,0(sp)
    80002996:	1000                	addi	s0,sp,32
    80002998:	892e                	mv	s2,a1
    8000299a:	84b2                	mv	s1,a2
  *ip = argraw(n);
    8000299c:	ed1ff0ef          	jal	8000286c <argraw>
  uint64 addr;
  argaddr(n, &addr);
  return fetchstr(addr, buf, max);
    800029a0:	8626                	mv	a2,s1
    800029a2:	85ca                	mv	a1,s2
    800029a4:	f6fff0ef          	jal	80002912 <fetchstr>
}
    800029a8:	60e2                	ld	ra,24(sp)
    800029aa:	6442                	ld	s0,16(sp)
    800029ac:	64a2                	ld	s1,8(sp)
    800029ae:	6902                	ld	s2,0(sp)
    800029b0:	6105                	addi	sp,sp,32
    800029b2:	8082                	ret

00000000800029b4 <syscall>:
  // clang-format on
};

void
syscall(void)
{
    800029b4:	1101                	addi	sp,sp,-32
    800029b6:	ec06                	sd	ra,24(sp)
    800029b8:	e822                	sd	s0,16(sp)
    800029ba:	e426                	sd	s1,8(sp)
    800029bc:	e04a                	sd	s2,0(sp)
    800029be:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    800029c0:	f57fe0ef          	jal	80001916 <myproc>
    800029c4:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    800029c6:	05853903          	ld	s2,88(a0)
    800029ca:	0a893783          	ld	a5,168(s2)
    800029ce:	0007869b          	sext.w	a3,a5
  if (num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    800029d2:	37fd                	addiw	a5,a5,-1
    800029d4:	4759                	li	a4,22
    800029d6:	00f76f63          	bltu	a4,a5,800029f4 <syscall+0x40>
    800029da:	00369713          	slli	a4,a3,0x3
    800029de:	00005797          	auipc	a5,0x5
    800029e2:	df278793          	addi	a5,a5,-526 # 800077d0 <syscalls>
    800029e6:	97ba                	add	a5,a5,a4
    800029e8:	639c                	ld	a5,0(a5)
    800029ea:	c789                	beqz	a5,800029f4 <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    800029ec:	9782                	jalr	a5
    800029ee:	06a93823          	sd	a0,112(s2)
    800029f2:	a829                	j	80002a0c <syscall+0x58>
  } else {
    printk("%d %s: unknown sys call %d\n", p->pid, p->name, num);
    800029f4:	15848613          	addi	a2,s1,344
    800029f8:	588c                	lw	a1,48(s1)
    800029fa:	00005517          	auipc	a0,0x5
    800029fe:	9d650513          	addi	a0,a0,-1578 # 800073d0 <etext+0x3d0>
    80002a02:	af9fd0ef          	jal	800004fa <printk>
    p->trapframe->a0 = -1;
    80002a06:	6cbc                	ld	a5,88(s1)
    80002a08:	577d                	li	a4,-1
    80002a0a:	fbb8                	sd	a4,112(a5)
  }
}
    80002a0c:	60e2                	ld	ra,24(sp)
    80002a0e:	6442                	ld	s0,16(sp)
    80002a10:	64a2                	ld	s1,8(sp)
    80002a12:	6902                	ld	s2,0(sp)
    80002a14:	6105                	addi	sp,sp,32
    80002a16:	8082                	ret

0000000080002a18 <sys_exit>:
#include "proc.h"
#include "vm.h"

uint64
sys_exit(void)
{
    80002a18:	1101                	addi	sp,sp,-32
    80002a1a:	ec06                	sd	ra,24(sp)
    80002a1c:	e822                	sd	s0,16(sp)
    80002a1e:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80002a20:	fec40593          	addi	a1,s0,-20
    80002a24:	4501                	li	a0,0
    80002a26:	f2fff0ef          	jal	80002954 <argint>
  kexit(n);
    80002a2a:	fec42503          	lw	a0,-20(s0)
    80002a2e:	eceff0ef          	jal	800020fc <kexit>
  return 0; // not reached
}
    80002a32:	4501                	li	a0,0
    80002a34:	60e2                	ld	ra,24(sp)
    80002a36:	6442                	ld	s0,16(sp)
    80002a38:	6105                	addi	sp,sp,32
    80002a3a:	8082                	ret

0000000080002a3c <sys_getpid>:

uint64
sys_getpid(void)
{
    80002a3c:	1141                	addi	sp,sp,-16
    80002a3e:	e406                	sd	ra,8(sp)
    80002a40:	e022                	sd	s0,0(sp)
    80002a42:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80002a44:	ed3fe0ef          	jal	80001916 <myproc>
}
    80002a48:	5908                	lw	a0,48(a0)
    80002a4a:	60a2                	ld	ra,8(sp)
    80002a4c:	6402                	ld	s0,0(sp)
    80002a4e:	0141                	addi	sp,sp,16
    80002a50:	8082                	ret

0000000080002a52 <sys_fork>:

uint64
sys_fork(void)
{
    80002a52:	1141                	addi	sp,sp,-16
    80002a54:	e406                	sd	ra,8(sp)
    80002a56:	e022                	sd	s0,0(sp)
    80002a58:	0800                	addi	s0,sp,16
  return kfork();
    80002a5a:	a1eff0ef          	jal	80001c78 <kfork>
}
    80002a5e:	60a2                	ld	ra,8(sp)
    80002a60:	6402                	ld	s0,0(sp)
    80002a62:	0141                	addi	sp,sp,16
    80002a64:	8082                	ret

0000000080002a66 <sys_wait>:

uint64
sys_wait(void)
{
    80002a66:	1101                	addi	sp,sp,-32
    80002a68:	ec06                	sd	ra,24(sp)
    80002a6a:	e822                	sd	s0,16(sp)
    80002a6c:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80002a6e:	fe840593          	addi	a1,s0,-24
    80002a72:	4501                	li	a0,0
    80002a74:	efdff0ef          	jal	80002970 <argaddr>
  return kwait(p);
    80002a78:	fe843503          	ld	a0,-24(s0)
    80002a7c:	ff2ff0ef          	jal	8000226e <kwait>
}
    80002a80:	60e2                	ld	ra,24(sp)
    80002a82:	6442                	ld	s0,16(sp)
    80002a84:	6105                	addi	sp,sp,32
    80002a86:	8082                	ret

0000000080002a88 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80002a88:	7179                	addi	sp,sp,-48
    80002a8a:	f406                	sd	ra,40(sp)
    80002a8c:	f022                	sd	s0,32(sp)
    80002a8e:	ec26                	sd	s1,24(sp)
    80002a90:	1800                	addi	s0,sp,48
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
    80002a92:	fd840593          	addi	a1,s0,-40
    80002a96:	4501                	li	a0,0
    80002a98:	ebdff0ef          	jal	80002954 <argint>
  argint(1, &t);
    80002a9c:	fdc40593          	addi	a1,s0,-36
    80002aa0:	4505                	li	a0,1
    80002aa2:	eb3ff0ef          	jal	80002954 <argint>
  addr = myproc()->sz;
    80002aa6:	e71fe0ef          	jal	80001916 <myproc>
    80002aaa:	6524                	ld	s1,72(a0)

  if (t == SBRK_EAGER || n < 0) {
    80002aac:	fdc42703          	lw	a4,-36(s0)
    80002ab0:	4785                	li	a5,1
    80002ab2:	02f70a63          	beq	a4,a5,80002ae6 <sys_sbrk+0x5e>
    80002ab6:	fd842783          	lw	a5,-40(s0)
    80002aba:	0207c663          	bltz	a5,80002ae6 <sys_sbrk+0x5e>
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if (addr + n < addr)
    80002abe:	00978733          	add	a4,a5,s1
      return -1;
    if (addr + n > TRAPFRAME)
    80002ac2:	020007b7          	lui	a5,0x2000
    80002ac6:	17fd                	addi	a5,a5,-1 # 1ffffff <_entry-0x7e000001>
    80002ac8:	07b6                	slli	a5,a5,0xd
    80002aca:	00e7b7b3          	sltu	a5,a5,a4
    if (addr + n < addr)
    80002ace:	00973733          	sltu	a4,a4,s1
    if (addr + n > TRAPFRAME)
    80002ad2:	8fd9                	or	a5,a5,a4
    80002ad4:	e79d                	bnez	a5,80002b02 <sys_sbrk+0x7a>
      return -1;
    myproc()->sz += n;
    80002ad6:	e41fe0ef          	jal	80001916 <myproc>
    80002ada:	fd842703          	lw	a4,-40(s0)
    80002ade:	653c                	ld	a5,72(a0)
    80002ae0:	97ba                	add	a5,a5,a4
    80002ae2:	e53c                	sd	a5,72(a0)
    80002ae4:	a039                	j	80002af2 <sys_sbrk+0x6a>
    if (growproc(n) < 0) {
    80002ae6:	fd842503          	lw	a0,-40(s0)
    80002aea:	930ff0ef          	jal	80001c1a <growproc>
    80002aee:	00054863          	bltz	a0,80002afe <sys_sbrk+0x76>
  }
  return addr;
}
    80002af2:	8526                	mv	a0,s1
    80002af4:	70a2                	ld	ra,40(sp)
    80002af6:	7402                	ld	s0,32(sp)
    80002af8:	64e2                	ld	s1,24(sp)
    80002afa:	6145                	addi	sp,sp,48
    80002afc:	8082                	ret
      return -1;
    80002afe:	54fd                	li	s1,-1
    80002b00:	bfcd                	j	80002af2 <sys_sbrk+0x6a>
      return -1;
    80002b02:	54fd                	li	s1,-1
    80002b04:	b7fd                	j	80002af2 <sys_sbrk+0x6a>

0000000080002b06 <sys_pause>:

uint64
sys_pause(void)
{
    80002b06:	1141                	addi	sp,sp,-16
    80002b08:	e406                	sd	ra,8(sp)
    80002b0a:	e022                	sd	s0,0(sp)
    80002b0c:	0800                	addi	s0,sp,16
  acquire(&tickslock);
    80002b0e:	00013517          	auipc	a0,0x13
    80002b12:	efa50513          	addi	a0,a0,-262 # 80015a08 <tickslock>
    80002b16:	8fafe0ef          	jal	80000c10 <acquire>
  
  sleep(&ticks, &tickslock);
    80002b1a:	00013597          	auipc	a1,0x13
    80002b1e:	eee58593          	addi	a1,a1,-274 # 80015a08 <tickslock>
    80002b22:	00005517          	auipc	a0,0x5
    80002b26:	dae50513          	addi	a0,a0,-594 # 800078d0 <ticks>
    80002b2a:	cb6ff0ef          	jal	80001fe0 <sleep>
  
  release(&tickslock);
    80002b2e:	00013517          	auipc	a0,0x13
    80002b32:	eda50513          	addi	a0,a0,-294 # 80015a08 <tickslock>
    80002b36:	96cfe0ef          	jal	80000ca2 <release>
  return 0;
}
    80002b3a:	4501                	li	a0,0
    80002b3c:	60a2                	ld	ra,8(sp)
    80002b3e:	6402                	ld	s0,0(sp)
    80002b40:	0141                	addi	sp,sp,16
    80002b42:	8082                	ret

0000000080002b44 <sys_kill>:


uint64
sys_kill(void)
{
    80002b44:	1101                	addi	sp,sp,-32
    80002b46:	ec06                	sd	ra,24(sp)
    80002b48:	e822                	sd	s0,16(sp)
    80002b4a:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002b4c:	fec40593          	addi	a1,s0,-20
    80002b50:	4501                	li	a0,0
    80002b52:	e03ff0ef          	jal	80002954 <argint>
  return kkill(pid);
    80002b56:	fec42503          	lw	a0,-20(s0)
    80002b5a:	e48ff0ef          	jal	800021a2 <kkill>
}
    80002b5e:	60e2                	ld	ra,24(sp)
    80002b60:	6442                	ld	s0,16(sp)
    80002b62:	6105                	addi	sp,sp,32
    80002b64:	8082                	ret

0000000080002b66 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002b66:	1101                	addi	sp,sp,-32
    80002b68:	ec06                	sd	ra,24(sp)
    80002b6a:	e822                	sd	s0,16(sp)
    80002b6c:	e426                	sd	s1,8(sp)
    80002b6e:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002b70:	00013517          	auipc	a0,0x13
    80002b74:	e9850513          	addi	a0,a0,-360 # 80015a08 <tickslock>
    80002b78:	898fe0ef          	jal	80000c10 <acquire>
  xticks = ticks;
    80002b7c:	00005797          	auipc	a5,0x5
    80002b80:	d547a783          	lw	a5,-684(a5) # 800078d0 <ticks>
    80002b84:	84be                	mv	s1,a5
  release(&tickslock);
    80002b86:	00013517          	auipc	a0,0x13
    80002b8a:	e8250513          	addi	a0,a0,-382 # 80015a08 <tickslock>
    80002b8e:	914fe0ef          	jal	80000ca2 <release>
  return xticks;
}
    80002b92:	02049513          	slli	a0,s1,0x20
    80002b96:	9101                	srli	a0,a0,0x20
    80002b98:	60e2                	ld	ra,24(sp)
    80002b9a:	6442                	ld	s0,16(sp)
    80002b9c:	64a2                	ld	s1,8(sp)
    80002b9e:	6105                	addi	sp,sp,32
    80002ba0:	8082                	ret

0000000080002ba2 <sys_setpriority>:

uint64
sys_setpriority(void)
{
    80002ba2:	7179                	addi	sp,sp,-48
    80002ba4:	f406                	sd	ra,40(sp)
    80002ba6:	f022                	sd	s0,32(sp)
    80002ba8:	ec26                	sd	s1,24(sp)
    80002baa:	1800                	addi	s0,sp,48
  int new_priority;
  int old_priority;
  struct proc *p = myproc();
    80002bac:	d6bfe0ef          	jal	80001916 <myproc>
    80002bb0:	84aa                	mv	s1,a0

  // Extract the first integer argument
  argint(0, &new_priority);
    80002bb2:	fdc40593          	addi	a1,s0,-36
    80002bb6:	4501                	li	a0,0
    80002bb8:	d9dff0ef          	jal	80002954 <argint>

  // Reject values outside 0 through 200
  if (new_priority < 0 || new_priority > 200) {
    80002bbc:	fdc42703          	lw	a4,-36(s0)
    80002bc0:	0c800793          	li	a5,200
    return -1;
    80002bc4:	557d                	li	a0,-1
  if (new_priority < 0 || new_priority > 200) {
    80002bc6:	02e7e763          	bltu	a5,a4,80002bf4 <sys_setpriority+0x52>
    80002bca:	e84a                	sd	s2,16(sp)
  }

  acquire(&p->lock);
    80002bcc:	8526                	mv	a0,s1
    80002bce:	842fe0ef          	jal	80000c10 <acquire>
  
  // Save current priority for evaluation and eventual return
  old_priority = p->priority;
    80002bd2:	1684a783          	lw	a5,360(s1)
    80002bd6:	873e                	mv	a4,a5
    80002bd8:	893e                	mv	s2,a5
  
  // Assign the new priority requested by user space
  p->priority = new_priority;
    80002bda:	fdc42783          	lw	a5,-36(s0)
    80002bde:	16f4a423          	sw	a5,360(s1)

  if (new_priority > old_priority) {
    80002be2:	00f75e63          	bge	a4,a5,80002bfe <sys_setpriority+0x5c>
    release(&p->lock);
    80002be6:	8526                	mv	a0,s1
    80002be8:	8bafe0ef          	jal	80000ca2 <release>
    yield();
    80002bec:	b8cff0ef          	jal	80001f78 <yield>
  } else {
    release(&p->lock);
  }

  return (uint64)old_priority;
    80002bf0:	854a                	mv	a0,s2
    80002bf2:	6942                	ld	s2,16(sp)
}
    80002bf4:	70a2                	ld	ra,40(sp)
    80002bf6:	7402                	ld	s0,32(sp)
    80002bf8:	64e2                	ld	s1,24(sp)
    80002bfa:	6145                	addi	sp,sp,48
    80002bfc:	8082                	ret
    release(&p->lock);
    80002bfe:	8526                	mv	a0,s1
    80002c00:	8a2fe0ef          	jal	80000ca2 <release>
    80002c04:	b7f5                	j	80002bf0 <sys_setpriority+0x4e>

0000000080002c06 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002c06:	7179                	addi	sp,sp,-48
    80002c08:	f406                	sd	ra,40(sp)
    80002c0a:	f022                	sd	s0,32(sp)
    80002c0c:	ec26                	sd	s1,24(sp)
    80002c0e:	e84a                	sd	s2,16(sp)
    80002c10:	e44e                	sd	s3,8(sp)
    80002c12:	e052                	sd	s4,0(sp)
    80002c14:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002c16:	00004597          	auipc	a1,0x4
    80002c1a:	7da58593          	addi	a1,a1,2010 # 800073f0 <etext+0x3f0>
    80002c1e:	00013517          	auipc	a0,0x13
    80002c22:	e0250513          	addi	a0,a0,-510 # 80015a20 <bcache>
    80002c26:	f6bfd0ef          	jal	80000b90 <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002c2a:	0001b797          	auipc	a5,0x1b
    80002c2e:	df678793          	addi	a5,a5,-522 # 8001da20 <bcache+0x8000>
    80002c32:	0001b717          	auipc	a4,0x1b
    80002c36:	05670713          	addi	a4,a4,86 # 8001dc88 <bcache+0x8268>
    80002c3a:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002c3e:	2ae7bc23          	sd	a4,696(a5)
  for (b = bcache.buf; b < bcache.buf + NBUF; b++) {
    80002c42:	00013497          	auipc	s1,0x13
    80002c46:	df648493          	addi	s1,s1,-522 # 80015a38 <bcache+0x18>
    b->next = bcache.head.next;
    80002c4a:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002c4c:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002c4e:	00004a17          	auipc	s4,0x4
    80002c52:	7aaa0a13          	addi	s4,s4,1962 # 800073f8 <etext+0x3f8>
    b->next = bcache.head.next;
    80002c56:	2b893783          	ld	a5,696(s2)
    80002c5a:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002c5c:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002c60:	85d2                	mv	a1,s4
    80002c62:	01048513          	addi	a0,s1,16
    80002c66:	436010ef          	jal	8000409c <initsleeplock>
    bcache.head.next->prev = b;
    80002c6a:	2b893783          	ld	a5,696(s2)
    80002c6e:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002c70:	2a993c23          	sd	s1,696(s2)
  for (b = bcache.buf; b < bcache.buf + NBUF; b++) {
    80002c74:	45848493          	addi	s1,s1,1112
    80002c78:	fd349fe3          	bne	s1,s3,80002c56 <binit+0x50>
  }
}
    80002c7c:	70a2                	ld	ra,40(sp)
    80002c7e:	7402                	ld	s0,32(sp)
    80002c80:	64e2                	ld	s1,24(sp)
    80002c82:	6942                	ld	s2,16(sp)
    80002c84:	69a2                	ld	s3,8(sp)
    80002c86:	6a02                	ld	s4,0(sp)
    80002c88:	6145                	addi	sp,sp,48
    80002c8a:	8082                	ret

0000000080002c8c <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf *
bread(uint dev, uint blockno)
{
    80002c8c:	7179                	addi	sp,sp,-48
    80002c8e:	f406                	sd	ra,40(sp)
    80002c90:	f022                	sd	s0,32(sp)
    80002c92:	ec26                	sd	s1,24(sp)
    80002c94:	e84a                	sd	s2,16(sp)
    80002c96:	e44e                	sd	s3,8(sp)
    80002c98:	1800                	addi	s0,sp,48
    80002c9a:	892a                	mv	s2,a0
    80002c9c:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002c9e:	00013517          	auipc	a0,0x13
    80002ca2:	d8250513          	addi	a0,a0,-638 # 80015a20 <bcache>
    80002ca6:	f6bfd0ef          	jal	80000c10 <acquire>
  for (b = bcache.head.next; b != &bcache.head; b = b->next) {
    80002caa:	0001b497          	auipc	s1,0x1b
    80002cae:	02e4b483          	ld	s1,46(s1) # 8001dcd8 <bcache+0x82b8>
    80002cb2:	0001b797          	auipc	a5,0x1b
    80002cb6:	fd678793          	addi	a5,a5,-42 # 8001dc88 <bcache+0x8268>
    80002cba:	02f48b63          	beq	s1,a5,80002cf0 <bread+0x64>
    80002cbe:	873e                	mv	a4,a5
    80002cc0:	a021                	j	80002cc8 <bread+0x3c>
    80002cc2:	68a4                	ld	s1,80(s1)
    80002cc4:	02e48663          	beq	s1,a4,80002cf0 <bread+0x64>
    if (b->dev == dev && b->blockno == blockno) {
    80002cc8:	449c                	lw	a5,8(s1)
    80002cca:	ff279ce3          	bne	a5,s2,80002cc2 <bread+0x36>
    80002cce:	44dc                	lw	a5,12(s1)
    80002cd0:	ff3799e3          	bne	a5,s3,80002cc2 <bread+0x36>
      b->refcnt++;
    80002cd4:	40bc                	lw	a5,64(s1)
    80002cd6:	2785                	addiw	a5,a5,1
    80002cd8:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002cda:	00013517          	auipc	a0,0x13
    80002cde:	d4650513          	addi	a0,a0,-698 # 80015a20 <bcache>
    80002ce2:	fc1fd0ef          	jal	80000ca2 <release>
      acquiresleep(&b->lock);
    80002ce6:	01048513          	addi	a0,s1,16
    80002cea:	3e8010ef          	jal	800040d2 <acquiresleep>
      return b;
    80002cee:	a889                	j	80002d40 <bread+0xb4>
  for (b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    80002cf0:	0001b497          	auipc	s1,0x1b
    80002cf4:	fe04b483          	ld	s1,-32(s1) # 8001dcd0 <bcache+0x82b0>
    80002cf8:	0001b797          	auipc	a5,0x1b
    80002cfc:	f9078793          	addi	a5,a5,-112 # 8001dc88 <bcache+0x8268>
    80002d00:	00f48863          	beq	s1,a5,80002d10 <bread+0x84>
    80002d04:	873e                	mv	a4,a5
    if (b->refcnt == 0) {
    80002d06:	40bc                	lw	a5,64(s1)
    80002d08:	cb91                	beqz	a5,80002d1c <bread+0x90>
  for (b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    80002d0a:	64a4                	ld	s1,72(s1)
    80002d0c:	fee49de3          	bne	s1,a4,80002d06 <bread+0x7a>
  panic("bget: no buffers");
    80002d10:	00004517          	auipc	a0,0x4
    80002d14:	6f050513          	addi	a0,a0,1776 # 80007400 <etext+0x400>
    80002d18:	b1bfd0ef          	jal	80000832 <panic>
      b->dev = dev;
    80002d1c:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002d20:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002d24:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002d28:	4785                	li	a5,1
    80002d2a:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002d2c:	00013517          	auipc	a0,0x13
    80002d30:	cf450513          	addi	a0,a0,-780 # 80015a20 <bcache>
    80002d34:	f6ffd0ef          	jal	80000ca2 <release>
      acquiresleep(&b->lock);
    80002d38:	01048513          	addi	a0,s1,16
    80002d3c:	396010ef          	jal	800040d2 <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if (!b->valid) {
    80002d40:	409c                	lw	a5,0(s1)
    80002d42:	cb89                	beqz	a5,80002d54 <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80002d44:	8526                	mv	a0,s1
    80002d46:	70a2                	ld	ra,40(sp)
    80002d48:	7402                	ld	s0,32(sp)
    80002d4a:	64e2                	ld	s1,24(sp)
    80002d4c:	6942                	ld	s2,16(sp)
    80002d4e:	69a2                	ld	s3,8(sp)
    80002d50:	6145                	addi	sp,sp,48
    80002d52:	8082                	ret
    virtio_disk_rw(b, 0);
    80002d54:	4581                	li	a1,0
    80002d56:	8526                	mv	a0,s1
    80002d58:	421020ef          	jal	80005978 <virtio_disk_rw>
    b->valid = 1;
    80002d5c:	4785                	li	a5,1
    80002d5e:	c09c                	sw	a5,0(s1)
  return b;
    80002d60:	b7d5                	j	80002d44 <bread+0xb8>

0000000080002d62 <bwrite>:

// Write b's contents to disk.  Must be locked.
// Only the log calls bwrite.
void
bwrite(struct buf *b)
{
    80002d62:	1101                	addi	sp,sp,-32
    80002d64:	ec06                	sd	ra,24(sp)
    80002d66:	e822                	sd	s0,16(sp)
    80002d68:	e426                	sd	s1,8(sp)
    80002d6a:	1000                	addi	s0,sp,32
    80002d6c:	84aa                	mv	s1,a0
  if (!holdingsleep(&b->lock))
    80002d6e:	0541                	addi	a0,a0,16
    80002d70:	3f2010ef          	jal	80004162 <holdingsleep>
    80002d74:	c911                	beqz	a0,80002d88 <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80002d76:	4585                	li	a1,1
    80002d78:	8526                	mv	a0,s1
    80002d7a:	3ff020ef          	jal	80005978 <virtio_disk_rw>
}
    80002d7e:	60e2                	ld	ra,24(sp)
    80002d80:	6442                	ld	s0,16(sp)
    80002d82:	64a2                	ld	s1,8(sp)
    80002d84:	6105                	addi	sp,sp,32
    80002d86:	8082                	ret
    panic("bwrite");
    80002d88:	00004517          	auipc	a0,0x4
    80002d8c:	69050513          	addi	a0,a0,1680 # 80007418 <etext+0x418>
    80002d90:	aa3fd0ef          	jal	80000832 <panic>

0000000080002d94 <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80002d94:	1101                	addi	sp,sp,-32
    80002d96:	ec06                	sd	ra,24(sp)
    80002d98:	e822                	sd	s0,16(sp)
    80002d9a:	e426                	sd	s1,8(sp)
    80002d9c:	e04a                	sd	s2,0(sp)
    80002d9e:	1000                	addi	s0,sp,32
    80002da0:	84aa                	mv	s1,a0
  if (!holdingsleep(&b->lock))
    80002da2:	01050913          	addi	s2,a0,16
    80002da6:	854a                	mv	a0,s2
    80002da8:	3ba010ef          	jal	80004162 <holdingsleep>
    80002dac:	c125                	beqz	a0,80002e0c <brelse+0x78>
    panic("brelse");

  releasesleep(&b->lock);
    80002dae:	854a                	mv	a0,s2
    80002db0:	37a010ef          	jal	8000412a <releasesleep>

  acquire(&bcache.lock);
    80002db4:	00013517          	auipc	a0,0x13
    80002db8:	c6c50513          	addi	a0,a0,-916 # 80015a20 <bcache>
    80002dbc:	e55fd0ef          	jal	80000c10 <acquire>
  b->refcnt--;
    80002dc0:	40bc                	lw	a5,64(s1)
    80002dc2:	37fd                	addiw	a5,a5,-1
    80002dc4:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80002dc6:	e79d                	bnez	a5,80002df4 <brelse+0x60>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80002dc8:	68b8                	ld	a4,80(s1)
    80002dca:	64bc                	ld	a5,72(s1)
    80002dcc:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    80002dce:	68b8                	ld	a4,80(s1)
    80002dd0:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80002dd2:	0001b797          	auipc	a5,0x1b
    80002dd6:	c4e78793          	addi	a5,a5,-946 # 8001da20 <bcache+0x8000>
    80002dda:	2b87b703          	ld	a4,696(a5)
    80002dde:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80002de0:	0001b717          	auipc	a4,0x1b
    80002de4:	ea870713          	addi	a4,a4,-344 # 8001dc88 <bcache+0x8268>
    80002de8:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80002dea:	2b87b703          	ld	a4,696(a5)
    80002dee:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80002df0:	2a97bc23          	sd	s1,696(a5)
  }

  release(&bcache.lock);
    80002df4:	00013517          	auipc	a0,0x13
    80002df8:	c2c50513          	addi	a0,a0,-980 # 80015a20 <bcache>
    80002dfc:	ea7fd0ef          	jal	80000ca2 <release>
}
    80002e00:	60e2                	ld	ra,24(sp)
    80002e02:	6442                	ld	s0,16(sp)
    80002e04:	64a2                	ld	s1,8(sp)
    80002e06:	6902                	ld	s2,0(sp)
    80002e08:	6105                	addi	sp,sp,32
    80002e0a:	8082                	ret
    panic("brelse");
    80002e0c:	00004517          	auipc	a0,0x4
    80002e10:	61450513          	addi	a0,a0,1556 # 80007420 <etext+0x420>
    80002e14:	a1ffd0ef          	jal	80000832 <panic>

0000000080002e18 <bpin>:

void
bpin(struct buf *b)
{
    80002e18:	1101                	addi	sp,sp,-32
    80002e1a:	ec06                	sd	ra,24(sp)
    80002e1c:	e822                	sd	s0,16(sp)
    80002e1e:	e426                	sd	s1,8(sp)
    80002e20:	1000                	addi	s0,sp,32
    80002e22:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002e24:	00013517          	auipc	a0,0x13
    80002e28:	bfc50513          	addi	a0,a0,-1028 # 80015a20 <bcache>
    80002e2c:	de5fd0ef          	jal	80000c10 <acquire>
  b->refcnt++;
    80002e30:	40bc                	lw	a5,64(s1)
    80002e32:	2785                	addiw	a5,a5,1
    80002e34:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002e36:	00013517          	auipc	a0,0x13
    80002e3a:	bea50513          	addi	a0,a0,-1046 # 80015a20 <bcache>
    80002e3e:	e65fd0ef          	jal	80000ca2 <release>
}
    80002e42:	60e2                	ld	ra,24(sp)
    80002e44:	6442                	ld	s0,16(sp)
    80002e46:	64a2                	ld	s1,8(sp)
    80002e48:	6105                	addi	sp,sp,32
    80002e4a:	8082                	ret

0000000080002e4c <bunpin>:

void
bunpin(struct buf *b)
{
    80002e4c:	1101                	addi	sp,sp,-32
    80002e4e:	ec06                	sd	ra,24(sp)
    80002e50:	e822                	sd	s0,16(sp)
    80002e52:	e426                	sd	s1,8(sp)
    80002e54:	1000                	addi	s0,sp,32
    80002e56:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002e58:	00013517          	auipc	a0,0x13
    80002e5c:	bc850513          	addi	a0,a0,-1080 # 80015a20 <bcache>
    80002e60:	db1fd0ef          	jal	80000c10 <acquire>
  b->refcnt--;
    80002e64:	40bc                	lw	a5,64(s1)
    80002e66:	37fd                	addiw	a5,a5,-1
    80002e68:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002e6a:	00013517          	auipc	a0,0x13
    80002e6e:	bb650513          	addi	a0,a0,-1098 # 80015a20 <bcache>
    80002e72:	e31fd0ef          	jal	80000ca2 <release>
}
    80002e76:	60e2                	ld	ra,24(sp)
    80002e78:	6442                	ld	s0,16(sp)
    80002e7a:	64a2                	ld	s1,8(sp)
    80002e7c:	6105                	addi	sp,sp,32
    80002e7e:	8082                	ret

0000000080002e80 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80002e80:	1101                	addi	sp,sp,-32
    80002e82:	ec06                	sd	ra,24(sp)
    80002e84:	e822                	sd	s0,16(sp)
    80002e86:	e426                	sd	s1,8(sp)
    80002e88:	e04a                	sd	s2,0(sp)
    80002e8a:	1000                	addi	s0,sp,32
    80002e8c:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80002e8e:	00d5d79b          	srliw	a5,a1,0xd
    80002e92:	0001b597          	auipc	a1,0x1b
    80002e96:	26a5a583          	lw	a1,618(a1) # 8001e0fc <sb+0x1c>
    80002e9a:	9dbd                	addw	a1,a1,a5
    80002e9c:	df1ff0ef          	jal	80002c8c <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80002ea0:	0074f713          	andi	a4,s1,7
    80002ea4:	4785                	li	a5,1
    80002ea6:	00e797bb          	sllw	a5,a5,a4
  bi = b % BPB;
    80002eaa:	14ce                	slli	s1,s1,0x33
  if ((bp->data[bi / 8] & m) == 0)
    80002eac:	90d9                	srli	s1,s1,0x36
    80002eae:	00950733          	add	a4,a0,s1
    80002eb2:	05874703          	lbu	a4,88(a4)
    80002eb6:	00e7f6b3          	and	a3,a5,a4
    80002eba:	c29d                	beqz	a3,80002ee0 <bfree+0x60>
    80002ebc:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi / 8] &= ~m;
    80002ebe:	94aa                	add	s1,s1,a0
    80002ec0:	fff7c793          	not	a5,a5
    80002ec4:	8f7d                	and	a4,a4,a5
    80002ec6:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    80002eca:	09a010ef          	jal	80003f64 <log_write>
  brelse(bp);
    80002ece:	854a                	mv	a0,s2
    80002ed0:	ec5ff0ef          	jal	80002d94 <brelse>
}
    80002ed4:	60e2                	ld	ra,24(sp)
    80002ed6:	6442                	ld	s0,16(sp)
    80002ed8:	64a2                	ld	s1,8(sp)
    80002eda:	6902                	ld	s2,0(sp)
    80002edc:	6105                	addi	sp,sp,32
    80002ede:	8082                	ret
    panic("freeing free block");
    80002ee0:	00004517          	auipc	a0,0x4
    80002ee4:	54850513          	addi	a0,a0,1352 # 80007428 <etext+0x428>
    80002ee8:	94bfd0ef          	jal	80000832 <panic>

0000000080002eec <balloc>:
{
    80002eec:	715d                	addi	sp,sp,-80
    80002eee:	e486                	sd	ra,72(sp)
    80002ef0:	e0a2                	sd	s0,64(sp)
    80002ef2:	fc26                	sd	s1,56(sp)
    80002ef4:	0880                	addi	s0,sp,80
  for (b = 0; b < sb.size; b += BPB) {
    80002ef6:	0001b797          	auipc	a5,0x1b
    80002efa:	1ee7a783          	lw	a5,494(a5) # 8001e0e4 <sb+0x4>
    80002efe:	0e078263          	beqz	a5,80002fe2 <balloc+0xf6>
    80002f02:	f84a                	sd	s2,48(sp)
    80002f04:	f44e                	sd	s3,40(sp)
    80002f06:	f052                	sd	s4,32(sp)
    80002f08:	ec56                	sd	s5,24(sp)
    80002f0a:	e85a                	sd	s6,16(sp)
    80002f0c:	e45e                	sd	s7,8(sp)
    80002f0e:	e062                	sd	s8,0(sp)
    80002f10:	8baa                	mv	s7,a0
    80002f12:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80002f14:	0001bb17          	auipc	s6,0x1b
    80002f18:	1ccb0b13          	addi	s6,s6,460 # 8001e0e0 <sb>
      m = 1 << (bi % 8);
    80002f1c:	4985                	li	s3,1
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80002f1e:	6a09                	lui	s4,0x2
  for (b = 0; b < sb.size; b += BPB) {
    80002f20:	6c09                	lui	s8,0x2
    80002f22:	a09d                	j	80002f88 <balloc+0x9c>
        bp->data[bi / 8] |= m;           // Mark block in use.
    80002f24:	97ca                	add	a5,a5,s2
    80002f26:	8e55                	or	a2,a2,a3
    80002f28:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    80002f2c:	854a                	mv	a0,s2
    80002f2e:	036010ef          	jal	80003f64 <log_write>
        brelse(bp);
    80002f32:	854a                	mv	a0,s2
    80002f34:	e61ff0ef          	jal	80002d94 <brelse>
  bp = bread(dev, bno);
    80002f38:	85a6                	mv	a1,s1
    80002f3a:	855e                	mv	a0,s7
    80002f3c:	d51ff0ef          	jal	80002c8c <bread>
    80002f40:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80002f42:	40000613          	li	a2,1024
    80002f46:	4581                	li	a1,0
    80002f48:	05850513          	addi	a0,a0,88
    80002f4c:	d9dfd0ef          	jal	80000ce8 <memset>
  log_write(bp);
    80002f50:	854a                	mv	a0,s2
    80002f52:	012010ef          	jal	80003f64 <log_write>
  brelse(bp);
    80002f56:	854a                	mv	a0,s2
    80002f58:	e3dff0ef          	jal	80002d94 <brelse>
        return b + bi;
    80002f5c:	7942                	ld	s2,48(sp)
    80002f5e:	79a2                	ld	s3,40(sp)
    80002f60:	7a02                	ld	s4,32(sp)
    80002f62:	6ae2                	ld	s5,24(sp)
    80002f64:	6b42                	ld	s6,16(sp)
    80002f66:	6ba2                	ld	s7,8(sp)
    80002f68:	6c02                	ld	s8,0(sp)
}
    80002f6a:	8526                	mv	a0,s1
    80002f6c:	60a6                	ld	ra,72(sp)
    80002f6e:	6406                	ld	s0,64(sp)
    80002f70:	74e2                	ld	s1,56(sp)
    80002f72:	6161                	addi	sp,sp,80
    80002f74:	8082                	ret
    brelse(bp);
    80002f76:	854a                	mv	a0,s2
    80002f78:	e1dff0ef          	jal	80002d94 <brelse>
  for (b = 0; b < sb.size; b += BPB) {
    80002f7c:	015c0abb          	addw	s5,s8,s5
    80002f80:	004b2783          	lw	a5,4(s6)
    80002f84:	04faf863          	bgeu	s5,a5,80002fd4 <balloc+0xe8>
    bp = bread(dev, BBLOCK(b, sb));
    80002f88:	40dad59b          	sraiw	a1,s5,0xd
    80002f8c:	01cb2783          	lw	a5,28(s6)
    80002f90:	9dbd                	addw	a1,a1,a5
    80002f92:	855e                	mv	a0,s7
    80002f94:	cf9ff0ef          	jal	80002c8c <bread>
    80002f98:	892a                	mv	s2,a0
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80002f9a:	004b2503          	lw	a0,4(s6)
    80002f9e:	84d6                	mv	s1,s5
    80002fa0:	4701                	li	a4,0
    80002fa2:	fca4fae3          	bgeu	s1,a0,80002f76 <balloc+0x8a>
      m = 1 << (bi % 8);
    80002fa6:	00777693          	andi	a3,a4,7
    80002faa:	00d996bb          	sllw	a3,s3,a3
      if ((bp->data[bi / 8] & m) == 0) { // Is block free?
    80002fae:	41f7579b          	sraiw	a5,a4,0x1f
    80002fb2:	01d7d79b          	srliw	a5,a5,0x1d
    80002fb6:	9fb9                	addw	a5,a5,a4
    80002fb8:	4037d79b          	sraiw	a5,a5,0x3
    80002fbc:	00f90633          	add	a2,s2,a5
    80002fc0:	05864603          	lbu	a2,88(a2) # 1058 <_entry-0x7fffefa8>
    80002fc4:	00c6f5b3          	and	a1,a3,a2
    80002fc8:	ddb1                	beqz	a1,80002f24 <balloc+0x38>
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80002fca:	2705                	addiw	a4,a4,1
    80002fcc:	2485                	addiw	s1,s1,1
    80002fce:	fd471ae3          	bne	a4,s4,80002fa2 <balloc+0xb6>
    80002fd2:	b755                	j	80002f76 <balloc+0x8a>
    80002fd4:	7942                	ld	s2,48(sp)
    80002fd6:	79a2                	ld	s3,40(sp)
    80002fd8:	7a02                	ld	s4,32(sp)
    80002fda:	6ae2                	ld	s5,24(sp)
    80002fdc:	6b42                	ld	s6,16(sp)
    80002fde:	6ba2                	ld	s7,8(sp)
    80002fe0:	6c02                	ld	s8,0(sp)
  printk("balloc: out of blocks\n");
    80002fe2:	00004517          	auipc	a0,0x4
    80002fe6:	45e50513          	addi	a0,a0,1118 # 80007440 <etext+0x440>
    80002fea:	d10fd0ef          	jal	800004fa <printk>
  return 0;
    80002fee:	4481                	li	s1,0
    80002ff0:	bfad                	j	80002f6a <balloc+0x7e>

0000000080002ff2 <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    80002ff2:	7179                	addi	sp,sp,-48
    80002ff4:	f406                	sd	ra,40(sp)
    80002ff6:	f022                	sd	s0,32(sp)
    80002ff8:	ec26                	sd	s1,24(sp)
    80002ffa:	e84a                	sd	s2,16(sp)
    80002ffc:	e44e                	sd	s3,8(sp)
    80002ffe:	1800                	addi	s0,sp,48
    80003000:	892a                	mv	s2,a0
  uint addr, *a;
  struct buf *bp;

  if (bn < NDIRECT) {
    80003002:	47ad                	li	a5,11
    80003004:	02b7e363          	bltu	a5,a1,8000302a <bmap+0x38>
    if ((addr = ip->addrs[bn]) == 0) {
    80003008:	02059793          	slli	a5,a1,0x20
    8000300c:	01e7d593          	srli	a1,a5,0x1e
    80003010:	00b509b3          	add	s3,a0,a1
    80003014:	0509a483          	lw	s1,80(s3)
    80003018:	e0b5                	bnez	s1,8000307c <bmap+0x8a>
      addr = balloc(ip->dev);
    8000301a:	4108                	lw	a0,0(a0)
    8000301c:	ed1ff0ef          	jal	80002eec <balloc>
    80003020:	84aa                	mv	s1,a0
      if (addr == 0)
    80003022:	cd29                	beqz	a0,8000307c <bmap+0x8a>
        return 0;
      ip->addrs[bn] = addr;
    80003024:	04a9a823          	sw	a0,80(s3)
    80003028:	a891                	j	8000307c <bmap+0x8a>
    }
    return addr;
  }
  bn -= NDIRECT;
    8000302a:	ff45879b          	addiw	a5,a1,-12
    8000302e:	873e                	mv	a4,a5
    80003030:	89be                	mv	s3,a5

  if (bn < NINDIRECT) {
    80003032:	0ff00793          	li	a5,255
    80003036:	06e7e763          	bltu	a5,a4,800030a4 <bmap+0xb2>
    // Load indirect block, allocating if necessary.
    if ((addr = ip->addrs[NDIRECT]) == 0) {
    8000303a:	08052483          	lw	s1,128(a0)
    8000303e:	e891                	bnez	s1,80003052 <bmap+0x60>
      addr = balloc(ip->dev);
    80003040:	4108                	lw	a0,0(a0)
    80003042:	eabff0ef          	jal	80002eec <balloc>
    80003046:	84aa                	mv	s1,a0
      if (addr == 0)
    80003048:	c915                	beqz	a0,8000307c <bmap+0x8a>
    8000304a:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    8000304c:	08a92023          	sw	a0,128(s2)
    80003050:	a011                	j	80003054 <bmap+0x62>
    80003052:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    80003054:	85a6                	mv	a1,s1
    80003056:	00092503          	lw	a0,0(s2)
    8000305a:	c33ff0ef          	jal	80002c8c <bread>
    8000305e:	8a2a                	mv	s4,a0
    a = (uint *)bp->data;
    80003060:	05850793          	addi	a5,a0,88
    if ((addr = a[bn]) == 0) {
    80003064:	02099713          	slli	a4,s3,0x20
    80003068:	01e75593          	srli	a1,a4,0x1e
    8000306c:	97ae                	add	a5,a5,a1
    8000306e:	89be                	mv	s3,a5
    80003070:	4384                	lw	s1,0(a5)
    80003072:	cc89                	beqz	s1,8000308c <bmap+0x9a>
      if (addr) {
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    80003074:	8552                	mv	a0,s4
    80003076:	d1fff0ef          	jal	80002d94 <brelse>
    return addr;
    8000307a:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    8000307c:	8526                	mv	a0,s1
    8000307e:	70a2                	ld	ra,40(sp)
    80003080:	7402                	ld	s0,32(sp)
    80003082:	64e2                	ld	s1,24(sp)
    80003084:	6942                	ld	s2,16(sp)
    80003086:	69a2                	ld	s3,8(sp)
    80003088:	6145                	addi	sp,sp,48
    8000308a:	8082                	ret
      addr = balloc(ip->dev);
    8000308c:	00092503          	lw	a0,0(s2)
    80003090:	e5dff0ef          	jal	80002eec <balloc>
    80003094:	84aa                	mv	s1,a0
      if (addr) {
    80003096:	dd79                	beqz	a0,80003074 <bmap+0x82>
        a[bn] = addr;
    80003098:	00a9a023          	sw	a0,0(s3)
        log_write(bp);
    8000309c:	8552                	mv	a0,s4
    8000309e:	6c7000ef          	jal	80003f64 <log_write>
    800030a2:	bfc9                	j	80003074 <bmap+0x82>
    800030a4:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    800030a6:	00004517          	auipc	a0,0x4
    800030aa:	3b250513          	addi	a0,a0,946 # 80007458 <etext+0x458>
    800030ae:	f84fd0ef          	jal	80000832 <panic>

00000000800030b2 <iget>:
{
    800030b2:	7179                	addi	sp,sp,-48
    800030b4:	f406                	sd	ra,40(sp)
    800030b6:	f022                	sd	s0,32(sp)
    800030b8:	ec26                	sd	s1,24(sp)
    800030ba:	e84a                	sd	s2,16(sp)
    800030bc:	e44e                	sd	s3,8(sp)
    800030be:	e052                	sd	s4,0(sp)
    800030c0:	1800                	addi	s0,sp,48
    800030c2:	89aa                	mv	s3,a0
    800030c4:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    800030c6:	0001b517          	auipc	a0,0x1b
    800030ca:	03a50513          	addi	a0,a0,58 # 8001e100 <itable>
    800030ce:	b43fd0ef          	jal	80000c10 <acquire>
  empty = 0;
    800030d2:	4901                	li	s2,0
  for (ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++) {
    800030d4:	0001b497          	auipc	s1,0x1b
    800030d8:	04448493          	addi	s1,s1,68 # 8001e118 <itable+0x18>
    800030dc:	0001d697          	auipc	a3,0x1d
    800030e0:	acc68693          	addi	a3,a3,-1332 # 8001fba8 <log>
    800030e4:	a819                	j	800030fa <iget+0x48>
    if (empty == 0 && ip->ref == 0) // Remember empty slot.
    800030e6:	0017b793          	seqz	a5,a5
    800030ea:	00193713          	seqz	a4,s2
    800030ee:	8ff9                	and	a5,a5,a4
    800030f0:	eb85                	bnez	a5,80003120 <iget+0x6e>
  for (ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++) {
    800030f2:	08848493          	addi	s1,s1,136
    800030f6:	02d48763          	beq	s1,a3,80003124 <iget+0x72>
    if (ip->ref > 0 && ip->dev == dev && ip->inum == inum) {
    800030fa:	449c                	lw	a5,8(s1)
    800030fc:	fef055e3          	blez	a5,800030e6 <iget+0x34>
    80003100:	4098                	lw	a4,0(s1)
    80003102:	ff3718e3          	bne	a4,s3,800030f2 <iget+0x40>
    80003106:	40d8                	lw	a4,4(s1)
    80003108:	ff4715e3          	bne	a4,s4,800030f2 <iget+0x40>
      ip->ref++;
    8000310c:	2785                	addiw	a5,a5,1
    8000310e:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    80003110:	0001b517          	auipc	a0,0x1b
    80003114:	ff050513          	addi	a0,a0,-16 # 8001e100 <itable>
    80003118:	b8bfd0ef          	jal	80000ca2 <release>
      return ip;
    8000311c:	8926                	mv	s2,s1
    8000311e:	a025                	j	80003146 <iget+0x94>
      empty = ip;
    80003120:	8926                	mv	s2,s1
    80003122:	bfc1                	j	800030f2 <iget+0x40>
  if (empty == 0)
    80003124:	02090a63          	beqz	s2,80003158 <iget+0xa6>
  ip->dev = dev;
    80003128:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    8000312c:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    80003130:	4785                	li	a5,1
    80003132:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    80003136:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    8000313a:	0001b517          	auipc	a0,0x1b
    8000313e:	fc650513          	addi	a0,a0,-58 # 8001e100 <itable>
    80003142:	b61fd0ef          	jal	80000ca2 <release>
}
    80003146:	854a                	mv	a0,s2
    80003148:	70a2                	ld	ra,40(sp)
    8000314a:	7402                	ld	s0,32(sp)
    8000314c:	64e2                	ld	s1,24(sp)
    8000314e:	6942                	ld	s2,16(sp)
    80003150:	69a2                	ld	s3,8(sp)
    80003152:	6a02                	ld	s4,0(sp)
    80003154:	6145                	addi	sp,sp,48
    80003156:	8082                	ret
    panic("iget: no inodes");
    80003158:	00004517          	auipc	a0,0x4
    8000315c:	31850513          	addi	a0,a0,792 # 80007470 <etext+0x470>
    80003160:	ed2fd0ef          	jal	80000832 <panic>

0000000080003164 <iinit>:
{
    80003164:	7179                	addi	sp,sp,-48
    80003166:	f406                	sd	ra,40(sp)
    80003168:	f022                	sd	s0,32(sp)
    8000316a:	ec26                	sd	s1,24(sp)
    8000316c:	e84a                	sd	s2,16(sp)
    8000316e:	e44e                	sd	s3,8(sp)
    80003170:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    80003172:	00004597          	auipc	a1,0x4
    80003176:	30e58593          	addi	a1,a1,782 # 80007480 <etext+0x480>
    8000317a:	0001b517          	auipc	a0,0x1b
    8000317e:	f8650513          	addi	a0,a0,-122 # 8001e100 <itable>
    80003182:	a0ffd0ef          	jal	80000b90 <initlock>
  for (i = 0; i < NINODE; i++) {
    80003186:	0001b497          	auipc	s1,0x1b
    8000318a:	fa248493          	addi	s1,s1,-94 # 8001e128 <itable+0x28>
    8000318e:	0001d997          	auipc	s3,0x1d
    80003192:	a2a98993          	addi	s3,s3,-1494 # 8001fbb8 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    80003196:	00004917          	auipc	s2,0x4
    8000319a:	2f290913          	addi	s2,s2,754 # 80007488 <etext+0x488>
    8000319e:	85ca                	mv	a1,s2
    800031a0:	8526                	mv	a0,s1
    800031a2:	6fb000ef          	jal	8000409c <initsleeplock>
  for (i = 0; i < NINODE; i++) {
    800031a6:	08848493          	addi	s1,s1,136
    800031aa:	ff349ae3          	bne	s1,s3,8000319e <iinit+0x3a>
}
    800031ae:	70a2                	ld	ra,40(sp)
    800031b0:	7402                	ld	s0,32(sp)
    800031b2:	64e2                	ld	s1,24(sp)
    800031b4:	6942                	ld	s2,16(sp)
    800031b6:	69a2                	ld	s3,8(sp)
    800031b8:	6145                	addi	sp,sp,48
    800031ba:	8082                	ret

00000000800031bc <ialloc>:
{
    800031bc:	7139                	addi	sp,sp,-64
    800031be:	fc06                	sd	ra,56(sp)
    800031c0:	f822                	sd	s0,48(sp)
    800031c2:	0080                	addi	s0,sp,64
  for (inum = 1; inum < sb.ninodes; inum++) {
    800031c4:	0001b717          	auipc	a4,0x1b
    800031c8:	f2872703          	lw	a4,-216(a4) # 8001e0ec <sb+0xc>
    800031cc:	4785                	li	a5,1
    800031ce:	06e7f063          	bgeu	a5,a4,8000322e <ialloc+0x72>
    800031d2:	f426                	sd	s1,40(sp)
    800031d4:	f04a                	sd	s2,32(sp)
    800031d6:	ec4e                	sd	s3,24(sp)
    800031d8:	e852                	sd	s4,16(sp)
    800031da:	e456                	sd	s5,8(sp)
    800031dc:	e05a                	sd	s6,0(sp)
    800031de:	8aaa                	mv	s5,a0
    800031e0:	8b2e                	mv	s6,a1
    800031e2:	893e                	mv	s2,a5
    bp = bread(dev, IBLOCK(inum, sb));
    800031e4:	0001ba17          	auipc	s4,0x1b
    800031e8:	efca0a13          	addi	s4,s4,-260 # 8001e0e0 <sb>
    800031ec:	00495593          	srli	a1,s2,0x4
    800031f0:	018a2783          	lw	a5,24(s4)
    800031f4:	9dbd                	addw	a1,a1,a5
    800031f6:	8556                	mv	a0,s5
    800031f8:	a95ff0ef          	jal	80002c8c <bread>
    800031fc:	84aa                	mv	s1,a0
    dip = (struct dinode *)bp->data + inum % IPB;
    800031fe:	05850993          	addi	s3,a0,88
    80003202:	00f97793          	andi	a5,s2,15
    80003206:	079a                	slli	a5,a5,0x6
    80003208:	99be                	add	s3,s3,a5
    if (dip->type == 0) { // a free inode
    8000320a:	00099783          	lh	a5,0(s3)
    8000320e:	cb9d                	beqz	a5,80003244 <ialloc+0x88>
    brelse(bp);
    80003210:	b85ff0ef          	jal	80002d94 <brelse>
  for (inum = 1; inum < sb.ninodes; inum++) {
    80003214:	0905                	addi	s2,s2,1
    80003216:	00ca2703          	lw	a4,12(s4)
    8000321a:	0009079b          	sext.w	a5,s2
    8000321e:	fce7e7e3          	bltu	a5,a4,800031ec <ialloc+0x30>
    80003222:	74a2                	ld	s1,40(sp)
    80003224:	7902                	ld	s2,32(sp)
    80003226:	69e2                	ld	s3,24(sp)
    80003228:	6a42                	ld	s4,16(sp)
    8000322a:	6aa2                	ld	s5,8(sp)
    8000322c:	6b02                	ld	s6,0(sp)
  printk("ialloc: no inodes\n");
    8000322e:	00004517          	auipc	a0,0x4
    80003232:	26250513          	addi	a0,a0,610 # 80007490 <etext+0x490>
    80003236:	ac4fd0ef          	jal	800004fa <printk>
  return 0;
    8000323a:	4501                	li	a0,0
}
    8000323c:	70e2                	ld	ra,56(sp)
    8000323e:	7442                	ld	s0,48(sp)
    80003240:	6121                	addi	sp,sp,64
    80003242:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    80003244:	04000613          	li	a2,64
    80003248:	4581                	li	a1,0
    8000324a:	854e                	mv	a0,s3
    8000324c:	a9dfd0ef          	jal	80000ce8 <memset>
      dip->type = type;
    80003250:	01699023          	sh	s6,0(s3)
      log_write(bp); // mark it allocated on the disk
    80003254:	8526                	mv	a0,s1
    80003256:	50f000ef          	jal	80003f64 <log_write>
      brelse(bp);
    8000325a:	8526                	mv	a0,s1
    8000325c:	b39ff0ef          	jal	80002d94 <brelse>
      return iget(dev, inum);
    80003260:	0009059b          	sext.w	a1,s2
    80003264:	8556                	mv	a0,s5
    80003266:	e4dff0ef          	jal	800030b2 <iget>
    8000326a:	74a2                	ld	s1,40(sp)
    8000326c:	7902                	ld	s2,32(sp)
    8000326e:	69e2                	ld	s3,24(sp)
    80003270:	6a42                	ld	s4,16(sp)
    80003272:	6aa2                	ld	s5,8(sp)
    80003274:	6b02                	ld	s6,0(sp)
    80003276:	b7d9                	j	8000323c <ialloc+0x80>

0000000080003278 <iupdate>:
{
    80003278:	1101                	addi	sp,sp,-32
    8000327a:	ec06                	sd	ra,24(sp)
    8000327c:	e822                	sd	s0,16(sp)
    8000327e:	e426                	sd	s1,8(sp)
    80003280:	e04a                	sd	s2,0(sp)
    80003282:	1000                	addi	s0,sp,32
    80003284:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003286:	415c                	lw	a5,4(a0)
    80003288:	0047d79b          	srliw	a5,a5,0x4
    8000328c:	0001b597          	auipc	a1,0x1b
    80003290:	e6c5a583          	lw	a1,-404(a1) # 8001e0f8 <sb+0x18>
    80003294:	9dbd                	addw	a1,a1,a5
    80003296:	4108                	lw	a0,0(a0)
    80003298:	9f5ff0ef          	jal	80002c8c <bread>
    8000329c:	892a                	mv	s2,a0
  dip = (struct dinode *)bp->data + ip->inum % IPB;
    8000329e:	05850793          	addi	a5,a0,88
    800032a2:	40d8                	lw	a4,4(s1)
    800032a4:	8b3d                	andi	a4,a4,15
    800032a6:	071a                	slli	a4,a4,0x6
    800032a8:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    800032aa:	04449703          	lh	a4,68(s1)
    800032ae:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    800032b2:	04649703          	lh	a4,70(s1)
    800032b6:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    800032ba:	04849703          	lh	a4,72(s1)
    800032be:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    800032c2:	04a49703          	lh	a4,74(s1)
    800032c6:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    800032ca:	44f8                	lw	a4,76(s1)
    800032cc:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    800032ce:	03400613          	li	a2,52
    800032d2:	05048593          	addi	a1,s1,80
    800032d6:	00c78513          	addi	a0,a5,12
    800032da:	a6bfd0ef          	jal	80000d44 <memmove>
  log_write(bp);
    800032de:	854a                	mv	a0,s2
    800032e0:	485000ef          	jal	80003f64 <log_write>
  brelse(bp);
    800032e4:	854a                	mv	a0,s2
    800032e6:	aafff0ef          	jal	80002d94 <brelse>
}
    800032ea:	60e2                	ld	ra,24(sp)
    800032ec:	6442                	ld	s0,16(sp)
    800032ee:	64a2                	ld	s1,8(sp)
    800032f0:	6902                	ld	s2,0(sp)
    800032f2:	6105                	addi	sp,sp,32
    800032f4:	8082                	ret

00000000800032f6 <idup>:
{
    800032f6:	1101                	addi	sp,sp,-32
    800032f8:	ec06                	sd	ra,24(sp)
    800032fa:	e822                	sd	s0,16(sp)
    800032fc:	e426                	sd	s1,8(sp)
    800032fe:	1000                	addi	s0,sp,32
    80003300:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003302:	0001b517          	auipc	a0,0x1b
    80003306:	dfe50513          	addi	a0,a0,-514 # 8001e100 <itable>
    8000330a:	907fd0ef          	jal	80000c10 <acquire>
  ip->ref++;
    8000330e:	449c                	lw	a5,8(s1)
    80003310:	2785                	addiw	a5,a5,1
    80003312:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003314:	0001b517          	auipc	a0,0x1b
    80003318:	dec50513          	addi	a0,a0,-532 # 8001e100 <itable>
    8000331c:	987fd0ef          	jal	80000ca2 <release>
}
    80003320:	8526                	mv	a0,s1
    80003322:	60e2                	ld	ra,24(sp)
    80003324:	6442                	ld	s0,16(sp)
    80003326:	64a2                	ld	s1,8(sp)
    80003328:	6105                	addi	sp,sp,32
    8000332a:	8082                	ret

000000008000332c <ilock>:
{
    8000332c:	1101                	addi	sp,sp,-32
    8000332e:	ec06                	sd	ra,24(sp)
    80003330:	e822                	sd	s0,16(sp)
    80003332:	e426                	sd	s1,8(sp)
    80003334:	1000                	addi	s0,sp,32
  if (ip == 0 || ip->ref < 1)
    80003336:	cd19                	beqz	a0,80003354 <ilock+0x28>
    80003338:	84aa                	mv	s1,a0
    8000333a:	451c                	lw	a5,8(a0)
    8000333c:	00f05c63          	blez	a5,80003354 <ilock+0x28>
  acquiresleep(&ip->lock);
    80003340:	0541                	addi	a0,a0,16
    80003342:	591000ef          	jal	800040d2 <acquiresleep>
  if (ip->valid == 0) {
    80003346:	40bc                	lw	a5,64(s1)
    80003348:	cf89                	beqz	a5,80003362 <ilock+0x36>
}
    8000334a:	60e2                	ld	ra,24(sp)
    8000334c:	6442                	ld	s0,16(sp)
    8000334e:	64a2                	ld	s1,8(sp)
    80003350:	6105                	addi	sp,sp,32
    80003352:	8082                	ret
    80003354:	e04a                	sd	s2,0(sp)
    panic("ilock");
    80003356:	00004517          	auipc	a0,0x4
    8000335a:	15250513          	addi	a0,a0,338 # 800074a8 <etext+0x4a8>
    8000335e:	cd4fd0ef          	jal	80000832 <panic>
    80003362:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003364:	40dc                	lw	a5,4(s1)
    80003366:	0047d79b          	srliw	a5,a5,0x4
    8000336a:	0001b597          	auipc	a1,0x1b
    8000336e:	d8e5a583          	lw	a1,-626(a1) # 8001e0f8 <sb+0x18>
    80003372:	9dbd                	addw	a1,a1,a5
    80003374:	4088                	lw	a0,0(s1)
    80003376:	917ff0ef          	jal	80002c8c <bread>
    8000337a:	892a                	mv	s2,a0
    dip = (struct dinode *)bp->data + ip->inum % IPB;
    8000337c:	05850593          	addi	a1,a0,88
    80003380:	40dc                	lw	a5,4(s1)
    80003382:	8bbd                	andi	a5,a5,15
    80003384:	079a                	slli	a5,a5,0x6
    80003386:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    80003388:	00059783          	lh	a5,0(a1)
    8000338c:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    80003390:	00259783          	lh	a5,2(a1)
    80003394:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    80003398:	00459783          	lh	a5,4(a1)
    8000339c:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    800033a0:	00659783          	lh	a5,6(a1)
    800033a4:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    800033a8:	459c                	lw	a5,8(a1)
    800033aa:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    800033ac:	03400613          	li	a2,52
    800033b0:	05b1                	addi	a1,a1,12
    800033b2:	05048513          	addi	a0,s1,80
    800033b6:	98ffd0ef          	jal	80000d44 <memmove>
    brelse(bp);
    800033ba:	854a                	mv	a0,s2
    800033bc:	9d9ff0ef          	jal	80002d94 <brelse>
    ip->valid = 1;
    800033c0:	4785                	li	a5,1
    800033c2:	c0bc                	sw	a5,64(s1)
    if (ip->type == 0)
    800033c4:	04449783          	lh	a5,68(s1)
    800033c8:	c399                	beqz	a5,800033ce <ilock+0xa2>
    800033ca:	6902                	ld	s2,0(sp)
    800033cc:	bfbd                	j	8000334a <ilock+0x1e>
      panic("ilock: no type");
    800033ce:	00004517          	auipc	a0,0x4
    800033d2:	0e250513          	addi	a0,a0,226 # 800074b0 <etext+0x4b0>
    800033d6:	c5cfd0ef          	jal	80000832 <panic>

00000000800033da <iunlock>:
{
    800033da:	1101                	addi	sp,sp,-32
    800033dc:	ec06                	sd	ra,24(sp)
    800033de:	e822                	sd	s0,16(sp)
    800033e0:	e426                	sd	s1,8(sp)
    800033e2:	e04a                	sd	s2,0(sp)
    800033e4:	1000                	addi	s0,sp,32
  if (ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    800033e6:	c505                	beqz	a0,8000340e <iunlock+0x34>
    800033e8:	84aa                	mv	s1,a0
    800033ea:	01050913          	addi	s2,a0,16
    800033ee:	854a                	mv	a0,s2
    800033f0:	573000ef          	jal	80004162 <holdingsleep>
    800033f4:	cd09                	beqz	a0,8000340e <iunlock+0x34>
    800033f6:	449c                	lw	a5,8(s1)
    800033f8:	00f05b63          	blez	a5,8000340e <iunlock+0x34>
  releasesleep(&ip->lock);
    800033fc:	854a                	mv	a0,s2
    800033fe:	52d000ef          	jal	8000412a <releasesleep>
}
    80003402:	60e2                	ld	ra,24(sp)
    80003404:	6442                	ld	s0,16(sp)
    80003406:	64a2                	ld	s1,8(sp)
    80003408:	6902                	ld	s2,0(sp)
    8000340a:	6105                	addi	sp,sp,32
    8000340c:	8082                	ret
    panic("iunlock");
    8000340e:	00004517          	auipc	a0,0x4
    80003412:	0b250513          	addi	a0,a0,178 # 800074c0 <etext+0x4c0>
    80003416:	c1cfd0ef          	jal	80000832 <panic>

000000008000341a <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    8000341a:	7179                	addi	sp,sp,-48
    8000341c:	f406                	sd	ra,40(sp)
    8000341e:	f022                	sd	s0,32(sp)
    80003420:	ec26                	sd	s1,24(sp)
    80003422:	e84a                	sd	s2,16(sp)
    80003424:	e44e                	sd	s3,8(sp)
    80003426:	1800                	addi	s0,sp,48
    80003428:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for (i = 0; i < NDIRECT; i++) {
    8000342a:	05050493          	addi	s1,a0,80
    8000342e:	08050913          	addi	s2,a0,128
    80003432:	a021                	j	8000343a <itrunc+0x20>
    80003434:	0491                	addi	s1,s1,4
    80003436:	01248b63          	beq	s1,s2,8000344c <itrunc+0x32>
    if (ip->addrs[i]) {
    8000343a:	408c                	lw	a1,0(s1)
    8000343c:	dde5                	beqz	a1,80003434 <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    8000343e:	0009a503          	lw	a0,0(s3)
    80003442:	a3fff0ef          	jal	80002e80 <bfree>
      ip->addrs[i] = 0;
    80003446:	0004a023          	sw	zero,0(s1)
    8000344a:	b7ed                	j	80003434 <itrunc+0x1a>
    }
  }

  if (ip->addrs[NDIRECT]) {
    8000344c:	0809a583          	lw	a1,128(s3)
    80003450:	ed89                	bnez	a1,8000346a <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    80003452:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    80003456:	854e                	mv	a0,s3
    80003458:	e21ff0ef          	jal	80003278 <iupdate>
}
    8000345c:	70a2                	ld	ra,40(sp)
    8000345e:	7402                	ld	s0,32(sp)
    80003460:	64e2                	ld	s1,24(sp)
    80003462:	6942                	ld	s2,16(sp)
    80003464:	69a2                	ld	s3,8(sp)
    80003466:	6145                	addi	sp,sp,48
    80003468:	8082                	ret
    8000346a:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    8000346c:	0009a503          	lw	a0,0(s3)
    80003470:	81dff0ef          	jal	80002c8c <bread>
    80003474:	8a2a                	mv	s4,a0
    for (j = 0; j < NINDIRECT; j++) {
    80003476:	05850493          	addi	s1,a0,88
    8000347a:	45850913          	addi	s2,a0,1112
    8000347e:	a021                	j	80003486 <itrunc+0x6c>
    80003480:	0491                	addi	s1,s1,4
    80003482:	01248963          	beq	s1,s2,80003494 <itrunc+0x7a>
      if (a[j])
    80003486:	408c                	lw	a1,0(s1)
    80003488:	dde5                	beqz	a1,80003480 <itrunc+0x66>
        bfree(ip->dev, a[j]);
    8000348a:	0009a503          	lw	a0,0(s3)
    8000348e:	9f3ff0ef          	jal	80002e80 <bfree>
    80003492:	b7fd                	j	80003480 <itrunc+0x66>
    brelse(bp);
    80003494:	8552                	mv	a0,s4
    80003496:	8ffff0ef          	jal	80002d94 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    8000349a:	0809a583          	lw	a1,128(s3)
    8000349e:	0009a503          	lw	a0,0(s3)
    800034a2:	9dfff0ef          	jal	80002e80 <bfree>
    ip->addrs[NDIRECT] = 0;
    800034a6:	0809a023          	sw	zero,128(s3)
    800034aa:	6a02                	ld	s4,0(sp)
    800034ac:	b75d                	j	80003452 <itrunc+0x38>

00000000800034ae <iput>:
{
    800034ae:	7179                	addi	sp,sp,-48
    800034b0:	f406                	sd	ra,40(sp)
    800034b2:	f022                	sd	s0,32(sp)
    800034b4:	ec26                	sd	s1,24(sp)
    800034b6:	1800                	addi	s0,sp,48
    800034b8:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800034ba:	0001b517          	auipc	a0,0x1b
    800034be:	c4650513          	addi	a0,a0,-954 # 8001e100 <itable>
    800034c2:	f4efd0ef          	jal	80000c10 <acquire>
  int last = (ip->ref == 1 && ip->valid && ip->nlink == 0);
    800034c6:	449c                	lw	a5,8(s1)
    800034c8:	4705                	li	a4,1
    800034ca:	00e78f63          	beq	a5,a4,800034e8 <iput+0x3a>
  ip->ref--;
    800034ce:	37fd                	addiw	a5,a5,-1
    800034d0:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800034d2:	0001b517          	auipc	a0,0x1b
    800034d6:	c2e50513          	addi	a0,a0,-978 # 8001e100 <itable>
    800034da:	fc8fd0ef          	jal	80000ca2 <release>
}
    800034de:	70a2                	ld	ra,40(sp)
    800034e0:	7402                	ld	s0,32(sp)
    800034e2:	64e2                	ld	s1,24(sp)
    800034e4:	6145                	addi	sp,sp,48
    800034e6:	8082                	ret
  int last = (ip->ref == 1 && ip->valid && ip->nlink == 0);
    800034e8:	40b8                	lw	a4,64(s1)
    800034ea:	d375                	beqz	a4,800034ce <iput+0x20>
    800034ec:	e84a                	sd	s2,16(sp)
    800034ee:	e052                	sd	s4,0(sp)
  uint dev = ip->dev, inum = ip->inum;
    800034f0:	0004aa03          	lw	s4,0(s1)
    800034f4:	0044a903          	lw	s2,4(s1)
  if (last) {
    800034f8:	04a49703          	lh	a4,74(s1)
    800034fc:	ef3d                	bnez	a4,8000357a <iput+0xcc>
    800034fe:	e44e                	sd	s3,8(sp)
    acquiresleep(&ip->lock);
    80003500:	01048793          	addi	a5,s1,16
    80003504:	89be                	mv	s3,a5
    80003506:	853e                	mv	a0,a5
    80003508:	3cb000ef          	jal	800040d2 <acquiresleep>
    release(&itable.lock);
    8000350c:	0001b517          	auipc	a0,0x1b
    80003510:	bf450513          	addi	a0,a0,-1036 # 8001e100 <itable>
    80003514:	f8efd0ef          	jal	80000ca2 <release>
    itrunc(ip); // free the data blocks (type stays nonzero on disk)
    80003518:	8526                	mv	a0,s1
    8000351a:	f01ff0ef          	jal	8000341a <itrunc>
    ip->valid = 0;
    8000351e:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    80003522:	854e                	mv	a0,s3
    80003524:	407000ef          	jal	8000412a <releasesleep>
    acquire(&itable.lock);
    80003528:	0001b517          	auipc	a0,0x1b
    8000352c:	bd850513          	addi	a0,a0,-1064 # 8001e100 <itable>
    80003530:	ee0fd0ef          	jal	80000c10 <acquire>
  ip->ref--;
    80003534:	449c                	lw	a5,8(s1)
    80003536:	37fd                	addiw	a5,a5,-1
    80003538:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    8000353a:	0001b517          	auipc	a0,0x1b
    8000353e:	bc650513          	addi	a0,a0,-1082 # 8001e100 <itable>
    80003542:	f60fd0ef          	jal	80000ca2 <release>
  struct buf *bp = bread(dev, IBLOCK(inum, sb));
    80003546:	0049579b          	srliw	a5,s2,0x4
    8000354a:	0001b597          	auipc	a1,0x1b
    8000354e:	bae5a583          	lw	a1,-1106(a1) # 8001e0f8 <sb+0x18>
    80003552:	9dbd                	addw	a1,a1,a5
    80003554:	8552                	mv	a0,s4
    80003556:	f36ff0ef          	jal	80002c8c <bread>
    8000355a:	84aa                	mv	s1,a0
  struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    8000355c:	00f97793          	andi	a5,s2,15
  dip->type = 0;
    80003560:	079a                	slli	a5,a5,0x6
    80003562:	97aa                	add	a5,a5,a0
    80003564:	04079c23          	sh	zero,88(a5)
  log_write(bp);
    80003568:	1fd000ef          	jal	80003f64 <log_write>
  brelse(bp);
    8000356c:	8526                	mv	a0,s1
    8000356e:	827ff0ef          	jal	80002d94 <brelse>
}
    80003572:	6942                	ld	s2,16(sp)
    80003574:	69a2                	ld	s3,8(sp)
    80003576:	6a02                	ld	s4,0(sp)
    80003578:	b79d                	j	800034de <iput+0x30>
    8000357a:	6942                	ld	s2,16(sp)
    8000357c:	6a02                	ld	s4,0(sp)
    8000357e:	bf81                	j	800034ce <iput+0x20>

0000000080003580 <iunlockput>:
{
    80003580:	1101                	addi	sp,sp,-32
    80003582:	ec06                	sd	ra,24(sp)
    80003584:	e822                	sd	s0,16(sp)
    80003586:	e426                	sd	s1,8(sp)
    80003588:	1000                	addi	s0,sp,32
    8000358a:	84aa                	mv	s1,a0
  iunlock(ip);
    8000358c:	e4fff0ef          	jal	800033da <iunlock>
  iput(ip);
    80003590:	8526                	mv	a0,s1
    80003592:	f1dff0ef          	jal	800034ae <iput>
}
    80003596:	60e2                	ld	ra,24(sp)
    80003598:	6442                	ld	s0,16(sp)
    8000359a:	64a2                	ld	s1,8(sp)
    8000359c:	6105                	addi	sp,sp,32
    8000359e:	8082                	ret

00000000800035a0 <ireclaim>:
  for (int inum = 1; inum < sb.ninodes; inum++) {
    800035a0:	0001b717          	auipc	a4,0x1b
    800035a4:	b4c72703          	lw	a4,-1204(a4) # 8001e0ec <sb+0xc>
    800035a8:	4785                	li	a5,1
    800035aa:	0ae7fe63          	bgeu	a5,a4,80003666 <ireclaim+0xc6>
{
    800035ae:	7139                	addi	sp,sp,-64
    800035b0:	fc06                	sd	ra,56(sp)
    800035b2:	f822                	sd	s0,48(sp)
    800035b4:	f426                	sd	s1,40(sp)
    800035b6:	f04a                	sd	s2,32(sp)
    800035b8:	ec4e                	sd	s3,24(sp)
    800035ba:	e852                	sd	s4,16(sp)
    800035bc:	e456                	sd	s5,8(sp)
    800035be:	e05a                	sd	s6,0(sp)
    800035c0:	0080                	addi	s0,sp,64
    800035c2:	8aaa                	mv	s5,a0
  for (int inum = 1; inum < sb.ninodes; inum++) {
    800035c4:	84be                	mv	s1,a5
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    800035c6:	0001ba17          	auipc	s4,0x1b
    800035ca:	b1aa0a13          	addi	s4,s4,-1254 # 8001e0e0 <sb>
      printk("ireclaim: orphaned inode %d\n", inum);
    800035ce:	00004b17          	auipc	s6,0x4
    800035d2:	efab0b13          	addi	s6,s6,-262 # 800074c8 <etext+0x4c8>
    800035d6:	a099                	j	8000361c <ireclaim+0x7c>
    800035d8:	85ce                	mv	a1,s3
    800035da:	855a                	mv	a0,s6
    800035dc:	f1ffc0ef          	jal	800004fa <printk>
      ip = iget(dev, inum);
    800035e0:	85ce                	mv	a1,s3
    800035e2:	8556                	mv	a0,s5
    800035e4:	acfff0ef          	jal	800030b2 <iget>
    800035e8:	89aa                	mv	s3,a0
    brelse(bp);
    800035ea:	854a                	mv	a0,s2
    800035ec:	fa8ff0ef          	jal	80002d94 <brelse>
    if (ip) {
    800035f0:	00098f63          	beqz	s3,8000360e <ireclaim+0x6e>
      begin_op();
    800035f4:	7ba000ef          	jal	80003dae <begin_op>
      ilock(ip);
    800035f8:	854e                	mv	a0,s3
    800035fa:	d33ff0ef          	jal	8000332c <ilock>
      iunlock(ip);
    800035fe:	854e                	mv	a0,s3
    80003600:	ddbff0ef          	jal	800033da <iunlock>
      iput(ip);
    80003604:	854e                	mv	a0,s3
    80003606:	ea9ff0ef          	jal	800034ae <iput>
      end_op();
    8000360a:	039000ef          	jal	80003e42 <end_op>
  for (int inum = 1; inum < sb.ninodes; inum++) {
    8000360e:	0485                	addi	s1,s1,1
    80003610:	00ca2703          	lw	a4,12(s4)
    80003614:	0004879b          	sext.w	a5,s1
    80003618:	02e7fd63          	bgeu	a5,a4,80003652 <ireclaim+0xb2>
    8000361c:	0004899b          	sext.w	s3,s1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    80003620:	0044d593          	srli	a1,s1,0x4
    80003624:	018a2783          	lw	a5,24(s4)
    80003628:	9dbd                	addw	a1,a1,a5
    8000362a:	8556                	mv	a0,s5
    8000362c:	e60ff0ef          	jal	80002c8c <bread>
    80003630:	892a                	mv	s2,a0
    struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    80003632:	05850793          	addi	a5,a0,88
    80003636:	00f9f713          	andi	a4,s3,15
    8000363a:	071a                	slli	a4,a4,0x6
    8000363c:	97ba                	add	a5,a5,a4
    if (dip->type != 0 && dip->nlink == 0) { // is an orphaned inode
    8000363e:	00079703          	lh	a4,0(a5)
    80003642:	c701                	beqz	a4,8000364a <ireclaim+0xaa>
    80003644:	00679783          	lh	a5,6(a5)
    80003648:	dbc1                	beqz	a5,800035d8 <ireclaim+0x38>
    brelse(bp);
    8000364a:	854a                	mv	a0,s2
    8000364c:	f48ff0ef          	jal	80002d94 <brelse>
    if (ip) {
    80003650:	bf7d                	j	8000360e <ireclaim+0x6e>
}
    80003652:	70e2                	ld	ra,56(sp)
    80003654:	7442                	ld	s0,48(sp)
    80003656:	74a2                	ld	s1,40(sp)
    80003658:	7902                	ld	s2,32(sp)
    8000365a:	69e2                	ld	s3,24(sp)
    8000365c:	6a42                	ld	s4,16(sp)
    8000365e:	6aa2                	ld	s5,8(sp)
    80003660:	6b02                	ld	s6,0(sp)
    80003662:	6121                	addi	sp,sp,64
    80003664:	8082                	ret
    80003666:	8082                	ret

0000000080003668 <fsinit>:
{
    80003668:	1101                	addi	sp,sp,-32
    8000366a:	ec06                	sd	ra,24(sp)
    8000366c:	e822                	sd	s0,16(sp)
    8000366e:	e426                	sd	s1,8(sp)
    80003670:	e04a                	sd	s2,0(sp)
    80003672:	1000                	addi	s0,sp,32
    80003674:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    80003676:	4585                	li	a1,1
    80003678:	e14ff0ef          	jal	80002c8c <bread>
    8000367c:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    8000367e:	02000613          	li	a2,32
    80003682:	05850593          	addi	a1,a0,88
    80003686:	0001b517          	auipc	a0,0x1b
    8000368a:	a5a50513          	addi	a0,a0,-1446 # 8001e0e0 <sb>
    8000368e:	eb6fd0ef          	jal	80000d44 <memmove>
  brelse(bp);
    80003692:	8526                	mv	a0,s1
    80003694:	f00ff0ef          	jal	80002d94 <brelse>
  if (sb.magic != FSMAGIC)
    80003698:	0001b717          	auipc	a4,0x1b
    8000369c:	a4872703          	lw	a4,-1464(a4) # 8001e0e0 <sb>
    800036a0:	102037b7          	lui	a5,0x10203
    800036a4:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    800036a8:	02f71263          	bne	a4,a5,800036cc <fsinit+0x64>
  initlog(dev, &sb);
    800036ac:	0001b597          	auipc	a1,0x1b
    800036b0:	a3458593          	addi	a1,a1,-1484 # 8001e0e0 <sb>
    800036b4:	854a                	mv	a0,s2
    800036b6:	676000ef          	jal	80003d2c <initlog>
  ireclaim(dev);
    800036ba:	854a                	mv	a0,s2
    800036bc:	ee5ff0ef          	jal	800035a0 <ireclaim>
}
    800036c0:	60e2                	ld	ra,24(sp)
    800036c2:	6442                	ld	s0,16(sp)
    800036c4:	64a2                	ld	s1,8(sp)
    800036c6:	6902                	ld	s2,0(sp)
    800036c8:	6105                	addi	sp,sp,32
    800036ca:	8082                	ret
    panic("invalid file system");
    800036cc:	00004517          	auipc	a0,0x4
    800036d0:	e1c50513          	addi	a0,a0,-484 # 800074e8 <etext+0x4e8>
    800036d4:	95efd0ef          	jal	80000832 <panic>

00000000800036d8 <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    800036d8:	1141                	addi	sp,sp,-16
    800036da:	e406                	sd	ra,8(sp)
    800036dc:	e022                	sd	s0,0(sp)
    800036de:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    800036e0:	411c                	lw	a5,0(a0)
    800036e2:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    800036e4:	415c                	lw	a5,4(a0)
    800036e6:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    800036e8:	04451783          	lh	a5,68(a0)
    800036ec:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    800036f0:	04a51783          	lh	a5,74(a0)
    800036f4:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    800036f8:	04c56783          	lwu	a5,76(a0)
    800036fc:	e99c                	sd	a5,16(a1)
}
    800036fe:	60a2                	ld	ra,8(sp)
    80003700:	6402                	ld	s0,0(sp)
    80003702:	0141                	addi	sp,sp,16
    80003704:	8082                	ret

0000000080003706 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if (off > ip->size || off + n < off)
    80003706:	457c                	lw	a5,76(a0)
    80003708:	0ed7e663          	bltu	a5,a3,800037f4 <readi+0xee>
{
    8000370c:	7159                	addi	sp,sp,-112
    8000370e:	f486                	sd	ra,104(sp)
    80003710:	f0a2                	sd	s0,96(sp)
    80003712:	eca6                	sd	s1,88(sp)
    80003714:	e0d2                	sd	s4,64(sp)
    80003716:	fc56                	sd	s5,56(sp)
    80003718:	f85a                	sd	s6,48(sp)
    8000371a:	f45e                	sd	s7,40(sp)
    8000371c:	1880                	addi	s0,sp,112
    8000371e:	8b2a                	mv	s6,a0
    80003720:	8bae                	mv	s7,a1
    80003722:	8a32                	mv	s4,a2
    80003724:	84b6                	mv	s1,a3
    80003726:	8aba                	mv	s5,a4
  if (off > ip->size || off + n < off)
    80003728:	9f35                	addw	a4,a4,a3
    return 0;
    8000372a:	4501                	li	a0,0
  if (off > ip->size || off + n < off)
    8000372c:	0ad76b63          	bltu	a4,a3,800037e2 <readi+0xdc>
    80003730:	e4ce                	sd	s3,72(sp)
  if (off + n > ip->size)
    80003732:	00e7f463          	bgeu	a5,a4,8000373a <readi+0x34>
    n = ip->size - off;
    80003736:	40d78abb          	subw	s5,a5,a3

  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    8000373a:	080a8b63          	beqz	s5,800037d0 <readi+0xca>
    8000373e:	e8ca                	sd	s2,80(sp)
    80003740:	f062                	sd	s8,32(sp)
    80003742:	ec66                	sd	s9,24(sp)
    80003744:	e86a                	sd	s10,16(sp)
    80003746:	e46e                	sd	s11,8(sp)
    80003748:	4981                	li	s3,0
    uint addr = bmap(ip, off / BSIZE);
    if (addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off % BSIZE);
    8000374a:	40000c93          	li	s9,1024
    if (either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    8000374e:	5c7d                	li	s8,-1
    80003750:	a80d                	j	80003782 <readi+0x7c>
    80003752:	020d1d93          	slli	s11,s10,0x20
    80003756:	020ddd93          	srli	s11,s11,0x20
    8000375a:	05890613          	addi	a2,s2,88
    8000375e:	86ee                	mv	a3,s11
    80003760:	963e                	add	a2,a2,a5
    80003762:	85d2                	mv	a1,s4
    80003764:	855e                	mv	a0,s7
    80003766:	c03fe0ef          	jal	80002368 <either_copyout>
    8000376a:	05850363          	beq	a0,s8,800037b0 <readi+0xaa>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    8000376e:	854a                	mv	a0,s2
    80003770:	e24ff0ef          	jal	80002d94 <brelse>
  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    80003774:	013d09bb          	addw	s3,s10,s3
    80003778:	009d04bb          	addw	s1,s10,s1
    8000377c:	9a6e                	add	s4,s4,s11
    8000377e:	0559f363          	bgeu	s3,s5,800037c4 <readi+0xbe>
    uint addr = bmap(ip, off / BSIZE);
    80003782:	00a4d59b          	srliw	a1,s1,0xa
    80003786:	855a                	mv	a0,s6
    80003788:	86bff0ef          	jal	80002ff2 <bmap>
    8000378c:	85aa                	mv	a1,a0
    if (addr == 0)
    8000378e:	c139                	beqz	a0,800037d4 <readi+0xce>
    bp = bread(ip->dev, addr);
    80003790:	000b2503          	lw	a0,0(s6)
    80003794:	cf8ff0ef          	jal	80002c8c <bread>
    80003798:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off % BSIZE);
    8000379a:	3ff4f793          	andi	a5,s1,1023
    8000379e:	40fc873b          	subw	a4,s9,a5
    800037a2:	413a86bb          	subw	a3,s5,s3
    800037a6:	8d3a                	mv	s10,a4
    800037a8:	fae6f5e3          	bgeu	a3,a4,80003752 <readi+0x4c>
    800037ac:	8d36                	mv	s10,a3
    800037ae:	b755                	j	80003752 <readi+0x4c>
      brelse(bp);
    800037b0:	854a                	mv	a0,s2
    800037b2:	de2ff0ef          	jal	80002d94 <brelse>
      tot = -1;
    800037b6:	59fd                	li	s3,-1
      break;
    800037b8:	6946                	ld	s2,80(sp)
    800037ba:	7c02                	ld	s8,32(sp)
    800037bc:	6ce2                	ld	s9,24(sp)
    800037be:	6d42                	ld	s10,16(sp)
    800037c0:	6da2                	ld	s11,8(sp)
    800037c2:	a831                	j	800037de <readi+0xd8>
    800037c4:	6946                	ld	s2,80(sp)
    800037c6:	7c02                	ld	s8,32(sp)
    800037c8:	6ce2                	ld	s9,24(sp)
    800037ca:	6d42                	ld	s10,16(sp)
    800037cc:	6da2                	ld	s11,8(sp)
    800037ce:	a801                	j	800037de <readi+0xd8>
  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    800037d0:	89d6                	mv	s3,s5
    800037d2:	a031                	j	800037de <readi+0xd8>
    800037d4:	6946                	ld	s2,80(sp)
    800037d6:	7c02                	ld	s8,32(sp)
    800037d8:	6ce2                	ld	s9,24(sp)
    800037da:	6d42                	ld	s10,16(sp)
    800037dc:	6da2                	ld	s11,8(sp)
  }
  return tot;
    800037de:	854e                	mv	a0,s3
    800037e0:	69a6                	ld	s3,72(sp)
}
    800037e2:	70a6                	ld	ra,104(sp)
    800037e4:	7406                	ld	s0,96(sp)
    800037e6:	64e6                	ld	s1,88(sp)
    800037e8:	6a06                	ld	s4,64(sp)
    800037ea:	7ae2                	ld	s5,56(sp)
    800037ec:	7b42                	ld	s6,48(sp)
    800037ee:	7ba2                	ld	s7,40(sp)
    800037f0:	6165                	addi	sp,sp,112
    800037f2:	8082                	ret
    return 0;
    800037f4:	4501                	li	a0,0
}
    800037f6:	8082                	ret

00000000800037f8 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if (off > ip->size || off + n < off)
    800037f8:	457c                	lw	a5,76(a0)
    800037fa:	10d7e163          	bltu	a5,a3,800038fc <writei+0x104>
{
    800037fe:	7159                	addi	sp,sp,-112
    80003800:	f486                	sd	ra,104(sp)
    80003802:	f0a2                	sd	s0,96(sp)
    80003804:	e8ca                	sd	s2,80(sp)
    80003806:	e0d2                	sd	s4,64(sp)
    80003808:	fc56                	sd	s5,56(sp)
    8000380a:	f85a                	sd	s6,48(sp)
    8000380c:	f45e                	sd	s7,40(sp)
    8000380e:	1880                	addi	s0,sp,112
    80003810:	8aaa                	mv	s5,a0
    80003812:	8bae                	mv	s7,a1
    80003814:	8a32                	mv	s4,a2
    80003816:	8936                	mv	s2,a3
    80003818:	8b3a                	mv	s6,a4
  if (off > ip->size || off + n < off)
    8000381a:	9f35                	addw	a4,a4,a3
    return -1;
  if (off + n > MAXFILE * BSIZE)
    8000381c:	000437b7          	lui	a5,0x43
    80003820:	00e7b7b3          	sltu	a5,a5,a4
  if (off > ip->size || off + n < off)
    80003824:	00d73733          	sltu	a4,a4,a3
  if (off + n > MAXFILE * BSIZE)
    80003828:	8fd9                	or	a5,a5,a4
    8000382a:	ef91                	bnez	a5,80003846 <writei+0x4e>
    8000382c:	e4ce                	sd	s3,72(sp)
    return -1;

  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    8000382e:	0a0b0f63          	beqz	s6,800038ec <writei+0xf4>
    80003832:	eca6                	sd	s1,88(sp)
    80003834:	f062                	sd	s8,32(sp)
    80003836:	ec66                	sd	s9,24(sp)
    80003838:	e86a                	sd	s10,16(sp)
    8000383a:	e46e                	sd	s11,8(sp)
    8000383c:	4981                	li	s3,0
    uint addr = bmap(ip, off / BSIZE);
    if (addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off % BSIZE);
    8000383e:	40000c93          	li	s9,1024
    if (either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80003842:	5c7d                	li	s8,-1
    80003844:	a835                	j	80003880 <writei+0x88>
    return -1;
    80003846:	557d                	li	a0,-1
    80003848:	a849                	j	800038da <writei+0xe2>
    if (either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    8000384a:	020d1d93          	slli	s11,s10,0x20
    8000384e:	020ddd93          	srli	s11,s11,0x20
    80003852:	05848513          	addi	a0,s1,88
    80003856:	86ee                	mv	a3,s11
    80003858:	8652                	mv	a2,s4
    8000385a:	85de                	mv	a1,s7
    8000385c:	953e                	add	a0,a0,a5
    8000385e:	b57fe0ef          	jal	800023b4 <either_copyin>
    80003862:	05850663          	beq	a0,s8,800038ae <writei+0xb6>
      // Might have partially updated the block, so we need to log it.
      log_write(bp);
      brelse(bp);
      break;
    }
    log_write(bp);
    80003866:	8526                	mv	a0,s1
    80003868:	6fc000ef          	jal	80003f64 <log_write>
    brelse(bp);
    8000386c:	8526                	mv	a0,s1
    8000386e:	d26ff0ef          	jal	80002d94 <brelse>
  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80003872:	013d09bb          	addw	s3,s10,s3
    80003876:	012d093b          	addw	s2,s10,s2
    8000387a:	9a6e                	add	s4,s4,s11
    8000387c:	0369ff63          	bgeu	s3,s6,800038ba <writei+0xc2>
    uint addr = bmap(ip, off / BSIZE);
    80003880:	00a9559b          	srliw	a1,s2,0xa
    80003884:	8556                	mv	a0,s5
    80003886:	f6cff0ef          	jal	80002ff2 <bmap>
    8000388a:	85aa                	mv	a1,a0
    if (addr == 0)
    8000388c:	c51d                	beqz	a0,800038ba <writei+0xc2>
    bp = bread(ip->dev, addr);
    8000388e:	000aa503          	lw	a0,0(s5)
    80003892:	bfaff0ef          	jal	80002c8c <bread>
    80003896:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off % BSIZE);
    80003898:	3ff97793          	andi	a5,s2,1023
    8000389c:	40fc873b          	subw	a4,s9,a5
    800038a0:	413b06bb          	subw	a3,s6,s3
    800038a4:	8d3a                	mv	s10,a4
    800038a6:	fae6f2e3          	bgeu	a3,a4,8000384a <writei+0x52>
    800038aa:	8d36                	mv	s10,a3
    800038ac:	bf79                	j	8000384a <writei+0x52>
      log_write(bp);
    800038ae:	8526                	mv	a0,s1
    800038b0:	6b4000ef          	jal	80003f64 <log_write>
      brelse(bp);
    800038b4:	8526                	mv	a0,s1
    800038b6:	cdeff0ef          	jal	80002d94 <brelse>
  }

  if (off > ip->size)
    800038ba:	04caa783          	lw	a5,76(s5)
    800038be:	0327f963          	bgeu	a5,s2,800038f0 <writei+0xf8>
    ip->size = off;
    800038c2:	052aa623          	sw	s2,76(s5)
    800038c6:	64e6                	ld	s1,88(sp)
    800038c8:	7c02                	ld	s8,32(sp)
    800038ca:	6ce2                	ld	s9,24(sp)
    800038cc:	6d42                	ld	s10,16(sp)
    800038ce:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    800038d0:	8556                	mv	a0,s5
    800038d2:	9a7ff0ef          	jal	80003278 <iupdate>

  return tot;
    800038d6:	854e                	mv	a0,s3
    800038d8:	69a6                	ld	s3,72(sp)
}
    800038da:	70a6                	ld	ra,104(sp)
    800038dc:	7406                	ld	s0,96(sp)
    800038de:	6946                	ld	s2,80(sp)
    800038e0:	6a06                	ld	s4,64(sp)
    800038e2:	7ae2                	ld	s5,56(sp)
    800038e4:	7b42                	ld	s6,48(sp)
    800038e6:	7ba2                	ld	s7,40(sp)
    800038e8:	6165                	addi	sp,sp,112
    800038ea:	8082                	ret
  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    800038ec:	89da                	mv	s3,s6
    800038ee:	b7cd                	j	800038d0 <writei+0xd8>
    800038f0:	64e6                	ld	s1,88(sp)
    800038f2:	7c02                	ld	s8,32(sp)
    800038f4:	6ce2                	ld	s9,24(sp)
    800038f6:	6d42                	ld	s10,16(sp)
    800038f8:	6da2                	ld	s11,8(sp)
    800038fa:	bfd9                	j	800038d0 <writei+0xd8>
    return -1;
    800038fc:	557d                	li	a0,-1
}
    800038fe:	8082                	ret

0000000080003900 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80003900:	1141                	addi	sp,sp,-16
    80003902:	e406                	sd	ra,8(sp)
    80003904:	e022                	sd	s0,0(sp)
    80003906:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80003908:	4639                	li	a2,14
    8000390a:	caefd0ef          	jal	80000db8 <strncmp>
}
    8000390e:	60a2                	ld	ra,8(sp)
    80003910:	6402                	ld	s0,0(sp)
    80003912:	0141                	addi	sp,sp,16
    80003914:	8082                	ret

0000000080003916 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode *
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80003916:	711d                	addi	sp,sp,-96
    80003918:	ec86                	sd	ra,88(sp)
    8000391a:	e8a2                	sd	s0,80(sp)
    8000391c:	e4a6                	sd	s1,72(sp)
    8000391e:	e0ca                	sd	s2,64(sp)
    80003920:	fc4e                	sd	s3,56(sp)
    80003922:	f852                	sd	s4,48(sp)
    80003924:	f456                	sd	s5,40(sp)
    80003926:	f05a                	sd	s6,32(sp)
    80003928:	ec5e                	sd	s7,24(sp)
    8000392a:	1080                	addi	s0,sp,96
  uint off, inum;
  struct dirent de;

  if (dp->type != T_DIR)
    8000392c:	04451703          	lh	a4,68(a0)
    80003930:	4785                	li	a5,1
    80003932:	02f71963          	bne	a4,a5,80003964 <dirlookup+0x4e>
    80003936:	892a                	mv	s2,a0
    80003938:	8aae                	mv	s5,a1
    8000393a:	8bb2                	mv	s7,a2
    panic("dirlookup not DIR");

  for (off = 0; off < dp->size; off += sizeof(de)) {
    8000393c:	457c                	lw	a5,76(a0)
    8000393e:	4481                	li	s1,0
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003940:	fa040a13          	addi	s4,s0,-96
    80003944:	49c1                	li	s3,16
      panic("dirlookup read");
    if (de.inum == 0)
      continue;
    if (namecmp(name, de.name) == 0) {
    80003946:	fa240b13          	addi	s6,s0,-94
  for (off = 0; off < dp->size; off += sizeof(de)) {
    8000394a:	ef95                	bnez	a5,80003986 <dirlookup+0x70>
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    8000394c:	4501                	li	a0,0
}
    8000394e:	60e6                	ld	ra,88(sp)
    80003950:	6446                	ld	s0,80(sp)
    80003952:	64a6                	ld	s1,72(sp)
    80003954:	6906                	ld	s2,64(sp)
    80003956:	79e2                	ld	s3,56(sp)
    80003958:	7a42                	ld	s4,48(sp)
    8000395a:	7aa2                	ld	s5,40(sp)
    8000395c:	7b02                	ld	s6,32(sp)
    8000395e:	6be2                	ld	s7,24(sp)
    80003960:	6125                	addi	sp,sp,96
    80003962:	8082                	ret
    panic("dirlookup not DIR");
    80003964:	00004517          	auipc	a0,0x4
    80003968:	b9c50513          	addi	a0,a0,-1124 # 80007500 <etext+0x500>
    8000396c:	ec7fc0ef          	jal	80000832 <panic>
      panic("dirlookup read");
    80003970:	00004517          	auipc	a0,0x4
    80003974:	ba850513          	addi	a0,a0,-1112 # 80007518 <etext+0x518>
    80003978:	ebbfc0ef          	jal	80000832 <panic>
  for (off = 0; off < dp->size; off += sizeof(de)) {
    8000397c:	24c1                	addiw	s1,s1,16
    8000397e:	04c92783          	lw	a5,76(s2)
    80003982:	fcf4f5e3          	bgeu	s1,a5,8000394c <dirlookup+0x36>
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003986:	874e                	mv	a4,s3
    80003988:	86a6                	mv	a3,s1
    8000398a:	8652                	mv	a2,s4
    8000398c:	4581                	li	a1,0
    8000398e:	854a                	mv	a0,s2
    80003990:	d77ff0ef          	jal	80003706 <readi>
    80003994:	fd351ee3          	bne	a0,s3,80003970 <dirlookup+0x5a>
    if (de.inum == 0)
    80003998:	fa045783          	lhu	a5,-96(s0)
    8000399c:	d3e5                	beqz	a5,8000397c <dirlookup+0x66>
    if (namecmp(name, de.name) == 0) {
    8000399e:	85da                	mv	a1,s6
    800039a0:	8556                	mv	a0,s5
    800039a2:	f5fff0ef          	jal	80003900 <namecmp>
    800039a6:	f979                	bnez	a0,8000397c <dirlookup+0x66>
      if (poff)
    800039a8:	000b8463          	beqz	s7,800039b0 <dirlookup+0x9a>
        *poff = off;
    800039ac:	009ba023          	sw	s1,0(s7)
      return iget(dp->dev, inum);
    800039b0:	fa045583          	lhu	a1,-96(s0)
    800039b4:	00092503          	lw	a0,0(s2)
    800039b8:	efaff0ef          	jal	800030b2 <iget>
    800039bc:	bf49                	j	8000394e <dirlookup+0x38>

00000000800039be <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode *
namex(char *path, int nameiparent, char *name)
{
    800039be:	711d                	addi	sp,sp,-96
    800039c0:	ec86                	sd	ra,88(sp)
    800039c2:	e8a2                	sd	s0,80(sp)
    800039c4:	e4a6                	sd	s1,72(sp)
    800039c6:	e0ca                	sd	s2,64(sp)
    800039c8:	fc4e                	sd	s3,56(sp)
    800039ca:	f852                	sd	s4,48(sp)
    800039cc:	f456                	sd	s5,40(sp)
    800039ce:	f05a                	sd	s6,32(sp)
    800039d0:	ec5e                	sd	s7,24(sp)
    800039d2:	e862                	sd	s8,16(sp)
    800039d4:	e466                	sd	s9,8(sp)
    800039d6:	e06a                	sd	s10,0(sp)
    800039d8:	1080                	addi	s0,sp,96
    800039da:	84aa                	mv	s1,a0
    800039dc:	8b2e                	mv	s6,a1
    800039de:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if (*path == '/')
    800039e0:	00054703          	lbu	a4,0(a0)
    800039e4:	02f00793          	li	a5,47
    800039e8:	00f70f63          	beq	a4,a5,80003a06 <namex+0x48>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    800039ec:	f2bfd0ef          	jal	80001916 <myproc>
    800039f0:	15053503          	ld	a0,336(a0)
    800039f4:	903ff0ef          	jal	800032f6 <idup>
    800039f8:	8a2a                	mv	s4,a0
  while (*path == '/')
    800039fa:	02f00993          	li	s3,47
  if (len >= DIRSIZ)
    800039fe:	4c35                	li	s8,13
    memmove(name, s, DIRSIZ);
    80003a00:	4cb9                	li	s9,14

  while ((path = skipelem(path, name)) != 0) {
    ilock(ip);
    if (ip->type != T_DIR) {
    80003a02:	4b85                	li	s7,1
    80003a04:	a075                	j	80003ab0 <namex+0xf2>
    ip = iget(ROOTDEV, ROOTINO);
    80003a06:	4585                	li	a1,1
    80003a08:	852e                	mv	a0,a1
    80003a0a:	ea8ff0ef          	jal	800030b2 <iget>
    80003a0e:	8a2a                	mv	s4,a0
    80003a10:	b7ed                	j	800039fa <namex+0x3c>
      iunlockput(ip);
    80003a12:	8552                	mv	a0,s4
    80003a14:	b6dff0ef          	jal	80003580 <iunlockput>
      return 0;
    80003a18:	4a01                	li	s4,0
  if (nameiparent) {
    iput(ip);
    return 0;
  }
  return ip;
}
    80003a1a:	8552                	mv	a0,s4
    80003a1c:	60e6                	ld	ra,88(sp)
    80003a1e:	6446                	ld	s0,80(sp)
    80003a20:	64a6                	ld	s1,72(sp)
    80003a22:	6906                	ld	s2,64(sp)
    80003a24:	79e2                	ld	s3,56(sp)
    80003a26:	7a42                	ld	s4,48(sp)
    80003a28:	7aa2                	ld	s5,40(sp)
    80003a2a:	7b02                	ld	s6,32(sp)
    80003a2c:	6be2                	ld	s7,24(sp)
    80003a2e:	6c42                	ld	s8,16(sp)
    80003a30:	6ca2                	ld	s9,8(sp)
    80003a32:	6d02                	ld	s10,0(sp)
    80003a34:	6125                	addi	sp,sp,96
    80003a36:	8082                	ret
      iunlockput(ip);
    80003a38:	8552                	mv	a0,s4
    80003a3a:	b47ff0ef          	jal	80003580 <iunlockput>
      return 0;
    80003a3e:	bfe9                	j	80003a18 <namex+0x5a>
      iunlock(ip);
    80003a40:	8552                	mv	a0,s4
    80003a42:	999ff0ef          	jal	800033da <iunlock>
      return ip;
    80003a46:	bfd1                	j	80003a1a <namex+0x5c>
      iunlockput(ip);
    80003a48:	8552                	mv	a0,s4
    80003a4a:	b37ff0ef          	jal	80003580 <iunlockput>
      return 0;
    80003a4e:	8a4a                	mv	s4,s2
    80003a50:	b7e9                	j	80003a1a <namex+0x5c>
  while (*path != '/' && *path != 0)
    80003a52:	8926                	mv	s2,s1
  len = path - s;
    80003a54:	4d01                	li	s10,0
    80003a56:	4601                	li	a2,0
    memmove(name, s, len);
    80003a58:	2601                	sext.w	a2,a2
    80003a5a:	85a6                	mv	a1,s1
    80003a5c:	8556                	mv	a0,s5
    80003a5e:	ae6fd0ef          	jal	80000d44 <memmove>
    name[len] = 0;
    80003a62:	9d56                	add	s10,s10,s5
    80003a64:	000d0023          	sb	zero,0(s10) # fffffffffffff000 <end+0xffffffff7ffde218>
  while (*path == '/')
    80003a68:	00094783          	lbu	a5,0(s2)
    80003a6c:	0b379363          	bne	a5,s3,80003b12 <namex+0x154>
    80003a70:	84ca                	mv	s1,s2
    path++;
    80003a72:	0485                	addi	s1,s1,1
  while (*path == '/')
    80003a74:	0004c783          	lbu	a5,0(s1)
    80003a78:	ff378de3          	beq	a5,s3,80003a72 <namex+0xb4>
    ilock(ip);
    80003a7c:	8552                	mv	a0,s4
    80003a7e:	8afff0ef          	jal	8000332c <ilock>
    if (ip->type != T_DIR) {
    80003a82:	044a1783          	lh	a5,68(s4)
    80003a86:	f97796e3          	bne	a5,s7,80003a12 <namex+0x54>
    if (ip->nlink == 0) {
    80003a8a:	04aa1783          	lh	a5,74(s4)
    80003a8e:	d7cd                	beqz	a5,80003a38 <namex+0x7a>
    if (nameiparent && *path == '\0') {
    80003a90:	000b0563          	beqz	s6,80003a9a <namex+0xdc>
    80003a94:	0004c783          	lbu	a5,0(s1)
    80003a98:	d7c5                	beqz	a5,80003a40 <namex+0x82>
    if ((next = dirlookup(ip, name, 0)) == 0) {
    80003a9a:	4601                	li	a2,0
    80003a9c:	85d6                	mv	a1,s5
    80003a9e:	8552                	mv	a0,s4
    80003aa0:	e77ff0ef          	jal	80003916 <dirlookup>
    80003aa4:	892a                	mv	s2,a0
    80003aa6:	d14d                	beqz	a0,80003a48 <namex+0x8a>
    iunlockput(ip);
    80003aa8:	8552                	mv	a0,s4
    80003aaa:	ad7ff0ef          	jal	80003580 <iunlockput>
    ip = next;
    80003aae:	8a4a                	mv	s4,s2
  while (*path == '/')
    80003ab0:	0004c783          	lbu	a5,0(s1)
    80003ab4:	01379763          	bne	a5,s3,80003ac2 <namex+0x104>
    path++;
    80003ab8:	0485                	addi	s1,s1,1
  while (*path == '/')
    80003aba:	0004c783          	lbu	a5,0(s1)
    80003abe:	ff378de3          	beq	a5,s3,80003ab8 <namex+0xfa>
  if (*path == 0)
    80003ac2:	cfa1                	beqz	a5,80003b1a <namex+0x15c>
  while (*path != '/' && *path != 0)
    80003ac4:	0004c703          	lbu	a4,0(s1)
    80003ac8:	fd170793          	addi	a5,a4,-47
    80003acc:	00f037b3          	snez	a5,a5
    80003ad0:	00e03733          	snez	a4,a4
    80003ad4:	8ff9                	and	a5,a5,a4
    80003ad6:	dfb5                	beqz	a5,80003a52 <namex+0x94>
    80003ad8:	8926                	mv	s2,s1
    path++;
    80003ada:	0905                	addi	s2,s2,1
  while (*path != '/' && *path != 0)
    80003adc:	00094703          	lbu	a4,0(s2)
    80003ae0:	fd170793          	addi	a5,a4,-47
    80003ae4:	00f037b3          	snez	a5,a5
    80003ae8:	00e03733          	snez	a4,a4
    80003aec:	8ff9                	and	a5,a5,a4
    80003aee:	f7f5                	bnez	a5,80003ada <namex+0x11c>
  len = path - s;
    80003af0:	40990633          	sub	a2,s2,s1
    80003af4:	00060d1b          	sext.w	s10,a2
  if (len >= DIRSIZ)
    80003af8:	f7ac50e3          	bge	s8,s10,80003a58 <namex+0x9a>
    memmove(name, s, DIRSIZ);
    80003afc:	8666                	mv	a2,s9
    80003afe:	85a6                	mv	a1,s1
    80003b00:	8556                	mv	a0,s5
    80003b02:	a42fd0ef          	jal	80000d44 <memmove>
  while (*path == '/')
    80003b06:	00094783          	lbu	a5,0(s2)
    80003b0a:	84ca                	mv	s1,s2
    80003b0c:	f73783e3          	beq	a5,s3,80003a72 <namex+0xb4>
    80003b10:	b7b5                	j	80003a7c <namex+0xbe>
  while ((path = skipelem(path, name)) != 0) {
    80003b12:	00090463          	beqz	s2,80003b1a <namex+0x15c>
    80003b16:	84ca                	mv	s1,s2
    80003b18:	b795                	j	80003a7c <namex+0xbe>
  if (nameiparent) {
    80003b1a:	f00b00e3          	beqz	s6,80003a1a <namex+0x5c>
    iput(ip);
    80003b1e:	8552                	mv	a0,s4
    80003b20:	98fff0ef          	jal	800034ae <iput>
    return 0;
    80003b24:	bdd5                	j	80003a18 <namex+0x5a>

0000000080003b26 <dirlink>:
{
    80003b26:	715d                	addi	sp,sp,-80
    80003b28:	e486                	sd	ra,72(sp)
    80003b2a:	e0a2                	sd	s0,64(sp)
    80003b2c:	f84a                	sd	s2,48(sp)
    80003b2e:	ec56                	sd	s5,24(sp)
    80003b30:	e85a                	sd	s6,16(sp)
    80003b32:	0880                	addi	s0,sp,80
    80003b34:	892a                	mv	s2,a0
    80003b36:	8aae                	mv	s5,a1
    80003b38:	8b32                	mv	s6,a2
  if ((ip = dirlookup(dp, name, 0)) != 0) {
    80003b3a:	4601                	li	a2,0
    80003b3c:	ddbff0ef          	jal	80003916 <dirlookup>
    80003b40:	ed1d                	bnez	a0,80003b7e <dirlink+0x58>
    80003b42:	fc26                	sd	s1,56(sp)
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003b44:	04c92483          	lw	s1,76(s2)
    80003b48:	c4b9                	beqz	s1,80003b96 <dirlink+0x70>
    80003b4a:	f44e                	sd	s3,40(sp)
    80003b4c:	f052                	sd	s4,32(sp)
    80003b4e:	4481                	li	s1,0
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003b50:	fb040a13          	addi	s4,s0,-80
    80003b54:	49c1                	li	s3,16
    80003b56:	874e                	mv	a4,s3
    80003b58:	86a6                	mv	a3,s1
    80003b5a:	8652                	mv	a2,s4
    80003b5c:	4581                	li	a1,0
    80003b5e:	854a                	mv	a0,s2
    80003b60:	ba7ff0ef          	jal	80003706 <readi>
    80003b64:	03351163          	bne	a0,s3,80003b86 <dirlink+0x60>
    if (de.inum == 0)
    80003b68:	fb045783          	lhu	a5,-80(s0)
    80003b6c:	c39d                	beqz	a5,80003b92 <dirlink+0x6c>
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003b6e:	24c1                	addiw	s1,s1,16
    80003b70:	04c92783          	lw	a5,76(s2)
    80003b74:	fef4e1e3          	bltu	s1,a5,80003b56 <dirlink+0x30>
    80003b78:	79a2                	ld	s3,40(sp)
    80003b7a:	7a02                	ld	s4,32(sp)
    80003b7c:	a829                	j	80003b96 <dirlink+0x70>
    iput(ip);
    80003b7e:	931ff0ef          	jal	800034ae <iput>
    return -1;
    80003b82:	557d                	li	a0,-1
    80003b84:	a83d                	j	80003bc2 <dirlink+0x9c>
      panic("dirlink read");
    80003b86:	00004517          	auipc	a0,0x4
    80003b8a:	9a250513          	addi	a0,a0,-1630 # 80007528 <etext+0x528>
    80003b8e:	ca5fc0ef          	jal	80000832 <panic>
    80003b92:	79a2                	ld	s3,40(sp)
    80003b94:	7a02                	ld	s4,32(sp)
  strncpy(de.name, name, DIRSIZ);
    80003b96:	4639                	li	a2,14
    80003b98:	85d6                	mv	a1,s5
    80003b9a:	fb240513          	addi	a0,s0,-78
    80003b9e:	a50fd0ef          	jal	80000dee <strncpy>
  de.inum = inum;
    80003ba2:	fb641823          	sh	s6,-80(s0)
  if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003ba6:	4741                	li	a4,16
    80003ba8:	86a6                	mv	a3,s1
    80003baa:	fb040613          	addi	a2,s0,-80
    80003bae:	4581                	li	a1,0
    80003bb0:	854a                	mv	a0,s2
    80003bb2:	c47ff0ef          	jal	800037f8 <writei>
    80003bb6:	1541                	addi	a0,a0,-16
    80003bb8:	00a03533          	snez	a0,a0
    80003bbc:	40a0053b          	negw	a0,a0
    80003bc0:	74e2                	ld	s1,56(sp)
}
    80003bc2:	60a6                	ld	ra,72(sp)
    80003bc4:	6406                	ld	s0,64(sp)
    80003bc6:	7942                	ld	s2,48(sp)
    80003bc8:	6ae2                	ld	s5,24(sp)
    80003bca:	6b42                	ld	s6,16(sp)
    80003bcc:	6161                	addi	sp,sp,80
    80003bce:	8082                	ret

0000000080003bd0 <namei>:

struct inode *
namei(char *path)
{
    80003bd0:	1101                	addi	sp,sp,-32
    80003bd2:	ec06                	sd	ra,24(sp)
    80003bd4:	e822                	sd	s0,16(sp)
    80003bd6:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80003bd8:	fe040613          	addi	a2,s0,-32
    80003bdc:	4581                	li	a1,0
    80003bde:	de1ff0ef          	jal	800039be <namex>
}
    80003be2:	60e2                	ld	ra,24(sp)
    80003be4:	6442                	ld	s0,16(sp)
    80003be6:	6105                	addi	sp,sp,32
    80003be8:	8082                	ret

0000000080003bea <nameiparent>:

struct inode *
nameiparent(char *path, char *name)
{
    80003bea:	1141                	addi	sp,sp,-16
    80003bec:	e406                	sd	ra,8(sp)
    80003bee:	e022                	sd	s0,0(sp)
    80003bf0:	0800                	addi	s0,sp,16
    80003bf2:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80003bf4:	4585                	li	a1,1
    80003bf6:	dc9ff0ef          	jal	800039be <namex>
}
    80003bfa:	60a2                	ld	ra,8(sp)
    80003bfc:	6402                	ld	s0,0(sp)
    80003bfe:	0141                	addi	sp,sp,16
    80003c00:	8082                	ret

0000000080003c02 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80003c02:	1101                	addi	sp,sp,-32
    80003c04:	ec06                	sd	ra,24(sp)
    80003c06:	e822                	sd	s0,16(sp)
    80003c08:	e426                	sd	s1,8(sp)
    80003c0a:	e04a                	sd	s2,0(sp)
    80003c0c:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003c0e:	0001c917          	auipc	s2,0x1c
    80003c12:	f9a90913          	addi	s2,s2,-102 # 8001fba8 <log>
    80003c16:	01892583          	lw	a1,24(s2)
    80003c1a:	02492503          	lw	a0,36(s2)
    80003c1e:	86eff0ef          	jal	80002c8c <bread>
    80003c22:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *)(buf->data);
  int i;
  hb->n = log.lh.n;
    80003c24:	02c92603          	lw	a2,44(s2)
    80003c28:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003c2a:	00c05f63          	blez	a2,80003c48 <write_head+0x46>
    80003c2e:	0001c717          	auipc	a4,0x1c
    80003c32:	faa70713          	addi	a4,a4,-86 # 8001fbd8 <log+0x30>
    80003c36:	87aa                	mv	a5,a0
    80003c38:	060a                	slli	a2,a2,0x2
    80003c3a:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80003c3c:	4314                	lw	a3,0(a4)
    80003c3e:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80003c40:	0711                	addi	a4,a4,4
    80003c42:	0791                	addi	a5,a5,4 # 43004 <_entry-0x7ffbcffc>
    80003c44:	fec79ce3          	bne	a5,a2,80003c3c <write_head+0x3a>
  }
  bwrite(buf);
    80003c48:	8526                	mv	a0,s1
    80003c4a:	918ff0ef          	jal	80002d62 <bwrite>
  brelse(buf);
    80003c4e:	8526                	mv	a0,s1
    80003c50:	944ff0ef          	jal	80002d94 <brelse>
}
    80003c54:	60e2                	ld	ra,24(sp)
    80003c56:	6442                	ld	s0,16(sp)
    80003c58:	64a2                	ld	s1,8(sp)
    80003c5a:	6902                	ld	s2,0(sp)
    80003c5c:	6105                	addi	sp,sp,32
    80003c5e:	8082                	ret

0000000080003c60 <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003c60:	0001c797          	auipc	a5,0x1c
    80003c64:	f747a783          	lw	a5,-140(a5) # 8001fbd4 <log+0x2c>
    80003c68:	0cf05163          	blez	a5,80003d2a <install_trans+0xca>
{
    80003c6c:	715d                	addi	sp,sp,-80
    80003c6e:	e486                	sd	ra,72(sp)
    80003c70:	e0a2                	sd	s0,64(sp)
    80003c72:	fc26                	sd	s1,56(sp)
    80003c74:	f84a                	sd	s2,48(sp)
    80003c76:	f44e                	sd	s3,40(sp)
    80003c78:	f052                	sd	s4,32(sp)
    80003c7a:	ec56                	sd	s5,24(sp)
    80003c7c:	e85a                	sd	s6,16(sp)
    80003c7e:	e45e                	sd	s7,8(sp)
    80003c80:	e062                	sd	s8,0(sp)
    80003c82:	0880                	addi	s0,sp,80
    80003c84:	8b2a                	mv	s6,a0
    80003c86:	0001ca97          	auipc	s5,0x1c
    80003c8a:	f52a8a93          	addi	s5,s5,-174 # 8001fbd8 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003c8e:	4981                	li	s3,0
      printk("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003c90:	00004c17          	auipc	s8,0x4
    80003c94:	8a8c0c13          	addi	s8,s8,-1880 # 80007538 <etext+0x538>
    struct buf *lbuf = bread(log.dev, log.start + tail + 1); // read log block
    80003c98:	0001ca17          	auipc	s4,0x1c
    80003c9c:	f10a0a13          	addi	s4,s4,-240 # 8001fba8 <log>
    memmove(dbuf->data, lbuf->data, BSIZE); // copy block to dst
    80003ca0:	40000b93          	li	s7,1024
    80003ca4:	a025                	j	80003ccc <install_trans+0x6c>
      printk("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003ca6:	000aa603          	lw	a2,0(s5)
    80003caa:	85ce                	mv	a1,s3
    80003cac:	8562                	mv	a0,s8
    80003cae:	84dfc0ef          	jal	800004fa <printk>
    80003cb2:	a839                	j	80003cd0 <install_trans+0x70>
    brelse(lbuf);
    80003cb4:	854a                	mv	a0,s2
    80003cb6:	8deff0ef          	jal	80002d94 <brelse>
    brelse(dbuf);
    80003cba:	8526                	mv	a0,s1
    80003cbc:	8d8ff0ef          	jal	80002d94 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003cc0:	2985                	addiw	s3,s3,1
    80003cc2:	0a91                	addi	s5,s5,4
    80003cc4:	02ca2783          	lw	a5,44(s4)
    80003cc8:	04f9d563          	bge	s3,a5,80003d12 <install_trans+0xb2>
    if (recovering) {
    80003ccc:	fc0b1de3          	bnez	s6,80003ca6 <install_trans+0x46>
    struct buf *lbuf = bread(log.dev, log.start + tail + 1); // read log block
    80003cd0:	018a2583          	lw	a1,24(s4)
    80003cd4:	013585bb          	addw	a1,a1,s3
    80003cd8:	2585                	addiw	a1,a1,1
    80003cda:	024a2503          	lw	a0,36(s4)
    80003cde:	faffe0ef          	jal	80002c8c <bread>
    80003ce2:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]);   // read dst
    80003ce4:	000aa583          	lw	a1,0(s5)
    80003ce8:	024a2503          	lw	a0,36(s4)
    80003cec:	fa1fe0ef          	jal	80002c8c <bread>
    80003cf0:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE); // copy block to dst
    80003cf2:	865e                	mv	a2,s7
    80003cf4:	05890593          	addi	a1,s2,88
    80003cf8:	05850513          	addi	a0,a0,88
    80003cfc:	848fd0ef          	jal	80000d44 <memmove>
    bwrite(dbuf);                           // write dst to disk
    80003d00:	8526                	mv	a0,s1
    80003d02:	860ff0ef          	jal	80002d62 <bwrite>
    if (recovering == 0)
    80003d06:	fa0b17e3          	bnez	s6,80003cb4 <install_trans+0x54>
      bunpin(dbuf);
    80003d0a:	8526                	mv	a0,s1
    80003d0c:	940ff0ef          	jal	80002e4c <bunpin>
    80003d10:	b755                	j	80003cb4 <install_trans+0x54>
}
    80003d12:	60a6                	ld	ra,72(sp)
    80003d14:	6406                	ld	s0,64(sp)
    80003d16:	74e2                	ld	s1,56(sp)
    80003d18:	7942                	ld	s2,48(sp)
    80003d1a:	79a2                	ld	s3,40(sp)
    80003d1c:	7a02                	ld	s4,32(sp)
    80003d1e:	6ae2                	ld	s5,24(sp)
    80003d20:	6b42                	ld	s6,16(sp)
    80003d22:	6ba2                	ld	s7,8(sp)
    80003d24:	6c02                	ld	s8,0(sp)
    80003d26:	6161                	addi	sp,sp,80
    80003d28:	8082                	ret
    80003d2a:	8082                	ret

0000000080003d2c <initlog>:
{
    80003d2c:	7179                	addi	sp,sp,-48
    80003d2e:	f406                	sd	ra,40(sp)
    80003d30:	f022                	sd	s0,32(sp)
    80003d32:	ec26                	sd	s1,24(sp)
    80003d34:	e84a                	sd	s2,16(sp)
    80003d36:	e44e                	sd	s3,8(sp)
    80003d38:	1800                	addi	s0,sp,48
    80003d3a:	84aa                	mv	s1,a0
    80003d3c:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003d3e:	0001c917          	auipc	s2,0x1c
    80003d42:	e6a90913          	addi	s2,s2,-406 # 8001fba8 <log>
    80003d46:	00004597          	auipc	a1,0x4
    80003d4a:	81258593          	addi	a1,a1,-2030 # 80007558 <etext+0x558>
    80003d4e:	854a                	mv	a0,s2
    80003d50:	e41fc0ef          	jal	80000b90 <initlock>
  log.start = sb->logstart;
    80003d54:	0149a583          	lw	a1,20(s3)
    80003d58:	00b92c23          	sw	a1,24(s2)
  log.dev = dev;
    80003d5c:	02992223          	sw	s1,36(s2)
  struct buf *buf = bread(log.dev, log.start);
    80003d60:	8526                	mv	a0,s1
    80003d62:	f2bfe0ef          	jal	80002c8c <bread>
  log.lh.n = lh->n;
    80003d66:	4d30                	lw	a2,88(a0)
    80003d68:	02c92623          	sw	a2,44(s2)
  for (i = 0; i < log.lh.n; i++) {
    80003d6c:	00c05f63          	blez	a2,80003d8a <initlog+0x5e>
    80003d70:	87aa                	mv	a5,a0
    80003d72:	0001c717          	auipc	a4,0x1c
    80003d76:	e6670713          	addi	a4,a4,-410 # 8001fbd8 <log+0x30>
    80003d7a:	060a                	slli	a2,a2,0x2
    80003d7c:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80003d7e:	4ff4                	lw	a3,92(a5)
    80003d80:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003d82:	0791                	addi	a5,a5,4
    80003d84:	0711                	addi	a4,a4,4
    80003d86:	fec79ce3          	bne	a5,a2,80003d7e <initlog+0x52>
  brelse(buf);
    80003d8a:	80aff0ef          	jal	80002d94 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003d8e:	4505                	li	a0,1
    80003d90:	ed1ff0ef          	jal	80003c60 <install_trans>
  log.lh.n = 0;
    80003d94:	0001c797          	auipc	a5,0x1c
    80003d98:	e407a023          	sw	zero,-448(a5) # 8001fbd4 <log+0x2c>
  write_head(); // clear the log
    80003d9c:	e67ff0ef          	jal	80003c02 <write_head>
}
    80003da0:	70a2                	ld	ra,40(sp)
    80003da2:	7402                	ld	s0,32(sp)
    80003da4:	64e2                	ld	s1,24(sp)
    80003da6:	6942                	ld	s2,16(sp)
    80003da8:	69a2                	ld	s3,8(sp)
    80003daa:	6145                	addi	sp,sp,48
    80003dac:	8082                	ret

0000000080003dae <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003dae:	1101                	addi	sp,sp,-32
    80003db0:	ec06                	sd	ra,24(sp)
    80003db2:	e822                	sd	s0,16(sp)
    80003db4:	e426                	sd	s1,8(sp)
    80003db6:	e04a                	sd	s2,0(sp)
    80003db8:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003dba:	0001c517          	auipc	a0,0x1c
    80003dbe:	dee50513          	addi	a0,a0,-530 # 8001fba8 <log>
    80003dc2:	e4ffc0ef          	jal	80000c10 <acquire>
  while (1) {
    if (log.committing) {
    80003dc6:	0001c497          	auipc	s1,0x1c
    80003dca:	de248493          	addi	s1,s1,-542 # 8001fba8 <log>
      sleep_prepare(&log);
      release(&log.lock);
      sleep(&log, &log.lock);
      acquire(&log.lock);
    } else if (log.lh.n + (log.outstanding + 1) * MAXOPBLOCKS > LOGBLOCKS) {
    80003dce:	4979                	li	s2,30
    80003dd0:	a831                	j	80003dec <begin_op+0x3e>
      sleep_prepare(&log);
    80003dd2:	8526                	mv	a0,s1
    80003dd4:	9d0fe0ef          	jal	80001fa4 <sleep_prepare>
      release(&log.lock);
    80003dd8:	8526                	mv	a0,s1
    80003dda:	ec9fc0ef          	jal	80000ca2 <release>
      sleep(&log, &log.lock);
    80003dde:	85a6                	mv	a1,s1
    80003de0:	8526                	mv	a0,s1
    80003de2:	9fefe0ef          	jal	80001fe0 <sleep>
      acquire(&log.lock);
    80003de6:	8526                	mv	a0,s1
    80003de8:	e29fc0ef          	jal	80000c10 <acquire>
    if (log.committing) {
    80003dec:	509c                	lw	a5,32(s1)
    80003dee:	f3f5                	bnez	a5,80003dd2 <begin_op+0x24>
    } else if (log.lh.n + (log.outstanding + 1) * MAXOPBLOCKS > LOGBLOCKS) {
    80003df0:	4cd8                	lw	a4,28(s1)
    80003df2:	2705                	addiw	a4,a4,1
    80003df4:	0027179b          	slliw	a5,a4,0x2
    80003df8:	9fb9                	addw	a5,a5,a4
    80003dfa:	0017979b          	slliw	a5,a5,0x1
    80003dfe:	54d4                	lw	a3,44(s1)
    80003e00:	9fb5                	addw	a5,a5,a3
    80003e02:	02f95063          	bge	s2,a5,80003e22 <begin_op+0x74>
      // this op might exhaust log space; wait for commit.
      sleep_prepare(&log);
    80003e06:	8526                	mv	a0,s1
    80003e08:	99cfe0ef          	jal	80001fa4 <sleep_prepare>
      release(&log.lock);
    80003e0c:	8526                	mv	a0,s1
    80003e0e:	e95fc0ef          	jal	80000ca2 <release>
      sleep(&log, &log.lock);
    80003e12:	85a6                	mv	a1,s1
    80003e14:	8526                	mv	a0,s1
    80003e16:	9cafe0ef          	jal	80001fe0 <sleep>
      acquire(&log.lock);
    80003e1a:	8526                	mv	a0,s1
    80003e1c:	df5fc0ef          	jal	80000c10 <acquire>
    80003e20:	b7f1                	j	80003dec <begin_op+0x3e>
    } else {
      log.outstanding += 1;
    80003e22:	0001c797          	auipc	a5,0x1c
    80003e26:	dae7a123          	sw	a4,-606(a5) # 8001fbc4 <log+0x1c>
      release(&log.lock);
    80003e2a:	0001c517          	auipc	a0,0x1c
    80003e2e:	d7e50513          	addi	a0,a0,-642 # 8001fba8 <log>
    80003e32:	e71fc0ef          	jal	80000ca2 <release>
      break;
    }
  }
}
    80003e36:	60e2                	ld	ra,24(sp)
    80003e38:	6442                	ld	s0,16(sp)
    80003e3a:	64a2                	ld	s1,8(sp)
    80003e3c:	6902                	ld	s2,0(sp)
    80003e3e:	6105                	addi	sp,sp,32
    80003e40:	8082                	ret

0000000080003e42 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80003e42:	7139                	addi	sp,sp,-64
    80003e44:	fc06                	sd	ra,56(sp)
    80003e46:	f822                	sd	s0,48(sp)
    80003e48:	f426                	sd	s1,40(sp)
    80003e4a:	f04a                	sd	s2,32(sp)
    80003e4c:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80003e4e:	0001c497          	auipc	s1,0x1c
    80003e52:	d5a48493          	addi	s1,s1,-678 # 8001fba8 <log>
    80003e56:	8526                	mv	a0,s1
    80003e58:	db9fc0ef          	jal	80000c10 <acquire>
  log.outstanding -= 1;
    80003e5c:	4cdc                	lw	a5,28(s1)
    80003e5e:	37fd                	addiw	a5,a5,-1
    80003e60:	893e                	mv	s2,a5
    80003e62:	ccdc                	sw	a5,28(s1)
  if (log.committing)
    80003e64:	509c                	lw	a5,32(s1)
    80003e66:	e7b9                	bnez	a5,80003eb4 <end_op+0x72>
    panic("log.committing");
  if (log.outstanding == 0) {
    80003e68:	04091f63          	bnez	s2,80003ec6 <end_op+0x84>
    do_commit = 1;
    log.committing = 1;
    80003e6c:	0001c497          	auipc	s1,0x1c
    80003e70:	d3c48493          	addi	s1,s1,-708 # 8001fba8 <log>
    80003e74:	4785                	li	a5,1
    80003e76:	d09c                	sw	a5,32(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80003e78:	8526                	mv	a0,s1
    80003e7a:	e29fc0ef          	jal	80000ca2 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80003e7e:	54dc                	lw	a5,44(s1)
    80003e80:	06f04063          	bgtz	a5,80003ee0 <end_op+0x9e>
    acquire(&log.lock);
    80003e84:	0001c497          	auipc	s1,0x1c
    80003e88:	d2448493          	addi	s1,s1,-732 # 8001fba8 <log>
    80003e8c:	8526                	mv	a0,s1
    80003e8e:	d83fc0ef          	jal	80000c10 <acquire>
    log.committing = 0;
    80003e92:	0204a023          	sw	zero,32(s1)
    log.ncommit += 1;
    80003e96:	549c                	lw	a5,40(s1)
    80003e98:	2785                	addiw	a5,a5,1
    80003e9a:	d49c                	sw	a5,40(s1)
    wakeup(&log);
    80003e9c:	8526                	mv	a0,s1
    80003e9e:	98efe0ef          	jal	8000202c <wakeup>
    release(&log.lock);
    80003ea2:	8526                	mv	a0,s1
    80003ea4:	dfffc0ef          	jal	80000ca2 <release>
}
    80003ea8:	70e2                	ld	ra,56(sp)
    80003eaa:	7442                	ld	s0,48(sp)
    80003eac:	74a2                	ld	s1,40(sp)
    80003eae:	7902                	ld	s2,32(sp)
    80003eb0:	6121                	addi	sp,sp,64
    80003eb2:	8082                	ret
    80003eb4:	ec4e                	sd	s3,24(sp)
    80003eb6:	e852                	sd	s4,16(sp)
    80003eb8:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80003eba:	00003517          	auipc	a0,0x3
    80003ebe:	6a650513          	addi	a0,a0,1702 # 80007560 <etext+0x560>
    80003ec2:	971fc0ef          	jal	80000832 <panic>
    wakeup(&log);
    80003ec6:	0001c517          	auipc	a0,0x1c
    80003eca:	ce250513          	addi	a0,a0,-798 # 8001fba8 <log>
    80003ece:	95efe0ef          	jal	8000202c <wakeup>
  release(&log.lock);
    80003ed2:	0001c517          	auipc	a0,0x1c
    80003ed6:	cd650513          	addi	a0,a0,-810 # 8001fba8 <log>
    80003eda:	dc9fc0ef          	jal	80000ca2 <release>
  if (do_commit) {
    80003ede:	b7e9                	j	80003ea8 <end_op+0x66>
    80003ee0:	ec4e                	sd	s3,24(sp)
    80003ee2:	e852                	sd	s4,16(sp)
    80003ee4:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    80003ee6:	0001ca97          	auipc	s5,0x1c
    80003eea:	cf2a8a93          	addi	s5,s5,-782 # 8001fbd8 <log+0x30>
    struct buf *to = bread(log.dev, log.start + tail + 1); // log block
    80003eee:	0001ca17          	auipc	s4,0x1c
    80003ef2:	cbaa0a13          	addi	s4,s4,-838 # 8001fba8 <log>
    80003ef6:	018a2583          	lw	a1,24(s4)
    80003efa:	012585bb          	addw	a1,a1,s2
    80003efe:	2585                	addiw	a1,a1,1
    80003f00:	024a2503          	lw	a0,36(s4)
    80003f04:	d89fe0ef          	jal	80002c8c <bread>
    80003f08:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80003f0a:	000aa583          	lw	a1,0(s5)
    80003f0e:	024a2503          	lw	a0,36(s4)
    80003f12:	d7bfe0ef          	jal	80002c8c <bread>
    80003f16:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80003f18:	40000613          	li	a2,1024
    80003f1c:	05850593          	addi	a1,a0,88
    80003f20:	05848513          	addi	a0,s1,88
    80003f24:	e21fc0ef          	jal	80000d44 <memmove>
    bwrite(to); // write the log
    80003f28:	8526                	mv	a0,s1
    80003f2a:	e39fe0ef          	jal	80002d62 <bwrite>
    brelse(from);
    80003f2e:	854e                	mv	a0,s3
    80003f30:	e65fe0ef          	jal	80002d94 <brelse>
    brelse(to);
    80003f34:	8526                	mv	a0,s1
    80003f36:	e5ffe0ef          	jal	80002d94 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003f3a:	2905                	addiw	s2,s2,1
    80003f3c:	0a91                	addi	s5,s5,4
    80003f3e:	02ca2783          	lw	a5,44(s4)
    80003f42:	faf94ae3          	blt	s2,a5,80003ef6 <end_op+0xb4>
    write_log();      // Write modified blocks from cache to log
    write_head();     // Write header to disk -- the real commit
    80003f46:	cbdff0ef          	jal	80003c02 <write_head>
    install_trans(0); // Now install writes to home locations
    80003f4a:	4501                	li	a0,0
    80003f4c:	d15ff0ef          	jal	80003c60 <install_trans>
    log.lh.n = 0;
    80003f50:	0001c797          	auipc	a5,0x1c
    80003f54:	c807a223          	sw	zero,-892(a5) # 8001fbd4 <log+0x2c>
    write_head(); // Erase the transaction from the log
    80003f58:	cabff0ef          	jal	80003c02 <write_head>
    80003f5c:	69e2                	ld	s3,24(sp)
    80003f5e:	6a42                	ld	s4,16(sp)
    80003f60:	6aa2                	ld	s5,8(sp)
    80003f62:	b70d                	j	80003e84 <end_op+0x42>

0000000080003f64 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    80003f64:	1101                	addi	sp,sp,-32
    80003f66:	ec06                	sd	ra,24(sp)
    80003f68:	e822                	sd	s0,16(sp)
    80003f6a:	e426                	sd	s1,8(sp)
    80003f6c:	1000                	addi	s0,sp,32
    80003f6e:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80003f70:	0001c517          	auipc	a0,0x1c
    80003f74:	c3850513          	addi	a0,a0,-968 # 8001fba8 <log>
    80003f78:	c99fc0ef          	jal	80000c10 <acquire>
  if (log.lh.n >= LOGBLOCKS)
    80003f7c:	0001c617          	auipc	a2,0x1c
    80003f80:	c5862603          	lw	a2,-936(a2) # 8001fbd4 <log+0x2c>
    80003f84:	47f5                	li	a5,29
    80003f86:	04c7cc63          	blt	a5,a2,80003fde <log_write+0x7a>
    panic("too big a transaction");
  if (log.outstanding < 1)
    80003f8a:	0001c797          	auipc	a5,0x1c
    80003f8e:	c3a7a783          	lw	a5,-966(a5) # 8001fbc4 <log+0x1c>
    80003f92:	04f05c63          	blez	a5,80003fea <log_write+0x86>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80003f96:	4781                	li	a5,0
    80003f98:	04c05f63          	blez	a2,80003ff6 <log_write+0x92>
    if (log.lh.block[i] == b->blockno) // log absorption
    80003f9c:	44cc                	lw	a1,12(s1)
    80003f9e:	0001c717          	auipc	a4,0x1c
    80003fa2:	c3a70713          	addi	a4,a4,-966 # 8001fbd8 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    80003fa6:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno) // log absorption
    80003fa8:	4314                	lw	a3,0(a4)
    80003faa:	04b68663          	beq	a3,a1,80003ff6 <log_write+0x92>
  for (i = 0; i < log.lh.n; i++) {
    80003fae:	2785                	addiw	a5,a5,1
    80003fb0:	0711                	addi	a4,a4,4
    80003fb2:	fef61be3          	bne	a2,a5,80003fa8 <log_write+0x44>
      break;
  }
  log.lh.block[i] = b->blockno;
    80003fb6:	0621                	addi	a2,a2,8
    80003fb8:	060a                	slli	a2,a2,0x2
    80003fba:	0001c797          	auipc	a5,0x1c
    80003fbe:	bee78793          	addi	a5,a5,-1042 # 8001fba8 <log>
    80003fc2:	97b2                	add	a5,a5,a2
    80003fc4:	44d8                	lw	a4,12(s1)
    80003fc6:	cb98                	sw	a4,16(a5)
  if (i == log.lh.n) { // Add new block to log?
    bpin(b);
    80003fc8:	8526                	mv	a0,s1
    80003fca:	e4ffe0ef          	jal	80002e18 <bpin>
    log.lh.n++;
    80003fce:	0001c717          	auipc	a4,0x1c
    80003fd2:	bda70713          	addi	a4,a4,-1062 # 8001fba8 <log>
    80003fd6:	575c                	lw	a5,44(a4)
    80003fd8:	2785                	addiw	a5,a5,1
    80003fda:	d75c                	sw	a5,44(a4)
    80003fdc:	a80d                	j	8000400e <log_write+0xaa>
    panic("too big a transaction");
    80003fde:	00003517          	auipc	a0,0x3
    80003fe2:	59250513          	addi	a0,a0,1426 # 80007570 <etext+0x570>
    80003fe6:	84dfc0ef          	jal	80000832 <panic>
    panic("log_write outside of trans");
    80003fea:	00003517          	auipc	a0,0x3
    80003fee:	59e50513          	addi	a0,a0,1438 # 80007588 <etext+0x588>
    80003ff2:	841fc0ef          	jal	80000832 <panic>
  log.lh.block[i] = b->blockno;
    80003ff6:	00878693          	addi	a3,a5,8
    80003ffa:	068a                	slli	a3,a3,0x2
    80003ffc:	0001c717          	auipc	a4,0x1c
    80004000:	bac70713          	addi	a4,a4,-1108 # 8001fba8 <log>
    80004004:	9736                	add	a4,a4,a3
    80004006:	44d4                	lw	a3,12(s1)
    80004008:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) { // Add new block to log?
    8000400a:	faf60fe3          	beq	a2,a5,80003fc8 <log_write+0x64>
  }
  release(&log.lock);
    8000400e:	0001c517          	auipc	a0,0x1c
    80004012:	b9a50513          	addi	a0,a0,-1126 # 8001fba8 <log>
    80004016:	c8dfc0ef          	jal	80000ca2 <release>
}
    8000401a:	60e2                	ld	ra,24(sp)
    8000401c:	6442                	ld	s0,16(sp)
    8000401e:	64a2                	ld	s1,8(sp)
    80004020:	6105                	addi	sp,sp,32
    80004022:	8082                	ret

0000000080004024 <sys_sync>:

uint64
sys_sync(void)
{
    80004024:	1101                	addi	sp,sp,-32
    80004026:	ec06                	sd	ra,24(sp)
    80004028:	e822                	sd	s0,16(sp)
    8000402a:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    8000402c:	0001c517          	auipc	a0,0x1c
    80004030:	b7c50513          	addi	a0,a0,-1156 # 8001fba8 <log>
    80004034:	bddfc0ef          	jal	80000c10 <acquire>
  if (log.committing || log.outstanding > 0) {
    80004038:	0001c797          	auipc	a5,0x1c
    8000403c:	b907a783          	lw	a5,-1136(a5) # 8001fbc8 <log+0x20>
    80004040:	e799                	bnez	a5,8000404e <sys_sync+0x2a>
    80004042:	0001c797          	auipc	a5,0x1c
    80004046:	b827a783          	lw	a5,-1150(a5) # 8001fbc4 <log+0x1c>
    8000404a:	02f05e63          	blez	a5,80004086 <sys_sync+0x62>
    8000404e:	e426                	sd	s1,8(sp)
    80004050:	e04a                	sd	s2,0(sp)
    int n = log.ncommit + 1;
    80004052:	0001c917          	auipc	s2,0x1c
    80004056:	b7e92903          	lw	s2,-1154(s2) # 8001fbd0 <log+0x28>
    while (log.ncommit < n) {
      sleep_prepare(&log);
    8000405a:	0001c497          	auipc	s1,0x1c
    8000405e:	b4e48493          	addi	s1,s1,-1202 # 8001fba8 <log>
    80004062:	8526                	mv	a0,s1
    80004064:	f41fd0ef          	jal	80001fa4 <sleep_prepare>
      release(&log.lock);
    80004068:	8526                	mv	a0,s1
    8000406a:	c39fc0ef          	jal	80000ca2 <release>
      sleep(&log, &log.lock);
    8000406e:	85a6                	mv	a1,s1
    80004070:	8526                	mv	a0,s1
    80004072:	f6ffd0ef          	jal	80001fe0 <sleep>
      acquire(&log.lock);
    80004076:	8526                	mv	a0,s1
    80004078:	b99fc0ef          	jal	80000c10 <acquire>
    while (log.ncommit < n) {
    8000407c:	549c                	lw	a5,40(s1)
    8000407e:	fef952e3          	bge	s2,a5,80004062 <sys_sync+0x3e>
    80004082:	64a2                	ld	s1,8(sp)
    80004084:	6902                	ld	s2,0(sp)
    }
  }
  release(&log.lock);
    80004086:	0001c517          	auipc	a0,0x1c
    8000408a:	b2250513          	addi	a0,a0,-1246 # 8001fba8 <log>
    8000408e:	c15fc0ef          	jal	80000ca2 <release>
  return 0;
}
    80004092:	4501                	li	a0,0
    80004094:	60e2                	ld	ra,24(sp)
    80004096:	6442                	ld	s0,16(sp)
    80004098:	6105                	addi	sp,sp,32
    8000409a:	8082                	ret

000000008000409c <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    8000409c:	1101                	addi	sp,sp,-32
    8000409e:	ec06                	sd	ra,24(sp)
    800040a0:	e822                	sd	s0,16(sp)
    800040a2:	e426                	sd	s1,8(sp)
    800040a4:	e04a                	sd	s2,0(sp)
    800040a6:	1000                	addi	s0,sp,32
    800040a8:	84aa                	mv	s1,a0
    800040aa:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    800040ac:	00003597          	auipc	a1,0x3
    800040b0:	4fc58593          	addi	a1,a1,1276 # 800075a8 <etext+0x5a8>
    800040b4:	0521                	addi	a0,a0,8
    800040b6:	adbfc0ef          	jal	80000b90 <initlock>
  lk->name = name;
    800040ba:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    800040be:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    800040c2:	0204a423          	sw	zero,40(s1)
}
    800040c6:	60e2                	ld	ra,24(sp)
    800040c8:	6442                	ld	s0,16(sp)
    800040ca:	64a2                	ld	s1,8(sp)
    800040cc:	6902                	ld	s2,0(sp)
    800040ce:	6105                	addi	sp,sp,32
    800040d0:	8082                	ret

00000000800040d2 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    800040d2:	1101                	addi	sp,sp,-32
    800040d4:	ec06                	sd	ra,24(sp)
    800040d6:	e822                	sd	s0,16(sp)
    800040d8:	e426                	sd	s1,8(sp)
    800040da:	e04a                	sd	s2,0(sp)
    800040dc:	1000                	addi	s0,sp,32
    800040de:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800040e0:	00850913          	addi	s2,a0,8
    800040e4:	854a                	mv	a0,s2
    800040e6:	b2bfc0ef          	jal	80000c10 <acquire>
  while (lk->locked) {
    800040ea:	409c                	lw	a5,0(s1)
    800040ec:	c385                	beqz	a5,8000410c <acquiresleep+0x3a>
    sleep_prepare(lk);
    800040ee:	8526                	mv	a0,s1
    800040f0:	eb5fd0ef          	jal	80001fa4 <sleep_prepare>
    release(&lk->lk);
    800040f4:	854a                	mv	a0,s2
    800040f6:	badfc0ef          	jal	80000ca2 <release>
    sleep(lk, &lk->lk);
    800040fa:	85ca                	mv	a1,s2
    800040fc:	8526                	mv	a0,s1
    800040fe:	ee3fd0ef          	jal	80001fe0 <sleep>
    acquire(&lk->lk);
    80004102:	854a                	mv	a0,s2
    80004104:	b0dfc0ef          	jal	80000c10 <acquire>
  while (lk->locked) {
    80004108:	409c                	lw	a5,0(s1)
    8000410a:	f3f5                	bnez	a5,800040ee <acquiresleep+0x1c>
  }
  lk->locked = 1;
    8000410c:	4785                	li	a5,1
    8000410e:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    80004110:	807fd0ef          	jal	80001916 <myproc>
    80004114:	591c                	lw	a5,48(a0)
    80004116:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    80004118:	854a                	mv	a0,s2
    8000411a:	b89fc0ef          	jal	80000ca2 <release>
}
    8000411e:	60e2                	ld	ra,24(sp)
    80004120:	6442                	ld	s0,16(sp)
    80004122:	64a2                	ld	s1,8(sp)
    80004124:	6902                	ld	s2,0(sp)
    80004126:	6105                	addi	sp,sp,32
    80004128:	8082                	ret

000000008000412a <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    8000412a:	1101                	addi	sp,sp,-32
    8000412c:	ec06                	sd	ra,24(sp)
    8000412e:	e822                	sd	s0,16(sp)
    80004130:	e426                	sd	s1,8(sp)
    80004132:	e04a                	sd	s2,0(sp)
    80004134:	1000                	addi	s0,sp,32
    80004136:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80004138:	00850913          	addi	s2,a0,8
    8000413c:	854a                	mv	a0,s2
    8000413e:	ad3fc0ef          	jal	80000c10 <acquire>
  lk->locked = 0;
    80004142:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80004146:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    8000414a:	8526                	mv	a0,s1
    8000414c:	ee1fd0ef          	jal	8000202c <wakeup>
  release(&lk->lk);
    80004150:	854a                	mv	a0,s2
    80004152:	b51fc0ef          	jal	80000ca2 <release>
}
    80004156:	60e2                	ld	ra,24(sp)
    80004158:	6442                	ld	s0,16(sp)
    8000415a:	64a2                	ld	s1,8(sp)
    8000415c:	6902                	ld	s2,0(sp)
    8000415e:	6105                	addi	sp,sp,32
    80004160:	8082                	ret

0000000080004162 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    80004162:	7179                	addi	sp,sp,-48
    80004164:	f406                	sd	ra,40(sp)
    80004166:	f022                	sd	s0,32(sp)
    80004168:	ec26                	sd	s1,24(sp)
    8000416a:	e84a                	sd	s2,16(sp)
    8000416c:	1800                	addi	s0,sp,48
    8000416e:	84aa                	mv	s1,a0
  int r;

  acquire(&lk->lk);
    80004170:	00850913          	addi	s2,a0,8
    80004174:	854a                	mv	a0,s2
    80004176:	a9bfc0ef          	jal	80000c10 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    8000417a:	409c                	lw	a5,0(s1)
    8000417c:	ef81                	bnez	a5,80004194 <holdingsleep+0x32>
    8000417e:	4481                	li	s1,0
  release(&lk->lk);
    80004180:	854a                	mv	a0,s2
    80004182:	b21fc0ef          	jal	80000ca2 <release>
  return r;
}
    80004186:	8526                	mv	a0,s1
    80004188:	70a2                	ld	ra,40(sp)
    8000418a:	7402                	ld	s0,32(sp)
    8000418c:	64e2                	ld	s1,24(sp)
    8000418e:	6942                	ld	s2,16(sp)
    80004190:	6145                	addi	sp,sp,48
    80004192:	8082                	ret
    80004194:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    80004196:	0284a983          	lw	s3,40(s1)
    8000419a:	f7cfd0ef          	jal	80001916 <myproc>
    8000419e:	5904                	lw	s1,48(a0)
    800041a0:	413484b3          	sub	s1,s1,s3
    800041a4:	0014b493          	seqz	s1,s1
    800041a8:	69a2                	ld	s3,8(sp)
    800041aa:	bfd9                	j	80004180 <holdingsleep+0x1e>

00000000800041ac <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    800041ac:	1141                	addi	sp,sp,-16
    800041ae:	e406                	sd	ra,8(sp)
    800041b0:	e022                	sd	s0,0(sp)
    800041b2:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    800041b4:	00003597          	auipc	a1,0x3
    800041b8:	40458593          	addi	a1,a1,1028 # 800075b8 <etext+0x5b8>
    800041bc:	0001c517          	auipc	a0,0x1c
    800041c0:	b3450513          	addi	a0,a0,-1228 # 8001fcf0 <ftable>
    800041c4:	9cdfc0ef          	jal	80000b90 <initlock>
}
    800041c8:	60a2                	ld	ra,8(sp)
    800041ca:	6402                	ld	s0,0(sp)
    800041cc:	0141                	addi	sp,sp,16
    800041ce:	8082                	ret

00000000800041d0 <filealloc>:

// Allocate a file structure.
struct file *
filealloc(void)
{
    800041d0:	1101                	addi	sp,sp,-32
    800041d2:	ec06                	sd	ra,24(sp)
    800041d4:	e822                	sd	s0,16(sp)
    800041d6:	e426                	sd	s1,8(sp)
    800041d8:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    800041da:	0001c517          	auipc	a0,0x1c
    800041de:	b1650513          	addi	a0,a0,-1258 # 8001fcf0 <ftable>
    800041e2:	a2ffc0ef          	jal	80000c10 <acquire>
  for (f = ftable.file; f < ftable.file + NFILE; f++) {
    800041e6:	0001c497          	auipc	s1,0x1c
    800041ea:	b2248493          	addi	s1,s1,-1246 # 8001fd08 <ftable+0x18>
    800041ee:	0001d717          	auipc	a4,0x1d
    800041f2:	aba70713          	addi	a4,a4,-1350 # 80020ca8 <disk>
    if (f->ref == 0) {
    800041f6:	40dc                	lw	a5,4(s1)
    800041f8:	cf89                	beqz	a5,80004212 <filealloc+0x42>
  for (f = ftable.file; f < ftable.file + NFILE; f++) {
    800041fa:	02848493          	addi	s1,s1,40
    800041fe:	fee49ce3          	bne	s1,a4,800041f6 <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    80004202:	0001c517          	auipc	a0,0x1c
    80004206:	aee50513          	addi	a0,a0,-1298 # 8001fcf0 <ftable>
    8000420a:	a99fc0ef          	jal	80000ca2 <release>
  return 0;
    8000420e:	4481                	li	s1,0
    80004210:	a809                	j	80004222 <filealloc+0x52>
      f->ref = 1;
    80004212:	4785                	li	a5,1
    80004214:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    80004216:	0001c517          	auipc	a0,0x1c
    8000421a:	ada50513          	addi	a0,a0,-1318 # 8001fcf0 <ftable>
    8000421e:	a85fc0ef          	jal	80000ca2 <release>
}
    80004222:	8526                	mv	a0,s1
    80004224:	60e2                	ld	ra,24(sp)
    80004226:	6442                	ld	s0,16(sp)
    80004228:	64a2                	ld	s1,8(sp)
    8000422a:	6105                	addi	sp,sp,32
    8000422c:	8082                	ret

000000008000422e <filedup>:

// Increment ref count for file f.
struct file *
filedup(struct file *f)
{
    8000422e:	1101                	addi	sp,sp,-32
    80004230:	ec06                	sd	ra,24(sp)
    80004232:	e822                	sd	s0,16(sp)
    80004234:	e426                	sd	s1,8(sp)
    80004236:	1000                	addi	s0,sp,32
    80004238:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    8000423a:	0001c517          	auipc	a0,0x1c
    8000423e:	ab650513          	addi	a0,a0,-1354 # 8001fcf0 <ftable>
    80004242:	9cffc0ef          	jal	80000c10 <acquire>
  if (f->ref < 1)
    80004246:	40dc                	lw	a5,4(s1)
    80004248:	02f05063          	blez	a5,80004268 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    8000424c:	2785                	addiw	a5,a5,1
    8000424e:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    80004250:	0001c517          	auipc	a0,0x1c
    80004254:	aa050513          	addi	a0,a0,-1376 # 8001fcf0 <ftable>
    80004258:	a4bfc0ef          	jal	80000ca2 <release>
  return f;
}
    8000425c:	8526                	mv	a0,s1
    8000425e:	60e2                	ld	ra,24(sp)
    80004260:	6442                	ld	s0,16(sp)
    80004262:	64a2                	ld	s1,8(sp)
    80004264:	6105                	addi	sp,sp,32
    80004266:	8082                	ret
    panic("filedup");
    80004268:	00003517          	auipc	a0,0x3
    8000426c:	35850513          	addi	a0,a0,856 # 800075c0 <etext+0x5c0>
    80004270:	dc2fc0ef          	jal	80000832 <panic>

0000000080004274 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    80004274:	7139                	addi	sp,sp,-64
    80004276:	fc06                	sd	ra,56(sp)
    80004278:	f822                	sd	s0,48(sp)
    8000427a:	f426                	sd	s1,40(sp)
    8000427c:	0080                	addi	s0,sp,64
    8000427e:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    80004280:	0001c517          	auipc	a0,0x1c
    80004284:	a7050513          	addi	a0,a0,-1424 # 8001fcf0 <ftable>
    80004288:	989fc0ef          	jal	80000c10 <acquire>
  if (f->ref < 1)
    8000428c:	40dc                	lw	a5,4(s1)
    8000428e:	04f05a63          	blez	a5,800042e2 <fileclose+0x6e>
    panic("fileclose");
  if (--f->ref > 0) {
    80004292:	37fd                	addiw	a5,a5,-1
    80004294:	c0dc                	sw	a5,4(s1)
    80004296:	06f04063          	bgtz	a5,800042f6 <fileclose+0x82>
    8000429a:	f04a                	sd	s2,32(sp)
    8000429c:	ec4e                	sd	s3,24(sp)
    8000429e:	e852                	sd	s4,16(sp)
    800042a0:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    800042a2:	0004a903          	lw	s2,0(s1)
    800042a6:	0094c783          	lbu	a5,9(s1)
    800042aa:	89be                	mv	s3,a5
    800042ac:	689c                	ld	a5,16(s1)
    800042ae:	8a3e                	mv	s4,a5
    800042b0:	6c9c                	ld	a5,24(s1)
    800042b2:	8abe                	mv	s5,a5
  f->ref = 0;
    800042b4:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    800042b8:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    800042bc:	0001c517          	auipc	a0,0x1c
    800042c0:	a3450513          	addi	a0,a0,-1484 # 8001fcf0 <ftable>
    800042c4:	9dffc0ef          	jal	80000ca2 <release>

  if (ff.type == FD_PIPE) {
    800042c8:	4785                	li	a5,1
    800042ca:	04f90163          	beq	s2,a5,8000430c <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if (ff.type == FD_INODE || ff.type == FD_DEVICE) {
    800042ce:	ffe9079b          	addiw	a5,s2,-2
    800042d2:	4705                	li	a4,1
    800042d4:	04f77563          	bgeu	a4,a5,8000431e <fileclose+0xaa>
    800042d8:	7902                	ld	s2,32(sp)
    800042da:	69e2                	ld	s3,24(sp)
    800042dc:	6a42                	ld	s4,16(sp)
    800042de:	6aa2                	ld	s5,8(sp)
    800042e0:	a00d                	j	80004302 <fileclose+0x8e>
    800042e2:	f04a                	sd	s2,32(sp)
    800042e4:	ec4e                	sd	s3,24(sp)
    800042e6:	e852                	sd	s4,16(sp)
    800042e8:	e456                	sd	s5,8(sp)
    panic("fileclose");
    800042ea:	00003517          	auipc	a0,0x3
    800042ee:	2de50513          	addi	a0,a0,734 # 800075c8 <etext+0x5c8>
    800042f2:	d40fc0ef          	jal	80000832 <panic>
    release(&ftable.lock);
    800042f6:	0001c517          	auipc	a0,0x1c
    800042fa:	9fa50513          	addi	a0,a0,-1542 # 8001fcf0 <ftable>
    800042fe:	9a5fc0ef          	jal	80000ca2 <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    80004302:	70e2                	ld	ra,56(sp)
    80004304:	7442                	ld	s0,48(sp)
    80004306:	74a2                	ld	s1,40(sp)
    80004308:	6121                	addi	sp,sp,64
    8000430a:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    8000430c:	85ce                	mv	a1,s3
    8000430e:	8552                	mv	a0,s4
    80004310:	348000ef          	jal	80004658 <pipeclose>
    80004314:	7902                	ld	s2,32(sp)
    80004316:	69e2                	ld	s3,24(sp)
    80004318:	6a42                	ld	s4,16(sp)
    8000431a:	6aa2                	ld	s5,8(sp)
    8000431c:	b7dd                	j	80004302 <fileclose+0x8e>
    begin_op();
    8000431e:	a91ff0ef          	jal	80003dae <begin_op>
    iput(ff.ip);
    80004322:	8556                	mv	a0,s5
    80004324:	98aff0ef          	jal	800034ae <iput>
    end_op();
    80004328:	b1bff0ef          	jal	80003e42 <end_op>
    8000432c:	7902                	ld	s2,32(sp)
    8000432e:	69e2                	ld	s3,24(sp)
    80004330:	6a42                	ld	s4,16(sp)
    80004332:	6aa2                	ld	s5,8(sp)
    80004334:	b7f9                	j	80004302 <fileclose+0x8e>

0000000080004336 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    80004336:	715d                	addi	sp,sp,-80
    80004338:	e486                	sd	ra,72(sp)
    8000433a:	e0a2                	sd	s0,64(sp)
    8000433c:	fc26                	sd	s1,56(sp)
    8000433e:	f052                	sd	s4,32(sp)
    80004340:	0880                	addi	s0,sp,80
    80004342:	84aa                	mv	s1,a0
    80004344:	8a2e                	mv	s4,a1
  struct proc *p = myproc();
    80004346:	dd0fd0ef          	jal	80001916 <myproc>
  struct stat st;

  if (f->type == FD_INODE || f->type == FD_DEVICE) {
    8000434a:	409c                	lw	a5,0(s1)
    8000434c:	37f9                	addiw	a5,a5,-2
    8000434e:	4705                	li	a4,1
    80004350:	04f76463          	bltu	a4,a5,80004398 <filestat+0x62>
    80004354:	f84a                	sd	s2,48(sp)
    80004356:	f44e                	sd	s3,40(sp)
    80004358:	892a                	mv	s2,a0
    ilock(f->ip);
    8000435a:	6c88                	ld	a0,24(s1)
    8000435c:	fd1fe0ef          	jal	8000332c <ilock>
    stati(f->ip, &st);
    80004360:	fb840993          	addi	s3,s0,-72
    80004364:	85ce                	mv	a1,s3
    80004366:	6c88                	ld	a0,24(s1)
    80004368:	b70ff0ef          	jal	800036d8 <stati>
    iunlock(f->ip);
    8000436c:	6c88                	ld	a0,24(s1)
    8000436e:	86cff0ef          	jal	800033da <iunlock>
    if (copyout(p->pagetable, p->sz, addr, (char *)&st, sizeof(st)) < 0)
    80004372:	4761                	li	a4,24
    80004374:	86ce                	mv	a3,s3
    80004376:	8652                	mv	a2,s4
    80004378:	04893583          	ld	a1,72(s2)
    8000437c:	05093503          	ld	a0,80(s2)
    80004380:	9e0fd0ef          	jal	80001560 <copyout>
    80004384:	41f5551b          	sraiw	a0,a0,0x1f
    80004388:	7942                	ld	s2,48(sp)
    8000438a:	79a2                	ld	s3,40(sp)
      return -1;
    return 0;
  }
  return -1;
}
    8000438c:	60a6                	ld	ra,72(sp)
    8000438e:	6406                	ld	s0,64(sp)
    80004390:	74e2                	ld	s1,56(sp)
    80004392:	7a02                	ld	s4,32(sp)
    80004394:	6161                	addi	sp,sp,80
    80004396:	8082                	ret
  return -1;
    80004398:	557d                	li	a0,-1
    8000439a:	bfcd                	j	8000438c <filestat+0x56>

000000008000439c <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    8000439c:	7179                	addi	sp,sp,-48
    8000439e:	f406                	sd	ra,40(sp)
    800043a0:	f022                	sd	s0,32(sp)
    800043a2:	e84a                	sd	s2,16(sp)
    800043a4:	1800                	addi	s0,sp,48
  int r = 0;

  if (f->readable == 0 || n < 0)
    800043a6:	00854783          	lbu	a5,8(a0)
    800043aa:	0017b793          	seqz	a5,a5
    800043ae:	01f6571b          	srliw	a4,a2,0x1f
    800043b2:	8fd9                	or	a5,a5,a4
    800043b4:	e3c5                	bnez	a5,80004454 <fileread+0xb8>
    800043b6:	ec26                	sd	s1,24(sp)
    800043b8:	e44e                	sd	s3,8(sp)
    800043ba:	84aa                	mv	s1,a0
    800043bc:	892e                	mv	s2,a1
    800043be:	89b2                	mv	s3,a2
    return -1;

  if (f->type == FD_PIPE) {
    800043c0:	411c                	lw	a5,0(a0)
    800043c2:	4705                	li	a4,1
    800043c4:	04e78363          	beq	a5,a4,8000440a <fileread+0x6e>
    r = piperead(f->pipe, addr, n);
  } else if (f->type == FD_DEVICE) {
    800043c8:	470d                	li	a4,3
    800043ca:	04e78763          	beq	a5,a4,80004418 <fileread+0x7c>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if (f->type == FD_INODE) {
    800043ce:	4709                	li	a4,2
    800043d0:	06e79a63          	bne	a5,a4,80004444 <fileread+0xa8>
    ilock(f->ip);
    800043d4:	6d08                	ld	a0,24(a0)
    800043d6:	f57fe0ef          	jal	8000332c <ilock>
    if ((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    800043da:	874e                	mv	a4,s3
    800043dc:	5094                	lw	a3,32(s1)
    800043de:	864a                	mv	a2,s2
    800043e0:	4585                	li	a1,1
    800043e2:	6c88                	ld	a0,24(s1)
    800043e4:	b22ff0ef          	jal	80003706 <readi>
    800043e8:	892a                	mv	s2,a0
    800043ea:	00a05563          	blez	a0,800043f4 <fileread+0x58>
      f->off += r;
    800043ee:	509c                	lw	a5,32(s1)
    800043f0:	9fa9                	addw	a5,a5,a0
    800043f2:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    800043f4:	6c88                	ld	a0,24(s1)
    800043f6:	fe5fe0ef          	jal	800033da <iunlock>
    800043fa:	64e2                	ld	s1,24(sp)
    800043fc:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    800043fe:	854a                	mv	a0,s2
    80004400:	70a2                	ld	ra,40(sp)
    80004402:	7402                	ld	s0,32(sp)
    80004404:	6942                	ld	s2,16(sp)
    80004406:	6145                	addi	sp,sp,48
    80004408:	8082                	ret
    r = piperead(f->pipe, addr, n);
    8000440a:	6908                	ld	a0,16(a0)
    8000440c:	3ca000ef          	jal	800047d6 <piperead>
    80004410:	892a                	mv	s2,a0
    80004412:	64e2                	ld	s1,24(sp)
    80004414:	69a2                	ld	s3,8(sp)
    80004416:	b7e5                	j	800043fe <fileread+0x62>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    80004418:	02451783          	lh	a5,36(a0)
    8000441c:	03079693          	slli	a3,a5,0x30
    80004420:	92c1                	srli	a3,a3,0x30
    80004422:	4725                	li	a4,9
    80004424:	02d76663          	bltu	a4,a3,80004450 <fileread+0xb4>
    80004428:	0792                	slli	a5,a5,0x4
    8000442a:	0001c717          	auipc	a4,0x1c
    8000442e:	82670713          	addi	a4,a4,-2010 # 8001fc50 <devsw>
    80004432:	97ba                	add	a5,a5,a4
    80004434:	639c                	ld	a5,0(a5)
    80004436:	c395                	beqz	a5,8000445a <fileread+0xbe>
    r = devsw[f->major].read(1, addr, n);
    80004438:	4505                	li	a0,1
    8000443a:	9782                	jalr	a5
    8000443c:	892a                	mv	s2,a0
    8000443e:	64e2                	ld	s1,24(sp)
    80004440:	69a2                	ld	s3,8(sp)
    80004442:	bf75                	j	800043fe <fileread+0x62>
    panic("fileread");
    80004444:	00003517          	auipc	a0,0x3
    80004448:	19450513          	addi	a0,a0,404 # 800075d8 <etext+0x5d8>
    8000444c:	be6fc0ef          	jal	80000832 <panic>
    80004450:	64e2                	ld	s1,24(sp)
    80004452:	69a2                	ld	s3,8(sp)
    return -1;
    80004454:	57fd                	li	a5,-1
    80004456:	893e                	mv	s2,a5
    80004458:	b75d                	j	800043fe <fileread+0x62>
    8000445a:	64e2                	ld	s1,24(sp)
    8000445c:	69a2                	ld	s3,8(sp)
    8000445e:	bfdd                	j	80004454 <fileread+0xb8>

0000000080004460 <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if (f->writable == 0 || n < 0)
    80004460:	00954783          	lbu	a5,9(a0)
    80004464:	0017b793          	seqz	a5,a5
    80004468:	01f6571b          	srliw	a4,a2,0x1f
    8000446c:	8fd9                	or	a5,a5,a4
    8000446e:	12079363          	bnez	a5,80004594 <filewrite+0x134>
{
    80004472:	711d                	addi	sp,sp,-96
    80004474:	ec86                	sd	ra,88(sp)
    80004476:	e8a2                	sd	s0,80(sp)
    80004478:	e0ca                	sd	s2,64(sp)
    8000447a:	f456                	sd	s5,40(sp)
    8000447c:	f05a                	sd	s6,32(sp)
    8000447e:	1080                	addi	s0,sp,96
    80004480:	892a                	mv	s2,a0
    80004482:	8b2e                	mv	s6,a1
    80004484:	8ab2                	mv	s5,a2
    return -1;

  if (f->type == FD_PIPE) {
    80004486:	411c                	lw	a5,0(a0)
    80004488:	4705                	li	a4,1
    8000448a:	02e78a63          	beq	a5,a4,800044be <filewrite+0x5e>
    ret = pipewrite(f->pipe, addr, n);
  } else if (f->type == FD_DEVICE) {
    8000448e:	470d                	li	a4,3
    80004490:	02e78b63          	beq	a5,a4,800044c6 <filewrite+0x66>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if (f->type == FD_INODE) {
    80004494:	4709                	li	a4,2
    80004496:	0ce79763          	bne	a5,a4,80004564 <filewrite+0x104>
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS - 1 - 1 - 2) / 2) * BSIZE;
    int i = 0;
    while (i < n) {
    8000449a:	0ec05363          	blez	a2,80004580 <filewrite+0x120>
    8000449e:	e4a6                	sd	s1,72(sp)
    800044a0:	fc4e                	sd	s3,56(sp)
    800044a2:	f852                	sd	s4,48(sp)
    800044a4:	ec5e                	sd	s7,24(sp)
    800044a6:	e862                	sd	s8,16(sp)
    800044a8:	e466                	sd	s9,8(sp)
    int i = 0;
    800044aa:	4a01                	li	s4,0
      int n1 = n - i;
      if (n1 > max)
    800044ac:	6b85                	lui	s7,0x1
    800044ae:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    800044b2:	6785                	lui	a5,0x1
    800044b4:	c007879b          	addiw	a5,a5,-1024 # c00 <_entry-0x7ffff400>
    800044b8:	8cbe                	mv	s9,a5
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    800044ba:	4c05                	li	s8,1
    800044bc:	a8ad                	j	80004536 <filewrite+0xd6>
    ret = pipewrite(f->pipe, addr, n);
    800044be:	6908                	ld	a0,16(a0)
    800044c0:	1f6000ef          	jal	800046b6 <pipewrite>
    800044c4:	a849                	j	80004556 <filewrite+0xf6>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    800044c6:	02451783          	lh	a5,36(a0)
    800044ca:	03079693          	slli	a3,a5,0x30
    800044ce:	92c1                	srli	a3,a3,0x30
    800044d0:	4725                	li	a4,9
    800044d2:	0ad76563          	bltu	a4,a3,8000457c <filewrite+0x11c>
    800044d6:	0792                	slli	a5,a5,0x4
    800044d8:	0001b717          	auipc	a4,0x1b
    800044dc:	77870713          	addi	a4,a4,1912 # 8001fc50 <devsw>
    800044e0:	97ba                	add	a5,a5,a4
    800044e2:	679c                	ld	a5,8(a5)
    800044e4:	cfc1                	beqz	a5,8000457c <filewrite+0x11c>
    ret = devsw[f->major].write(1, addr, n);
    800044e6:	4505                	li	a0,1
    800044e8:	9782                	jalr	a5
    800044ea:	a0b5                	j	80004556 <filewrite+0xf6>
      if (n1 > max)
    800044ec:	2981                	sext.w	s3,s3
      begin_op();
    800044ee:	8c1ff0ef          	jal	80003dae <begin_op>
      ilock(f->ip);
    800044f2:	01893503          	ld	a0,24(s2)
    800044f6:	e37fe0ef          	jal	8000332c <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    800044fa:	874e                	mv	a4,s3
    800044fc:	02092683          	lw	a3,32(s2)
    80004500:	016a0633          	add	a2,s4,s6
    80004504:	85e2                	mv	a1,s8
    80004506:	01893503          	ld	a0,24(s2)
    8000450a:	aeeff0ef          	jal	800037f8 <writei>
    8000450e:	84aa                	mv	s1,a0
    80004510:	00a05763          	blez	a0,8000451e <filewrite+0xbe>
        f->off += r;
    80004514:	02092783          	lw	a5,32(s2)
    80004518:	9fa9                	addw	a5,a5,a0
    8000451a:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    8000451e:	01893503          	ld	a0,24(s2)
    80004522:	eb9fe0ef          	jal	800033da <iunlock>
      end_op();
    80004526:	91dff0ef          	jal	80003e42 <end_op>

      if (r != n1) {
    8000452a:	00999d63          	bne	s3,s1,80004544 <filewrite+0xe4>
        // error from writei
        break;
      }
      i += r;
    8000452e:	01448a3b          	addw	s4,s1,s4
    while (i < n) {
    80004532:	015a5963          	bge	s4,s5,80004544 <filewrite+0xe4>
      int n1 = n - i;
    80004536:	414a87bb          	subw	a5,s5,s4
    8000453a:	89be                	mv	s3,a5
      if (n1 > max)
    8000453c:	fafbd8e3          	bge	s7,a5,800044ec <filewrite+0x8c>
    80004540:	89e6                	mv	s3,s9
    80004542:	b76d                	j	800044ec <filewrite+0x8c>
    }
    ret = (i == n ? n : -1);
    80004544:	054a9063          	bne	s5,s4,80004584 <filewrite+0x124>
    80004548:	8556                	mv	a0,s5
    8000454a:	64a6                	ld	s1,72(sp)
    8000454c:	79e2                	ld	s3,56(sp)
    8000454e:	7a42                	ld	s4,48(sp)
    80004550:	6be2                	ld	s7,24(sp)
    80004552:	6c42                	ld	s8,16(sp)
    80004554:	6ca2                	ld	s9,8(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    80004556:	60e6                	ld	ra,88(sp)
    80004558:	6446                	ld	s0,80(sp)
    8000455a:	6906                	ld	s2,64(sp)
    8000455c:	7aa2                	ld	s5,40(sp)
    8000455e:	7b02                	ld	s6,32(sp)
    80004560:	6125                	addi	sp,sp,96
    80004562:	8082                	ret
    80004564:	e4a6                	sd	s1,72(sp)
    80004566:	fc4e                	sd	s3,56(sp)
    80004568:	f852                	sd	s4,48(sp)
    8000456a:	ec5e                	sd	s7,24(sp)
    8000456c:	e862                	sd	s8,16(sp)
    8000456e:	e466                	sd	s9,8(sp)
    panic("filewrite");
    80004570:	00003517          	auipc	a0,0x3
    80004574:	07850513          	addi	a0,a0,120 # 800075e8 <etext+0x5e8>
    80004578:	abafc0ef          	jal	80000832 <panic>
    return -1;
    8000457c:	557d                	li	a0,-1
    8000457e:	bfe1                	j	80004556 <filewrite+0xf6>
    ret = (i == n ? n : -1);
    80004580:	8532                	mv	a0,a2
    80004582:	bfd1                	j	80004556 <filewrite+0xf6>
    80004584:	557d                	li	a0,-1
    80004586:	64a6                	ld	s1,72(sp)
    80004588:	79e2                	ld	s3,56(sp)
    8000458a:	7a42                	ld	s4,48(sp)
    8000458c:	6be2                	ld	s7,24(sp)
    8000458e:	6c42                	ld	s8,16(sp)
    80004590:	6ca2                	ld	s9,8(sp)
    80004592:	b7d1                	j	80004556 <filewrite+0xf6>
    return -1;
    80004594:	557d                	li	a0,-1
}
    80004596:	8082                	ret

0000000080004598 <pipealloc>:
  int writeopen; // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    80004598:	7179                	addi	sp,sp,-48
    8000459a:	f406                	sd	ra,40(sp)
    8000459c:	f022                	sd	s0,32(sp)
    8000459e:	ec26                	sd	s1,24(sp)
    800045a0:	e052                	sd	s4,0(sp)
    800045a2:	1800                	addi	s0,sp,48
    800045a4:	84aa                	mv	s1,a0
    800045a6:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    800045a8:	0005b023          	sd	zero,0(a1)
    800045ac:	00053023          	sd	zero,0(a0)
  if ((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    800045b0:	c21ff0ef          	jal	800041d0 <filealloc>
    800045b4:	e088                	sd	a0,0(s1)
    800045b6:	c549                	beqz	a0,80004640 <pipealloc+0xa8>
    800045b8:	c19ff0ef          	jal	800041d0 <filealloc>
    800045bc:	00aa3023          	sd	a0,0(s4)
    800045c0:	cd25                	beqz	a0,80004638 <pipealloc+0xa0>
    800045c2:	e84a                	sd	s2,16(sp)
    goto bad;
  if ((pi = (struct pipe *)kalloc()) == 0)
    800045c4:	d72fc0ef          	jal	80000b36 <kalloc>
    800045c8:	892a                	mv	s2,a0
    800045ca:	c12d                	beqz	a0,8000462c <pipealloc+0x94>
    800045cc:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    800045ce:	4985                	li	s3,1
    800045d0:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    800045d4:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    800045d8:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    800045dc:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    800045e0:	00003597          	auipc	a1,0x3
    800045e4:	01858593          	addi	a1,a1,24 # 800075f8 <etext+0x5f8>
    800045e8:	da8fc0ef          	jal	80000b90 <initlock>
  (*f0)->type = FD_PIPE;
    800045ec:	609c                	ld	a5,0(s1)
    800045ee:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    800045f2:	609c                	ld	a5,0(s1)
    800045f4:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    800045f8:	609c                	ld	a5,0(s1)
    800045fa:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    800045fe:	609c                	ld	a5,0(s1)
    80004600:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    80004604:	000a3783          	ld	a5,0(s4)
    80004608:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    8000460c:	000a3783          	ld	a5,0(s4)
    80004610:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80004614:	000a3783          	ld	a5,0(s4)
    80004618:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    8000461c:	000a3783          	ld	a5,0(s4)
    80004620:	0127b823          	sd	s2,16(a5)
  return 0;
    80004624:	4501                	li	a0,0
    80004626:	6942                	ld	s2,16(sp)
    80004628:	69a2                	ld	s3,8(sp)
    8000462a:	a00d                	j	8000464c <pipealloc+0xb4>

bad:
  if (pi)
    kfree((char *)pi);
  if (*f0)
    8000462c:	6088                	ld	a0,0(s1)
    8000462e:	c119                	beqz	a0,80004634 <pipealloc+0x9c>
    80004630:	6942                	ld	s2,16(sp)
    80004632:	a029                	j	8000463c <pipealloc+0xa4>
    80004634:	6942                	ld	s2,16(sp)
    80004636:	a029                	j	80004640 <pipealloc+0xa8>
    80004638:	6088                	ld	a0,0(s1)
    8000463a:	c901                	beqz	a0,8000464a <pipealloc+0xb2>
    fileclose(*f0);
    8000463c:	c39ff0ef          	jal	80004274 <fileclose>
  if (*f1)
    80004640:	000a3503          	ld	a0,0(s4)
    80004644:	c119                	beqz	a0,8000464a <pipealloc+0xb2>
    fileclose(*f1);
    80004646:	c2fff0ef          	jal	80004274 <fileclose>
  return -1;
    8000464a:	557d                	li	a0,-1
}
    8000464c:	70a2                	ld	ra,40(sp)
    8000464e:	7402                	ld	s0,32(sp)
    80004650:	64e2                	ld	s1,24(sp)
    80004652:	6a02                	ld	s4,0(sp)
    80004654:	6145                	addi	sp,sp,48
    80004656:	8082                	ret

0000000080004658 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80004658:	1101                	addi	sp,sp,-32
    8000465a:	ec06                	sd	ra,24(sp)
    8000465c:	e822                	sd	s0,16(sp)
    8000465e:	e426                	sd	s1,8(sp)
    80004660:	e04a                	sd	s2,0(sp)
    80004662:	1000                	addi	s0,sp,32
    80004664:	84aa                	mv	s1,a0
    80004666:	892e                	mv	s2,a1
  acquire(&pi->lock);
    80004668:	da8fc0ef          	jal	80000c10 <acquire>
  if (writable) {
    8000466c:	02090763          	beqz	s2,8000469a <pipeclose+0x42>
    pi->writeopen = 0;
    80004670:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    80004674:	21848513          	addi	a0,s1,536
    80004678:	9b5fd0ef          	jal	8000202c <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if (pi->readopen == 0 && pi->writeopen == 0) {
    8000467c:	2204a783          	lw	a5,544(s1)
    80004680:	e781                	bnez	a5,80004688 <pipeclose+0x30>
    80004682:	2244a783          	lw	a5,548(s1)
    80004686:	c38d                	beqz	a5,800046a8 <pipeclose+0x50>
    release(&pi->lock);
    kfree((char *)pi);
  } else
    release(&pi->lock);
    80004688:	8526                	mv	a0,s1
    8000468a:	e18fc0ef          	jal	80000ca2 <release>
}
    8000468e:	60e2                	ld	ra,24(sp)
    80004690:	6442                	ld	s0,16(sp)
    80004692:	64a2                	ld	s1,8(sp)
    80004694:	6902                	ld	s2,0(sp)
    80004696:	6105                	addi	sp,sp,32
    80004698:	8082                	ret
    pi->readopen = 0;
    8000469a:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    8000469e:	21c48513          	addi	a0,s1,540
    800046a2:	98bfd0ef          	jal	8000202c <wakeup>
    800046a6:	bfd9                	j	8000467c <pipeclose+0x24>
    release(&pi->lock);
    800046a8:	8526                	mv	a0,s1
    800046aa:	df8fc0ef          	jal	80000ca2 <release>
    kfree((char *)pi);
    800046ae:	8526                	mv	a0,s1
    800046b0:	b9efc0ef          	jal	80000a4e <kfree>
    800046b4:	bfe9                	j	8000468e <pipeclose+0x36>

00000000800046b6 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    800046b6:	7159                	addi	sp,sp,-112
    800046b8:	f486                	sd	ra,104(sp)
    800046ba:	f0a2                	sd	s0,96(sp)
    800046bc:	eca6                	sd	s1,88(sp)
    800046be:	e8ca                	sd	s2,80(sp)
    800046c0:	e4ce                	sd	s3,72(sp)
    800046c2:	e0d2                	sd	s4,64(sp)
    800046c4:	fc56                	sd	s5,56(sp)
    800046c6:	1880                	addi	s0,sp,112
    800046c8:	84aa                	mv	s1,a0
    800046ca:	8aae                	mv	s5,a1
    800046cc:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    800046ce:	a48fd0ef          	jal	80001916 <myproc>
    800046d2:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    800046d4:	8526                	mv	a0,s1
    800046d6:	d3afc0ef          	jal	80000c10 <acquire>
  while (i < n) {
    800046da:	0f405c63          	blez	s4,800047d2 <pipewrite+0x11c>
    800046de:	f85a                	sd	s6,48(sp)
    800046e0:	f45e                	sd	s7,40(sp)
    800046e2:	f062                	sd	s8,32(sp)
    800046e4:	ec66                	sd	s9,24(sp)
    800046e6:	e86a                	sd	s10,16(sp)
  int i = 0;
    800046e8:	4901                	li	s2,0
      release(&pi->lock);
      sleep(&pi->nwrite, &pi->lock);
      acquire(&pi->lock);
    } else {
      char ch;
      if (copyin(pr->pagetable, pr->sz, &ch, addr + i, 1) == -1) {
    800046ea:	f9f40c93          	addi	s9,s0,-97
    800046ee:	4c05                	li	s8,1
    800046f0:	5bfd                	li	s7,-1
      wakeup(&pi->nread);
    800046f2:	21848d13          	addi	s10,s1,536
      sleep_prepare(&pi->nwrite);
    800046f6:	21c48b13          	addi	s6,s1,540
    800046fa:	a0b1                	j	80004746 <pipewrite+0x90>
      release(&pi->lock);
    800046fc:	8526                	mv	a0,s1
    800046fe:	da4fc0ef          	jal	80000ca2 <release>
      return -1;
    80004702:	597d                	li	s2,-1
    80004704:	7b42                	ld	s6,48(sp)
    80004706:	7ba2                	ld	s7,40(sp)
    80004708:	7c02                	ld	s8,32(sp)
    8000470a:	6ce2                	ld	s9,24(sp)
    8000470c:	6d42                	ld	s10,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    8000470e:	854a                	mv	a0,s2
    80004710:	70a6                	ld	ra,104(sp)
    80004712:	7406                	ld	s0,96(sp)
    80004714:	64e6                	ld	s1,88(sp)
    80004716:	6946                	ld	s2,80(sp)
    80004718:	69a6                	ld	s3,72(sp)
    8000471a:	6a06                	ld	s4,64(sp)
    8000471c:	7ae2                	ld	s5,56(sp)
    8000471e:	6165                	addi	sp,sp,112
    80004720:	8082                	ret
      wakeup(&pi->nread);
    80004722:	856a                	mv	a0,s10
    80004724:	909fd0ef          	jal	8000202c <wakeup>
      sleep_prepare(&pi->nwrite);
    80004728:	855a                	mv	a0,s6
    8000472a:	87bfd0ef          	jal	80001fa4 <sleep_prepare>
      release(&pi->lock);
    8000472e:	8526                	mv	a0,s1
    80004730:	d72fc0ef          	jal	80000ca2 <release>
      sleep(&pi->nwrite, &pi->lock);
    80004734:	85a6                	mv	a1,s1
    80004736:	855a                	mv	a0,s6
    80004738:	8a9fd0ef          	jal	80001fe0 <sleep>
      acquire(&pi->lock);
    8000473c:	8526                	mv	a0,s1
    8000473e:	cd2fc0ef          	jal	80000c10 <acquire>
  while (i < n) {
    80004742:	07495b63          	bge	s2,s4,800047b8 <pipewrite+0x102>
    if (pi->readopen == 0 || killed(pr)) {
    80004746:	2204a783          	lw	a5,544(s1)
    8000474a:	dbcd                	beqz	a5,800046fc <pipewrite+0x46>
    8000474c:	854e                	mv	a0,s3
    8000474e:	af7fd0ef          	jal	80002244 <killed>
    80004752:	f54d                	bnez	a0,800046fc <pipewrite+0x46>
    if (pi->nwrite == pi->nread + PIPESIZE) { //DOC: pipewrite-full
    80004754:	2184a783          	lw	a5,536(s1)
    80004758:	21c4a703          	lw	a4,540(s1)
    8000475c:	2007879b          	addiw	a5,a5,512
    80004760:	fcf701e3          	beq	a4,a5,80004722 <pipewrite+0x6c>
      if (copyin(pr->pagetable, pr->sz, &ch, addr + i, 1) == -1) {
    80004764:	8762                	mv	a4,s8
    80004766:	015906b3          	add	a3,s2,s5
    8000476a:	8666                	mv	a2,s9
    8000476c:	0489b583          	ld	a1,72(s3)
    80004770:	0509b503          	ld	a0,80(s3)
    80004774:	eadfc0ef          	jal	80001620 <copyin>
    80004778:	03750163          	beq	a0,s7,8000479a <pipewrite+0xe4>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    8000477c:	21c4a783          	lw	a5,540(s1)
    80004780:	0017871b          	addiw	a4,a5,1
    80004784:	20e4ae23          	sw	a4,540(s1)
    80004788:	1ff7f793          	andi	a5,a5,511
    8000478c:	97a6                	add	a5,a5,s1
    8000478e:	f9f44703          	lbu	a4,-97(s0)
    80004792:	00e78c23          	sb	a4,24(a5)
      i++;
    80004796:	2905                	addiw	s2,s2,1
    80004798:	b76d                	j	80004742 <pipewrite+0x8c>
        if (i == 0)
    8000479a:	00090863          	beqz	s2,800047aa <pipewrite+0xf4>
    8000479e:	7b42                	ld	s6,48(sp)
    800047a0:	7ba2                	ld	s7,40(sp)
    800047a2:	7c02                	ld	s8,32(sp)
    800047a4:	6ce2                	ld	s9,24(sp)
    800047a6:	6d42                	ld	s10,16(sp)
    800047a8:	a829                	j	800047c2 <pipewrite+0x10c>
          i = -1;
    800047aa:	892a                	mv	s2,a0
        break;
    800047ac:	7b42                	ld	s6,48(sp)
    800047ae:	7ba2                	ld	s7,40(sp)
    800047b0:	7c02                	ld	s8,32(sp)
    800047b2:	6ce2                	ld	s9,24(sp)
    800047b4:	6d42                	ld	s10,16(sp)
    800047b6:	a031                	j	800047c2 <pipewrite+0x10c>
    800047b8:	7b42                	ld	s6,48(sp)
    800047ba:	7ba2                	ld	s7,40(sp)
    800047bc:	7c02                	ld	s8,32(sp)
    800047be:	6ce2                	ld	s9,24(sp)
    800047c0:	6d42                	ld	s10,16(sp)
  wakeup(&pi->nread);
    800047c2:	21848513          	addi	a0,s1,536
    800047c6:	867fd0ef          	jal	8000202c <wakeup>
  release(&pi->lock);
    800047ca:	8526                	mv	a0,s1
    800047cc:	cd6fc0ef          	jal	80000ca2 <release>
  return i;
    800047d0:	bf3d                	j	8000470e <pipewrite+0x58>
  int i = 0;
    800047d2:	4901                	li	s2,0
    800047d4:	b7fd                	j	800047c2 <pipewrite+0x10c>

00000000800047d6 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    800047d6:	711d                	addi	sp,sp,-96
    800047d8:	ec86                	sd	ra,88(sp)
    800047da:	e8a2                	sd	s0,80(sp)
    800047dc:	e4a6                	sd	s1,72(sp)
    800047de:	e0ca                	sd	s2,64(sp)
    800047e0:	fc4e                	sd	s3,56(sp)
    800047e2:	f852                	sd	s4,48(sp)
    800047e4:	f456                	sd	s5,40(sp)
    800047e6:	1080                	addi	s0,sp,96
    800047e8:	84aa                	mv	s1,a0
    800047ea:	89ae                	mv	s3,a1
    800047ec:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    800047ee:	928fd0ef          	jal	80001916 <myproc>
    800047f2:	892a                	mv	s2,a0
  char ch;

  acquire(&pi->lock);
    800047f4:	8526                	mv	a0,s1
    800047f6:	c1afc0ef          	jal	80000c10 <acquire>
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    800047fa:	2184a703          	lw	a4,536(s1)
    800047fe:	21c4a783          	lw	a5,540(s1)
    if (killed(pr)) {
      release(&pi->lock);
      return -1;
    }
    sleep_prepare(&pi->nread); //DOC: piperead-sleep
    80004802:	21848a13          	addi	s4,s1,536
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    80004806:	02f71c63          	bne	a4,a5,8000483e <piperead+0x68>
    8000480a:	2244a783          	lw	a5,548(s1)
    8000480e:	cb85                	beqz	a5,8000483e <piperead+0x68>
    if (killed(pr)) {
    80004810:	854a                	mv	a0,s2
    80004812:	a33fd0ef          	jal	80002244 <killed>
    80004816:	e159                	bnez	a0,8000489c <piperead+0xc6>
    sleep_prepare(&pi->nread); //DOC: piperead-sleep
    80004818:	8552                	mv	a0,s4
    8000481a:	f8afd0ef          	jal	80001fa4 <sleep_prepare>
    release(&pi->lock);
    8000481e:	8526                	mv	a0,s1
    80004820:	c82fc0ef          	jal	80000ca2 <release>
    sleep(&pi->nread, &pi->lock);
    80004824:	85a6                	mv	a1,s1
    80004826:	8552                	mv	a0,s4
    80004828:	fb8fd0ef          	jal	80001fe0 <sleep>
    acquire(&pi->lock);
    8000482c:	8526                	mv	a0,s1
    8000482e:	be2fc0ef          	jal	80000c10 <acquire>
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    80004832:	2184a703          	lw	a4,536(s1)
    80004836:	21c4a783          	lw	a5,540(s1)
    8000483a:	fcf708e3          	beq	a4,a5,8000480a <piperead+0x34>
  }
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    8000483e:	07505a63          	blez	s5,800048b2 <piperead+0xdc>
    80004842:	f05a                	sd	s6,32(sp)
    80004844:	ec5e                	sd	s7,24(sp)
    80004846:	e862                	sd	s8,16(sp)
    80004848:	4a01                	li	s4,0
    if (pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread % PIPESIZE];
    if (copyout(pr->pagetable, pr->sz, addr + i, &ch, 1) == -1) {
    8000484a:	faf40c13          	addi	s8,s0,-81
    8000484e:	4b85                	li	s7,1
    80004850:	5b7d                	li	s6,-1
    if (pi->nread == pi->nwrite)
    80004852:	2184a783          	lw	a5,536(s1)
    80004856:	21c4a703          	lw	a4,540(s1)
    8000485a:	06f70363          	beq	a4,a5,800048c0 <piperead+0xea>
    ch = pi->data[pi->nread % PIPESIZE];
    8000485e:	1ff7f793          	andi	a5,a5,511
    80004862:	97a6                	add	a5,a5,s1
    80004864:	0187c783          	lbu	a5,24(a5)
    80004868:	faf407a3          	sb	a5,-81(s0)
    if (copyout(pr->pagetable, pr->sz, addr + i, &ch, 1) == -1) {
    8000486c:	875e                	mv	a4,s7
    8000486e:	86e2                	mv	a3,s8
    80004870:	864e                	mv	a2,s3
    80004872:	04893583          	ld	a1,72(s2)
    80004876:	05093503          	ld	a0,80(s2)
    8000487a:	ce7fc0ef          	jal	80001560 <copyout>
    8000487e:	03650463          	beq	a0,s6,800048a6 <piperead+0xd0>
      if (i == 0)
        i = -1;
      break;
    }
    pi->nread++;
    80004882:	2184a783          	lw	a5,536(s1)
    80004886:	2785                	addiw	a5,a5,1
    80004888:	20f4ac23          	sw	a5,536(s1)
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    8000488c:	2a05                	addiw	s4,s4,1
    8000488e:	0985                	addi	s3,s3,1
    80004890:	fd4a91e3          	bne	s5,s4,80004852 <piperead+0x7c>
    80004894:	7b02                	ld	s6,32(sp)
    80004896:	6be2                	ld	s7,24(sp)
    80004898:	6c42                	ld	s8,16(sp)
    8000489a:	a035                	j	800048c6 <piperead+0xf0>
      release(&pi->lock);
    8000489c:	8526                	mv	a0,s1
    8000489e:	c04fc0ef          	jal	80000ca2 <release>
      return -1;
    800048a2:	5a7d                	li	s4,-1
    800048a4:	a805                	j	800048d4 <piperead+0xfe>
      if (i == 0)
    800048a6:	000a0863          	beqz	s4,800048b6 <piperead+0xe0>
    800048aa:	7b02                	ld	s6,32(sp)
    800048ac:	6be2                	ld	s7,24(sp)
    800048ae:	6c42                	ld	s8,16(sp)
    800048b0:	a819                	j	800048c6 <piperead+0xf0>
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    800048b2:	4a01                	li	s4,0
    800048b4:	a809                	j	800048c6 <piperead+0xf0>
        i = -1;
    800048b6:	8a2a                	mv	s4,a0
    800048b8:	7b02                	ld	s6,32(sp)
    800048ba:	6be2                	ld	s7,24(sp)
    800048bc:	6c42                	ld	s8,16(sp)
    800048be:	a021                	j	800048c6 <piperead+0xf0>
    800048c0:	7b02                	ld	s6,32(sp)
    800048c2:	6be2                	ld	s7,24(sp)
    800048c4:	6c42                	ld	s8,16(sp)
  }
  wakeup(&pi->nwrite); //DOC: piperead-wakeup
    800048c6:	21c48513          	addi	a0,s1,540
    800048ca:	f62fd0ef          	jal	8000202c <wakeup>
  release(&pi->lock);
    800048ce:	8526                	mv	a0,s1
    800048d0:	bd2fc0ef          	jal	80000ca2 <release>
  return i;
}
    800048d4:	8552                	mv	a0,s4
    800048d6:	60e6                	ld	ra,88(sp)
    800048d8:	6446                	ld	s0,80(sp)
    800048da:	64a6                	ld	s1,72(sp)
    800048dc:	6906                	ld	s2,64(sp)
    800048de:	79e2                	ld	s3,56(sp)
    800048e0:	7a42                	ld	s4,48(sp)
    800048e2:	7aa2                	ld	s5,40(sp)
    800048e4:	6125                	addi	sp,sp,96
    800048e6:	8082                	ret

00000000800048e8 <flags2perm>:
static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

// map ELF permissions to PTE permission bits.
int
flags2perm(int flags)
{
    800048e8:	1141                	addi	sp,sp,-16
    800048ea:	e406                	sd	ra,8(sp)
    800048ec:	e022                	sd	s0,0(sp)
    800048ee:	0800                	addi	s0,sp,16
    800048f0:	87aa                	mv	a5,a0
  int perm = 0;
  if (flags & 0x1)
    800048f2:	0035151b          	slliw	a0,a0,0x3
    800048f6:	8921                	andi	a0,a0,8
    perm = PTE_X;
  if (flags & 0x2)
    800048f8:	8b89                	andi	a5,a5,2
    800048fa:	c399                	beqz	a5,80004900 <flags2perm+0x18>
    perm |= PTE_W;
    800048fc:	00456513          	ori	a0,a0,4
  return perm;
}
    80004900:	60a2                	ld	ra,8(sp)
    80004902:	6402                	ld	s0,0(sp)
    80004904:	0141                	addi	sp,sp,16
    80004906:	8082                	ret

0000000080004908 <kexec>:
//
// the implementation of the exec() system call
//
int
kexec(char *path, char **argv)
{
    80004908:	df010113          	addi	sp,sp,-528
    8000490c:	20113423          	sd	ra,520(sp)
    80004910:	20813023          	sd	s0,512(sp)
    80004914:	ffa6                	sd	s1,504(sp)
    80004916:	fbca                	sd	s2,496(sp)
    80004918:	0c00                	addi	s0,sp,528
    8000491a:	892a                	mv	s2,a0
    8000491c:	e0a43023          	sd	a0,-512(s0)
    80004920:	deb43c23          	sd	a1,-520(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80004924:	ff3fc0ef          	jal	80001916 <myproc>
    80004928:	84aa                	mv	s1,a0

  begin_op();
    8000492a:	c84ff0ef          	jal	80003dae <begin_op>

  // Open the executable file.
  if ((ip = namei(path)) == 0) {
    8000492e:	854a                	mv	a0,s2
    80004930:	aa0ff0ef          	jal	80003bd0 <namei>
    80004934:	c931                	beqz	a0,80004988 <kexec+0x80>
    80004936:	f3d2                	sd	s4,480(sp)
    80004938:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    8000493a:	9f3fe0ef          	jal	8000332c <ilock>

  // Read the ELF header.
  if (readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    8000493e:	04000713          	li	a4,64
    80004942:	4681                	li	a3,0
    80004944:	e5040613          	addi	a2,s0,-432
    80004948:	4581                	li	a1,0
    8000494a:	8552                	mv	a0,s4
    8000494c:	dbbfe0ef          	jal	80003706 <readi>
    80004950:	04000793          	li	a5,64
    80004954:	00f51a63          	bne	a0,a5,80004968 <kexec+0x60>
    goto bad;

  // Is this really an ELF file?
  if (elf.magic != ELF_MAGIC)
    80004958:	e5042703          	lw	a4,-432(s0)
    8000495c:	464c47b7          	lui	a5,0x464c4
    80004960:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80004964:	02f70563          	beq	a4,a5,8000498e <kexec+0x86>

bad:
  if (pagetable)
    proc_freepagetable(pagetable, sz);
  if (ip) {
    iunlockput(ip);
    80004968:	8552                	mv	a0,s4
    8000496a:	c17fe0ef          	jal	80003580 <iunlockput>
    end_op();
    8000496e:	cd4ff0ef          	jal	80003e42 <end_op>
    80004972:	7a1e                	ld	s4,480(sp)
    return -1;
    80004974:	557d                	li	a0,-1
  }
  return -1;
}
    80004976:	20813083          	ld	ra,520(sp)
    8000497a:	20013403          	ld	s0,512(sp)
    8000497e:	74fe                	ld	s1,504(sp)
    80004980:	795e                	ld	s2,496(sp)
    80004982:	21010113          	addi	sp,sp,528
    80004986:	8082                	ret
    end_op();
    80004988:	cbaff0ef          	jal	80003e42 <end_op>
    return -1;
    8000498c:	b7e5                	j	80004974 <kexec+0x6c>
    8000498e:	ebda                	sd	s6,464(sp)
  if ((pagetable = proc_pagetable(p)) == 0)
    80004990:	8526                	mv	a0,s1
    80004992:	88afd0ef          	jal	80001a1c <proc_pagetable>
    80004996:	8b2a                	mv	s6,a0
    80004998:	26050263          	beqz	a0,80004bfc <kexec+0x2f4>
    8000499c:	f7ce                	sd	s3,488(sp)
    8000499e:	efd6                	sd	s5,472(sp)
    800049a0:	e7de                	sd	s7,456(sp)
    800049a2:	e3e2                	sd	s8,448(sp)
    800049a4:	ff66                	sd	s9,440(sp)
    800049a6:	fb6a                	sd	s10,432(sp)
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    800049a8:	e8845783          	lhu	a5,-376(s0)
    800049ac:	12078763          	beqz	a5,80004ada <kexec+0x1d2>
    800049b0:	f76e                	sd	s11,424(sp)
    800049b2:	e7042683          	lw	a3,-400(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    800049b6:	4901                	li	s2,0
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    800049b8:	4d01                	li	s10,0
    if (readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    800049ba:	03800d93          	li	s11,56

  for (i = 0; i < sz; i += PGSIZE) {
    pa = walkaddr(pagetable, va + i);
    if (pa == 0)
      panic("loadseg: address should exist");
    if (sz - i < PGSIZE)
    800049be:	6c85                	lui	s9,0x1
    800049c0:	6a85                	lui	s5,0x1
    800049c2:	a085                	j	80004a22 <kexec+0x11a>
      panic("loadseg: address should exist");
    800049c4:	00003517          	auipc	a0,0x3
    800049c8:	c3c50513          	addi	a0,a0,-964 # 80007600 <etext+0x600>
    800049cc:	e67fb0ef          	jal	80000832 <panic>
    if (sz - i < PGSIZE)
    800049d0:	2901                	sext.w	s2,s2
      n = sz - i;
    else
      n = PGSIZE;
    if (readi(ip, 0, (uint64)pa, offset + i, n) != n)
    800049d2:	874a                	mv	a4,s2
    800049d4:	009b86bb          	addw	a3,s7,s1
    800049d8:	4581                	li	a1,0
    800049da:	8552                	mv	a0,s4
    800049dc:	d2bfe0ef          	jal	80003706 <readi>
    800049e0:	22a91263          	bne	s2,a0,80004c04 <kexec+0x2fc>
  for (i = 0; i < sz; i += PGSIZE) {
    800049e4:	009a84bb          	addw	s1,s5,s1
    800049e8:	0334f263          	bgeu	s1,s3,80004a0c <kexec+0x104>
    pa = walkaddr(pagetable, va + i);
    800049ec:	02049593          	slli	a1,s1,0x20
    800049f0:	9181                	srli	a1,a1,0x20
    800049f2:	95e2                	add	a1,a1,s8
    800049f4:	855a                	mv	a0,s6
    800049f6:	e16fc0ef          	jal	8000100c <walkaddr>
    800049fa:	862a                	mv	a2,a0
    if (pa == 0)
    800049fc:	d561                	beqz	a0,800049c4 <kexec+0xbc>
    if (sz - i < PGSIZE)
    800049fe:	409987bb          	subw	a5,s3,s1
    80004a02:	893e                	mv	s2,a5
    80004a04:	fcfcf6e3          	bgeu	s9,a5,800049d0 <kexec+0xc8>
    80004a08:	8956                	mv	s2,s5
    80004a0a:	b7d9                	j	800049d0 <kexec+0xc8>
    sz = sz1;
    80004a0c:	df043903          	ld	s2,-528(s0)
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    80004a10:	2d05                	addiw	s10,s10,1
    80004a12:	e0843783          	ld	a5,-504(s0)
    80004a16:	0387869b          	addiw	a3,a5,56
    80004a1a:	e8845783          	lhu	a5,-376(s0)
    80004a1e:	06fd5863          	bge	s10,a5,80004a8e <kexec+0x186>
    if (readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80004a22:	e0d43423          	sd	a3,-504(s0)
    80004a26:	876e                	mv	a4,s11
    80004a28:	e1840613          	addi	a2,s0,-488
    80004a2c:	4581                	li	a1,0
    80004a2e:	8552                	mv	a0,s4
    80004a30:	cd7fe0ef          	jal	80003706 <readi>
    80004a34:	1db51663          	bne	a0,s11,80004c00 <kexec+0x2f8>
    if (ph.type != ELF_PROG_LOAD)
    80004a38:	e1842783          	lw	a5,-488(s0)
    80004a3c:	4705                	li	a4,1
    80004a3e:	fce799e3          	bne	a5,a4,80004a10 <kexec+0x108>
    if (ph.memsz < ph.filesz)
    80004a42:	e4043483          	ld	s1,-448(s0)
    80004a46:	e3843783          	ld	a5,-456(s0)
    80004a4a:	1af4eb63          	bltu	s1,a5,80004c00 <kexec+0x2f8>
    if (ph.vaddr + ph.memsz < ph.vaddr)
    80004a4e:	e2843783          	ld	a5,-472(s0)
    80004a52:	94be                	add	s1,s1,a5
    80004a54:	1af4e663          	bltu	s1,a5,80004c00 <kexec+0x2f8>
    if (ph.vaddr % PGSIZE != 0)
    80004a58:	17d2                	slli	a5,a5,0x34
    80004a5a:	1a079363          	bnez	a5,80004c00 <kexec+0x2f8>
    if ((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz,
    80004a5e:	e1c42503          	lw	a0,-484(s0)
    80004a62:	e87ff0ef          	jal	800048e8 <flags2perm>
    80004a66:	86aa                	mv	a3,a0
    80004a68:	8626                	mv	a2,s1
    80004a6a:	85ca                	mv	a1,s2
    80004a6c:	855a                	mv	a0,s6
    80004a6e:	86dfc0ef          	jal	800012da <uvmalloc>
    80004a72:	dea43823          	sd	a0,-528(s0)
    80004a76:	18050563          	beqz	a0,80004c00 <kexec+0x2f8>
    if (loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004a7a:	e3842983          	lw	s3,-456(s0)
  for (i = 0; i < sz; i += PGSIZE) {
    80004a7e:	f80987e3          	beqz	s3,80004a0c <kexec+0x104>
    if (loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004a82:	e2843c03          	ld	s8,-472(s0)
    80004a86:	e2042b83          	lw	s7,-480(s0)
  for (i = 0; i < sz; i += PGSIZE) {
    80004a8a:	4481                	li	s1,0
    80004a8c:	b785                	j	800049ec <kexec+0xe4>
    80004a8e:	7dba                	ld	s11,424(sp)
  iunlockput(ip);
    80004a90:	8552                	mv	a0,s4
    80004a92:	aeffe0ef          	jal	80003580 <iunlockput>
  end_op();
    80004a96:	bacff0ef          	jal	80003e42 <end_op>
  p = myproc();
    80004a9a:	e7dfc0ef          	jal	80001916 <myproc>
    80004a9e:	89aa                	mv	s3,a0
  uint64 oldsz = p->sz;
    80004aa0:	04853a03          	ld	s4,72(a0)
  sz = PGROUNDUP(sz);
    80004aa4:	6485                	lui	s1,0x1
    80004aa6:	14fd                	addi	s1,s1,-1 # fff <_entry-0x7ffff001>
    80004aa8:	94ca                	add	s1,s1,s2
    80004aaa:	77fd                	lui	a5,0xfffff
    80004aac:	8cfd                	and	s1,s1,a5
  if ((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK + 1) * PGSIZE, PTE_W)) ==
    80004aae:	4691                	li	a3,4
    80004ab0:	6609                	lui	a2,0x2
    80004ab2:	9626                	add	a2,a2,s1
    80004ab4:	85a6                	mv	a1,s1
    80004ab6:	855a                	mv	a0,s6
    80004ab8:	823fc0ef          	jal	800012da <uvmalloc>
    80004abc:	8aaa                	mv	s5,a0
    80004abe:	e105                	bnez	a0,80004ade <kexec+0x1d6>
    proc_freepagetable(pagetable, sz);
    80004ac0:	85a6                	mv	a1,s1
    80004ac2:	855a                	mv	a0,s6
    80004ac4:	fdbfc0ef          	jal	80001a9e <proc_freepagetable>
  if (ip) {
    80004ac8:	79be                	ld	s3,488(sp)
    80004aca:	7a1e                	ld	s4,480(sp)
    80004acc:	6afe                	ld	s5,472(sp)
    80004ace:	6b5e                	ld	s6,464(sp)
    80004ad0:	6bbe                	ld	s7,456(sp)
    80004ad2:	6c1e                	ld	s8,448(sp)
    80004ad4:	7cfa                	ld	s9,440(sp)
    80004ad6:	7d5a                	ld	s10,432(sp)
    80004ad8:	bd71                	j	80004974 <kexec+0x6c>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004ada:	4901                	li	s2,0
    80004adc:	bf55                	j	80004a90 <kexec+0x188>
  uvmclear(pagetable, sz - (USERSTACK + 1) * PGSIZE);
    80004ade:	75f9                	lui	a1,0xffffe
    80004ae0:	95aa                	add	a1,a1,a0
    80004ae2:	855a                	mv	a0,s6
    80004ae4:	9bffc0ef          	jal	800014a2 <uvmclear>
  stackbase = sp - USERSTACK * PGSIZE;
    80004ae8:	7bfd                	lui	s7,0xfffff
    80004aea:	9bd6                	add	s7,s7,s5
  for (argc = 0; argv[argc]; argc++) {
    80004aec:	df843783          	ld	a5,-520(s0)
    80004af0:	6388                	ld	a0,0(a5)
    80004af2:	cd3d                	beqz	a0,80004b70 <kexec+0x268>
  sp = sz;
    80004af4:	8c56                	mv	s8,s5
  for (argc = 0; argv[argc]; argc++) {
    80004af6:	4481                	li	s1,0
    ustack[argc] = sp;
    80004af8:	e9040913          	addi	s2,s0,-368
    sp -= strlen(argv[argc]) + 1;
    80004afc:	b6cfc0ef          	jal	80000e68 <strlen>
    80004b00:	0015079b          	addiw	a5,a0,1
    80004b04:	40fc07b3          	sub	a5,s8,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80004b08:	ff07fc13          	andi	s8,a5,-16
    if (sp < stackbase)
    80004b0c:	077c6063          	bltu	s8,s7,80004b6c <kexec+0x264>
    if (copyout(pagetable, sz, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80004b10:	df843d03          	ld	s10,-520(s0)
    80004b14:	000d3c83          	ld	s9,0(s10)
    80004b18:	8566                	mv	a0,s9
    80004b1a:	b4efc0ef          	jal	80000e68 <strlen>
    80004b1e:	0015071b          	addiw	a4,a0,1
    80004b22:	86e6                	mv	a3,s9
    80004b24:	8662                	mv	a2,s8
    80004b26:	85d6                	mv	a1,s5
    80004b28:	855a                	mv	a0,s6
    80004b2a:	a37fc0ef          	jal	80001560 <copyout>
    80004b2e:	02054f63          	bltz	a0,80004b6c <kexec+0x264>
    ustack[argc] = sp;
    80004b32:	00349793          	slli	a5,s1,0x3
    80004b36:	97ca                	add	a5,a5,s2
    80004b38:	0187b023          	sd	s8,0(a5) # fffffffffffff000 <end+0xffffffff7ffde218>
  for (argc = 0; argv[argc]; argc++) {
    80004b3c:	0485                	addi	s1,s1,1
    80004b3e:	008d0793          	addi	a5,s10,8
    80004b42:	def43c23          	sd	a5,-520(s0)
    80004b46:	008d3503          	ld	a0,8(s10)
    80004b4a:	f94d                	bnez	a0,80004afc <kexec+0x1f4>
  ustack[argc] = 0;
    80004b4c:	00349793          	slli	a5,s1,0x3
    80004b50:	f9040713          	addi	a4,s0,-112
    80004b54:	97ba                	add	a5,a5,a4
    80004b56:	f007b023          	sd	zero,-256(a5)
  sp -= (argc + 1) * sizeof(uint64);
    80004b5a:	00148713          	addi	a4,s1,1
    80004b5e:	070e                	slli	a4,a4,0x3
    80004b60:	40ec0933          	sub	s2,s8,a4
  sp -= sp % 16;
    80004b64:	ff097913          	andi	s2,s2,-16
  if (sp < stackbase)
    80004b68:	01797763          	bgeu	s2,s7,80004b76 <kexec+0x26e>
  sz = sz1;
    80004b6c:	84d6                	mv	s1,s5
    80004b6e:	bf89                	j	80004ac0 <kexec+0x1b8>
  sp = sz;
    80004b70:	8c56                	mv	s8,s5
  for (argc = 0; argv[argc]; argc++) {
    80004b72:	4481                	li	s1,0
    80004b74:	bfe1                	j	80004b4c <kexec+0x244>
  if (copyout(pagetable, sz, sp, (char *)ustack, (argc + 1) * sizeof(uint64)) <
    80004b76:	e9040693          	addi	a3,s0,-368
    80004b7a:	864a                	mv	a2,s2
    80004b7c:	85d6                	mv	a1,s5
    80004b7e:	855a                	mv	a0,s6
    80004b80:	9e1fc0ef          	jal	80001560 <copyout>
    80004b84:	fe0544e3          	bltz	a0,80004b6c <kexec+0x264>
  p->trapframe->a1 = sp;
    80004b88:	0589b783          	ld	a5,88(s3)
    80004b8c:	0727bc23          	sd	s2,120(a5)
  for (last = s = path; *s; s++)
    80004b90:	e0043783          	ld	a5,-512(s0)
    80004b94:	0007c703          	lbu	a4,0(a5)
    80004b98:	cf11                	beqz	a4,80004bb4 <kexec+0x2ac>
    80004b9a:	0785                	addi	a5,a5,1
    if (*s == '/')
    80004b9c:	02f00693          	li	a3,47
    80004ba0:	a029                	j	80004baa <kexec+0x2a2>
  for (last = s = path; *s; s++)
    80004ba2:	0785                	addi	a5,a5,1
    80004ba4:	fff7c703          	lbu	a4,-1(a5)
    80004ba8:	c711                	beqz	a4,80004bb4 <kexec+0x2ac>
    if (*s == '/')
    80004baa:	fed71ce3          	bne	a4,a3,80004ba2 <kexec+0x29a>
      last = s + 1;
    80004bae:	e0f43023          	sd	a5,-512(s0)
    80004bb2:	bfc5                	j	80004ba2 <kexec+0x29a>
  safestrcpy(p->name, last, sizeof(p->name));
    80004bb4:	4641                	li	a2,16
    80004bb6:	e0043583          	ld	a1,-512(s0)
    80004bba:	15898513          	addi	a0,s3,344
    80004bbe:	a74fc0ef          	jal	80000e32 <safestrcpy>
  oldpagetable = p->pagetable;
    80004bc2:	0509b503          	ld	a0,80(s3)
  p->pagetable = pagetable;
    80004bc6:	0569b823          	sd	s6,80(s3)
  p->sz = sz;
    80004bca:	0559b423          	sd	s5,72(s3)
  p->trapframe->epc = elf.entry; // initial program counter = ulib.c:start()
    80004bce:	0589b783          	ld	a5,88(s3)
    80004bd2:	e6843703          	ld	a4,-408(s0)
    80004bd6:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp;         // initial stack pointer
    80004bd8:	0589b783          	ld	a5,88(s3)
    80004bdc:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80004be0:	85d2                	mv	a1,s4
    80004be2:	ebdfc0ef          	jal	80001a9e <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80004be6:	0004851b          	sext.w	a0,s1
    80004bea:	79be                	ld	s3,488(sp)
    80004bec:	7a1e                	ld	s4,480(sp)
    80004bee:	6afe                	ld	s5,472(sp)
    80004bf0:	6b5e                	ld	s6,464(sp)
    80004bf2:	6bbe                	ld	s7,456(sp)
    80004bf4:	6c1e                	ld	s8,448(sp)
    80004bf6:	7cfa                	ld	s9,440(sp)
    80004bf8:	7d5a                	ld	s10,432(sp)
    80004bfa:	bbb5                	j	80004976 <kexec+0x6e>
    80004bfc:	6b5e                	ld	s6,464(sp)
    80004bfe:	b3ad                	j	80004968 <kexec+0x60>
    return -1;
    80004c00:	df243823          	sd	s2,-528(s0)
    proc_freepagetable(pagetable, sz);
    80004c04:	df043583          	ld	a1,-528(s0)
    80004c08:	855a                	mv	a0,s6
    80004c0a:	e95fc0ef          	jal	80001a9e <proc_freepagetable>
  if (ip) {
    80004c0e:	79be                	ld	s3,488(sp)
    80004c10:	6afe                	ld	s5,472(sp)
    80004c12:	6b5e                	ld	s6,464(sp)
    80004c14:	6bbe                	ld	s7,456(sp)
    80004c16:	6c1e                	ld	s8,448(sp)
    80004c18:	7cfa                	ld	s9,440(sp)
    80004c1a:	7d5a                	ld	s10,432(sp)
    80004c1c:	7dba                	ld	s11,424(sp)
    80004c1e:	b3a9                	j	80004968 <kexec+0x60>

0000000080004c20 <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80004c20:	7179                	addi	sp,sp,-48
    80004c22:	f406                	sd	ra,40(sp)
    80004c24:	f022                	sd	s0,32(sp)
    80004c26:	ec26                	sd	s1,24(sp)
    80004c28:	e84a                	sd	s2,16(sp)
    80004c2a:	1800                	addi	s0,sp,48
    80004c2c:	892e                	mv	s2,a1
    80004c2e:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80004c30:	fdc40593          	addi	a1,s0,-36
    80004c34:	d21fd0ef          	jal	80002954 <argint>
  if (fd < 0 || fd >= NOFILE || (f = myproc()->ofile[fd]) == 0)
    80004c38:	fdc42703          	lw	a4,-36(s0)
    80004c3c:	47bd                	li	a5,15
    80004c3e:	02e7e963          	bltu	a5,a4,80004c70 <argfd+0x50>
    80004c42:	cd5fc0ef          	jal	80001916 <myproc>
    80004c46:	fdc42703          	lw	a4,-36(s0)
    80004c4a:	01a70793          	addi	a5,a4,26
    80004c4e:	078e                	slli	a5,a5,0x3
    80004c50:	953e                	add	a0,a0,a5
    80004c52:	611c                	ld	a5,0(a0)
    80004c54:	cf91                	beqz	a5,80004c70 <argfd+0x50>
    return -1;
  if (pfd)
    80004c56:	00090463          	beqz	s2,80004c5e <argfd+0x3e>
    *pfd = fd;
    80004c5a:	00e92023          	sw	a4,0(s2)
  if (pf)
    80004c5e:	c091                	beqz	s1,80004c62 <argfd+0x42>
    *pf = f;
    80004c60:	e09c                	sd	a5,0(s1)
  return 0;
    80004c62:	4501                	li	a0,0
}
    80004c64:	70a2                	ld	ra,40(sp)
    80004c66:	7402                	ld	s0,32(sp)
    80004c68:	64e2                	ld	s1,24(sp)
    80004c6a:	6942                	ld	s2,16(sp)
    80004c6c:	6145                	addi	sp,sp,48
    80004c6e:	8082                	ret
    return -1;
    80004c70:	557d                	li	a0,-1
    80004c72:	bfcd                	j	80004c64 <argfd+0x44>

0000000080004c74 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80004c74:	1101                	addi	sp,sp,-32
    80004c76:	ec06                	sd	ra,24(sp)
    80004c78:	e822                	sd	s0,16(sp)
    80004c7a:	e426                	sd	s1,8(sp)
    80004c7c:	1000                	addi	s0,sp,32
    80004c7e:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80004c80:	c97fc0ef          	jal	80001916 <myproc>
    80004c84:	862a                	mv	a2,a0

  for (fd = 0; fd < NOFILE; fd++) {
    80004c86:	0d050793          	addi	a5,a0,208
    80004c8a:	4501                	li	a0,0
    80004c8c:	46c1                	li	a3,16
    if (p->ofile[fd] == 0) {
    80004c8e:	6398                	ld	a4,0(a5)
    80004c90:	cb19                	beqz	a4,80004ca6 <fdalloc+0x32>
  for (fd = 0; fd < NOFILE; fd++) {
    80004c92:	2505                	addiw	a0,a0,1
    80004c94:	07a1                	addi	a5,a5,8
    80004c96:	fed51ce3          	bne	a0,a3,80004c8e <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80004c9a:	557d                	li	a0,-1
}
    80004c9c:	60e2                	ld	ra,24(sp)
    80004c9e:	6442                	ld	s0,16(sp)
    80004ca0:	64a2                	ld	s1,8(sp)
    80004ca2:	6105                	addi	sp,sp,32
    80004ca4:	8082                	ret
      p->ofile[fd] = f;
    80004ca6:	01a50793          	addi	a5,a0,26
    80004caa:	078e                	slli	a5,a5,0x3
    80004cac:	963e                	add	a2,a2,a5
    80004cae:	e204                	sd	s1,0(a2)
      return fd;
    80004cb0:	b7f5                	j	80004c9c <fdalloc+0x28>

0000000080004cb2 <create>:
  return -1;
}

static struct inode *
create(char *path, short type, short major, short minor)
{
    80004cb2:	715d                	addi	sp,sp,-80
    80004cb4:	e486                	sd	ra,72(sp)
    80004cb6:	e0a2                	sd	s0,64(sp)
    80004cb8:	fc26                	sd	s1,56(sp)
    80004cba:	f84a                	sd	s2,48(sp)
    80004cbc:	f44e                	sd	s3,40(sp)
    80004cbe:	ec56                	sd	s5,24(sp)
    80004cc0:	e85a                	sd	s6,16(sp)
    80004cc2:	0880                	addi	s0,sp,80
    80004cc4:	89ae                	mv	s3,a1
    80004cc6:	8ab2                	mv	s5,a2
    80004cc8:	8b36                	mv	s6,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if ((dp = nameiparent(path, name)) == 0)
    80004cca:	fb040593          	addi	a1,s0,-80
    80004cce:	f1dfe0ef          	jal	80003bea <nameiparent>
    80004cd2:	84aa                	mv	s1,a0
    return 0;
    80004cd4:	892a                	mv	s2,a0
  if ((dp = nameiparent(path, name)) == 0)
    80004cd6:	cd31                	beqz	a0,80004d32 <create+0x80>

  ilock(dp);
    80004cd8:	e54fe0ef          	jal	8000332c <ilock>

  if (dp->nlink == 0) {
    80004cdc:	04a49783          	lh	a5,74(s1)
    80004ce0:	c3bd                	beqz	a5,80004d46 <create+0x94>
    iunlockput(dp);
    return 0;
  }

  // a new directory's ".." would push dp->nlink past its maximum
  if (type == T_DIR && dp->nlink >= NLINK_MAX) {
    80004ce2:	7761                	lui	a4,0xffff8
    80004ce4:	0705                	addi	a4,a4,1 # ffffffffffff8001 <end+0xffffffff7ffd7219>
    80004ce6:	97ba                	add	a5,a5,a4
    80004ce8:	0017b793          	seqz	a5,a5
    80004cec:	fff98713          	addi	a4,s3,-1
    80004cf0:	00173713          	seqz	a4,a4
    80004cf4:	8ff9                	and	a5,a5,a4
    80004cf6:	efa1                	bnez	a5,80004d4e <create+0x9c>
    iunlockput(dp);
    return 0;
  }

  if ((ip = dirlookup(dp, name, 0)) != 0) {
    80004cf8:	4601                	li	a2,0
    80004cfa:	fb040593          	addi	a1,s0,-80
    80004cfe:	8526                	mv	a0,s1
    80004d00:	c17fe0ef          	jal	80003916 <dirlookup>
    80004d04:	892a                	mv	s2,a0
    80004d06:	c921                	beqz	a0,80004d56 <create+0xa4>
    iunlockput(dp);
    80004d08:	8526                	mv	a0,s1
    80004d0a:	877fe0ef          	jal	80003580 <iunlockput>
    ilock(ip);
    80004d0e:	854a                	mv	a0,s2
    80004d10:	e1cfe0ef          	jal	8000332c <ilock>
    if (type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80004d14:	4789                	li	a5,2
    80004d16:	00f99a63          	bne	s3,a5,80004d2a <create+0x78>
    80004d1a:	04495783          	lhu	a5,68(s2)
    80004d1e:	37f9                	addiw	a5,a5,-2
    80004d20:	17c2                	slli	a5,a5,0x30
    80004d22:	93c1                	srli	a5,a5,0x30
    80004d24:	4705                	li	a4,1
    80004d26:	00f77663          	bgeu	a4,a5,80004d32 <create+0x80>
      return ip;
    iunlockput(ip);
    80004d2a:	854a                	mv	a0,s2
    80004d2c:	855fe0ef          	jal	80003580 <iunlockput>
    return 0;
    80004d30:	4901                	li	s2,0
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80004d32:	854a                	mv	a0,s2
    80004d34:	60a6                	ld	ra,72(sp)
    80004d36:	6406                	ld	s0,64(sp)
    80004d38:	74e2                	ld	s1,56(sp)
    80004d3a:	7942                	ld	s2,48(sp)
    80004d3c:	79a2                	ld	s3,40(sp)
    80004d3e:	6ae2                	ld	s5,24(sp)
    80004d40:	6b42                	ld	s6,16(sp)
    80004d42:	6161                	addi	sp,sp,80
    80004d44:	8082                	ret
    iunlockput(dp);
    80004d46:	8526                	mv	a0,s1
    80004d48:	839fe0ef          	jal	80003580 <iunlockput>
    return 0;
    80004d4c:	b7d5                	j	80004d30 <create+0x7e>
    iunlockput(dp);
    80004d4e:	8526                	mv	a0,s1
    80004d50:	831fe0ef          	jal	80003580 <iunlockput>
    return 0;
    80004d54:	bff1                	j	80004d30 <create+0x7e>
    80004d56:	f052                	sd	s4,32(sp)
  if ((ip = ialloc(dp->dev, type)) == 0) {
    80004d58:	85ce                	mv	a1,s3
    80004d5a:	4088                	lw	a0,0(s1)
    80004d5c:	c60fe0ef          	jal	800031bc <ialloc>
    80004d60:	8a2a                	mv	s4,a0
    80004d62:	cd1d                	beqz	a0,80004da0 <create+0xee>
  ilock(ip);
    80004d64:	dc8fe0ef          	jal	8000332c <ilock>
  ip->major = major;
    80004d68:	055a1323          	sh	s5,70(s4)
  ip->minor = minor;
    80004d6c:	056a1423          	sh	s6,72(s4)
  ip->nlink = 1;
    80004d70:	4705                	li	a4,1
    80004d72:	04ea1523          	sh	a4,74(s4)
  iupdate(ip);
    80004d76:	8552                	mv	a0,s4
    80004d78:	d00fe0ef          	jal	80003278 <iupdate>
  if (type == T_DIR) { // Create . and .. entries.
    80004d7c:	4785                	li	a5,1
    80004d7e:	02f98563          	beq	s3,a5,80004da8 <create+0xf6>
  if (dirlink(dp, name, ip->inum) < 0)
    80004d82:	004a2603          	lw	a2,4(s4)
    80004d86:	fb040593          	addi	a1,s0,-80
    80004d8a:	8526                	mv	a0,s1
    80004d8c:	d9bfe0ef          	jal	80003b26 <dirlink>
    80004d90:	06054363          	bltz	a0,80004df6 <create+0x144>
  iunlockput(dp);
    80004d94:	8526                	mv	a0,s1
    80004d96:	feafe0ef          	jal	80003580 <iunlockput>
    return 0;
    80004d9a:	8952                	mv	s2,s4
    80004d9c:	7a02                	ld	s4,32(sp)
    80004d9e:	bf51                	j	80004d32 <create+0x80>
    iunlockput(dp);
    80004da0:	8526                	mv	a0,s1
    80004da2:	fdefe0ef          	jal	80003580 <iunlockput>
    return 0;
    80004da6:	bfd5                	j	80004d9a <create+0xe8>
    if (dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80004da8:	004a2603          	lw	a2,4(s4)
    80004dac:	00003597          	auipc	a1,0x3
    80004db0:	87458593          	addi	a1,a1,-1932 # 80007620 <etext+0x620>
    80004db4:	8552                	mv	a0,s4
    80004db6:	d71fe0ef          	jal	80003b26 <dirlink>
    80004dba:	02054e63          	bltz	a0,80004df6 <create+0x144>
    80004dbe:	40d0                	lw	a2,4(s1)
    80004dc0:	00003597          	auipc	a1,0x3
    80004dc4:	86858593          	addi	a1,a1,-1944 # 80007628 <etext+0x628>
    80004dc8:	8552                	mv	a0,s4
    80004dca:	d5dfe0ef          	jal	80003b26 <dirlink>
    80004dce:	02054463          	bltz	a0,80004df6 <create+0x144>
  if (dirlink(dp, name, ip->inum) < 0)
    80004dd2:	004a2603          	lw	a2,4(s4)
    80004dd6:	fb040593          	addi	a1,s0,-80
    80004dda:	8526                	mv	a0,s1
    80004ddc:	d4bfe0ef          	jal	80003b26 <dirlink>
    80004de0:	00054b63          	bltz	a0,80004df6 <create+0x144>
    dp->nlink++; // for ".."
    80004de4:	04a4d783          	lhu	a5,74(s1)
    80004de8:	2785                	addiw	a5,a5,1
    80004dea:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004dee:	8526                	mv	a0,s1
    80004df0:	c88fe0ef          	jal	80003278 <iupdate>
    80004df4:	b745                	j	80004d94 <create+0xe2>
  ip->nlink = 0;
    80004df6:	040a1523          	sh	zero,74(s4)
  iupdate(ip);
    80004dfa:	8552                	mv	a0,s4
    80004dfc:	c7cfe0ef          	jal	80003278 <iupdate>
  iunlockput(ip);
    80004e00:	8552                	mv	a0,s4
    80004e02:	f7efe0ef          	jal	80003580 <iunlockput>
  iunlockput(dp);
    80004e06:	8526                	mv	a0,s1
    80004e08:	f78fe0ef          	jal	80003580 <iunlockput>
  return 0;
    80004e0c:	7a02                	ld	s4,32(sp)
    80004e0e:	b715                	j	80004d32 <create+0x80>

0000000080004e10 <sys_dup>:
{
    80004e10:	7179                	addi	sp,sp,-48
    80004e12:	f406                	sd	ra,40(sp)
    80004e14:	f022                	sd	s0,32(sp)
    80004e16:	1800                	addi	s0,sp,48
  if (argfd(0, 0, &f) < 0)
    80004e18:	fd840613          	addi	a2,s0,-40
    80004e1c:	4581                	li	a1,0
    80004e1e:	4501                	li	a0,0
    80004e20:	e01ff0ef          	jal	80004c20 <argfd>
    80004e24:	02054863          	bltz	a0,80004e54 <sys_dup+0x44>
    80004e28:	ec26                	sd	s1,24(sp)
    80004e2a:	e84a                	sd	s2,16(sp)
  if ((fd = fdalloc(f)) < 0)
    80004e2c:	fd843483          	ld	s1,-40(s0)
    80004e30:	8526                	mv	a0,s1
    80004e32:	e43ff0ef          	jal	80004c74 <fdalloc>
    80004e36:	892a                	mv	s2,a0
    80004e38:	00054c63          	bltz	a0,80004e50 <sys_dup+0x40>
  filedup(f);
    80004e3c:	8526                	mv	a0,s1
    80004e3e:	bf0ff0ef          	jal	8000422e <filedup>
  return fd;
    80004e42:	854a                	mv	a0,s2
    80004e44:	64e2                	ld	s1,24(sp)
    80004e46:	6942                	ld	s2,16(sp)
}
    80004e48:	70a2                	ld	ra,40(sp)
    80004e4a:	7402                	ld	s0,32(sp)
    80004e4c:	6145                	addi	sp,sp,48
    80004e4e:	8082                	ret
    80004e50:	64e2                	ld	s1,24(sp)
    80004e52:	6942                	ld	s2,16(sp)
    return -1;
    80004e54:	557d                	li	a0,-1
    80004e56:	bfcd                	j	80004e48 <sys_dup+0x38>

0000000080004e58 <sys_read>:
{
    80004e58:	7179                	addi	sp,sp,-48
    80004e5a:	f406                	sd	ra,40(sp)
    80004e5c:	f022                	sd	s0,32(sp)
    80004e5e:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004e60:	fd840593          	addi	a1,s0,-40
    80004e64:	4505                	li	a0,1
    80004e66:	b0bfd0ef          	jal	80002970 <argaddr>
  argint(2, &n);
    80004e6a:	fe440593          	addi	a1,s0,-28
    80004e6e:	4509                	li	a0,2
    80004e70:	ae5fd0ef          	jal	80002954 <argint>
  if (argfd(0, 0, &f) < 0)
    80004e74:	fe840613          	addi	a2,s0,-24
    80004e78:	4581                	li	a1,0
    80004e7a:	4501                	li	a0,0
    80004e7c:	da5ff0ef          	jal	80004c20 <argfd>
    80004e80:	87aa                	mv	a5,a0
    return -1;
    80004e82:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    80004e84:	0007ca63          	bltz	a5,80004e98 <sys_read+0x40>
  return fileread(f, p, n);
    80004e88:	fe442603          	lw	a2,-28(s0)
    80004e8c:	fd843583          	ld	a1,-40(s0)
    80004e90:	fe843503          	ld	a0,-24(s0)
    80004e94:	d08ff0ef          	jal	8000439c <fileread>
}
    80004e98:	70a2                	ld	ra,40(sp)
    80004e9a:	7402                	ld	s0,32(sp)
    80004e9c:	6145                	addi	sp,sp,48
    80004e9e:	8082                	ret

0000000080004ea0 <sys_write>:
{
    80004ea0:	7179                	addi	sp,sp,-48
    80004ea2:	f406                	sd	ra,40(sp)
    80004ea4:	f022                	sd	s0,32(sp)
    80004ea6:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004ea8:	fd840593          	addi	a1,s0,-40
    80004eac:	4505                	li	a0,1
    80004eae:	ac3fd0ef          	jal	80002970 <argaddr>
  argint(2, &n);
    80004eb2:	fe440593          	addi	a1,s0,-28
    80004eb6:	4509                	li	a0,2
    80004eb8:	a9dfd0ef          	jal	80002954 <argint>
  if (argfd(0, 0, &f) < 0)
    80004ebc:	fe840613          	addi	a2,s0,-24
    80004ec0:	4581                	li	a1,0
    80004ec2:	4501                	li	a0,0
    80004ec4:	d5dff0ef          	jal	80004c20 <argfd>
    80004ec8:	87aa                	mv	a5,a0
    return -1;
    80004eca:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    80004ecc:	0007ca63          	bltz	a5,80004ee0 <sys_write+0x40>
  return filewrite(f, p, n);
    80004ed0:	fe442603          	lw	a2,-28(s0)
    80004ed4:	fd843583          	ld	a1,-40(s0)
    80004ed8:	fe843503          	ld	a0,-24(s0)
    80004edc:	d84ff0ef          	jal	80004460 <filewrite>
}
    80004ee0:	70a2                	ld	ra,40(sp)
    80004ee2:	7402                	ld	s0,32(sp)
    80004ee4:	6145                	addi	sp,sp,48
    80004ee6:	8082                	ret

0000000080004ee8 <sys_close>:
{
    80004ee8:	1101                	addi	sp,sp,-32
    80004eea:	ec06                	sd	ra,24(sp)
    80004eec:	e822                	sd	s0,16(sp)
    80004eee:	1000                	addi	s0,sp,32
  if (argfd(0, &fd, &f) < 0)
    80004ef0:	fe040613          	addi	a2,s0,-32
    80004ef4:	fec40593          	addi	a1,s0,-20
    80004ef8:	4501                	li	a0,0
    80004efa:	d27ff0ef          	jal	80004c20 <argfd>
    return -1;
    80004efe:	57fd                	li	a5,-1
  if (argfd(0, &fd, &f) < 0)
    80004f00:	02054063          	bltz	a0,80004f20 <sys_close+0x38>
  myproc()->ofile[fd] = 0;
    80004f04:	a13fc0ef          	jal	80001916 <myproc>
    80004f08:	fec42783          	lw	a5,-20(s0)
    80004f0c:	07e9                	addi	a5,a5,26
    80004f0e:	078e                	slli	a5,a5,0x3
    80004f10:	953e                	add	a0,a0,a5
    80004f12:	00053023          	sd	zero,0(a0)
  fileclose(f);
    80004f16:	fe043503          	ld	a0,-32(s0)
    80004f1a:	b5aff0ef          	jal	80004274 <fileclose>
  return 0;
    80004f1e:	4781                	li	a5,0
}
    80004f20:	853e                	mv	a0,a5
    80004f22:	60e2                	ld	ra,24(sp)
    80004f24:	6442                	ld	s0,16(sp)
    80004f26:	6105                	addi	sp,sp,32
    80004f28:	8082                	ret

0000000080004f2a <sys_fstat>:
{
    80004f2a:	1101                	addi	sp,sp,-32
    80004f2c:	ec06                	sd	ra,24(sp)
    80004f2e:	e822                	sd	s0,16(sp)
    80004f30:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80004f32:	fe040593          	addi	a1,s0,-32
    80004f36:	4505                	li	a0,1
    80004f38:	a39fd0ef          	jal	80002970 <argaddr>
  if (argfd(0, 0, &f) < 0)
    80004f3c:	fe840613          	addi	a2,s0,-24
    80004f40:	4581                	li	a1,0
    80004f42:	4501                	li	a0,0
    80004f44:	cddff0ef          	jal	80004c20 <argfd>
    80004f48:	87aa                	mv	a5,a0
    return -1;
    80004f4a:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    80004f4c:	0007c863          	bltz	a5,80004f5c <sys_fstat+0x32>
  return filestat(f, st);
    80004f50:	fe043583          	ld	a1,-32(s0)
    80004f54:	fe843503          	ld	a0,-24(s0)
    80004f58:	bdeff0ef          	jal	80004336 <filestat>
}
    80004f5c:	60e2                	ld	ra,24(sp)
    80004f5e:	6442                	ld	s0,16(sp)
    80004f60:	6105                	addi	sp,sp,32
    80004f62:	8082                	ret

0000000080004f64 <sys_link>:
{
    80004f64:	7169                	addi	sp,sp,-304
    80004f66:	f606                	sd	ra,296(sp)
    80004f68:	f222                	sd	s0,288(sp)
    80004f6a:	1a00                	addi	s0,sp,304
  if (argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004f6c:	08000613          	li	a2,128
    80004f70:	ed040593          	addi	a1,s0,-304
    80004f74:	4501                	li	a0,0
    80004f76:	a17fd0ef          	jal	8000298c <argstr>
    80004f7a:	0e054c63          	bltz	a0,80005072 <sys_link+0x10e>
    80004f7e:	08000613          	li	a2,128
    80004f82:	f5040593          	addi	a1,s0,-176
    80004f86:	4505                	li	a0,1
    80004f88:	a05fd0ef          	jal	8000298c <argstr>
    80004f8c:	0e054363          	bltz	a0,80005072 <sys_link+0x10e>
    80004f90:	ee26                	sd	s1,280(sp)
  begin_op();
    80004f92:	e1dfe0ef          	jal	80003dae <begin_op>
  if ((ip = namei(old)) == 0) {
    80004f96:	ed040513          	addi	a0,s0,-304
    80004f9a:	c37fe0ef          	jal	80003bd0 <namei>
    80004f9e:	84aa                	mv	s1,a0
    80004fa0:	cd35                	beqz	a0,8000501c <sys_link+0xb8>
  ilock(ip);
    80004fa2:	b8afe0ef          	jal	8000332c <ilock>
  if (ip->type == T_DIR) {
    80004fa6:	04449703          	lh	a4,68(s1)
    80004faa:	4785                	li	a5,1
    80004fac:	06f70c63          	beq	a4,a5,80005024 <sys_link+0xc0>
  if (ip->nlink >= NLINK_MAX) {
    80004fb0:	04a49783          	lh	a5,74(s1)
    80004fb4:	6721                	lui	a4,0x8
    80004fb6:	177d                	addi	a4,a4,-1 # 7fff <_entry-0x7fff8001>
    80004fb8:	06e78d63          	beq	a5,a4,80005032 <sys_link+0xce>
    80004fbc:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    80004fbe:	2785                	addiw	a5,a5,1
    80004fc0:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004fc4:	8526                	mv	a0,s1
    80004fc6:	ab2fe0ef          	jal	80003278 <iupdate>
  iunlock(ip);
    80004fca:	8526                	mv	a0,s1
    80004fcc:	c0efe0ef          	jal	800033da <iunlock>
  if ((dp = nameiparent(new, name)) == 0)
    80004fd0:	fd040593          	addi	a1,s0,-48
    80004fd4:	f5040513          	addi	a0,s0,-176
    80004fd8:	c13fe0ef          	jal	80003bea <nameiparent>
    80004fdc:	892a                	mv	s2,a0
    80004fde:	c925                	beqz	a0,8000504e <sys_link+0xea>
  ilock(dp);
    80004fe0:	b4cfe0ef          	jal	8000332c <ilock>
  if (dp->nlink == 0) {
    80004fe4:	04a91783          	lh	a5,74(s2)
    80004fe8:	cfa1                	beqz	a5,80005040 <sys_link+0xdc>
  if (dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0) {
    80004fea:	854a                	mv	a0,s2
    80004fec:	00092703          	lw	a4,0(s2)
    80004ff0:	409c                	lw	a5,0(s1)
    80004ff2:	04f71b63          	bne	a4,a5,80005048 <sys_link+0xe4>
    80004ff6:	40d0                	lw	a2,4(s1)
    80004ff8:	fd040593          	addi	a1,s0,-48
    80004ffc:	b2bfe0ef          	jal	80003b26 <dirlink>
    80005000:	04054463          	bltz	a0,80005048 <sys_link+0xe4>
  iunlockput(dp);
    80005004:	854a                	mv	a0,s2
    80005006:	d7afe0ef          	jal	80003580 <iunlockput>
  iput(ip);
    8000500a:	8526                	mv	a0,s1
    8000500c:	ca2fe0ef          	jal	800034ae <iput>
  end_op();
    80005010:	e33fe0ef          	jal	80003e42 <end_op>
  return 0;
    80005014:	4501                	li	a0,0
    80005016:	64f2                	ld	s1,280(sp)
    80005018:	6952                	ld	s2,272(sp)
    8000501a:	a8a9                	j	80005074 <sys_link+0x110>
    end_op();
    8000501c:	e27fe0ef          	jal	80003e42 <end_op>
    return -1;
    80005020:	64f2                	ld	s1,280(sp)
    80005022:	a881                	j	80005072 <sys_link+0x10e>
    iunlockput(ip);
    80005024:	8526                	mv	a0,s1
    80005026:	d5afe0ef          	jal	80003580 <iunlockput>
    end_op();
    8000502a:	e19fe0ef          	jal	80003e42 <end_op>
    return -1;
    8000502e:	64f2                	ld	s1,280(sp)
    80005030:	a089                	j	80005072 <sys_link+0x10e>
    iunlockput(ip);
    80005032:	8526                	mv	a0,s1
    80005034:	d4cfe0ef          	jal	80003580 <iunlockput>
    end_op();
    80005038:	e0bfe0ef          	jal	80003e42 <end_op>
    return -1;
    8000503c:	64f2                	ld	s1,280(sp)
    8000503e:	a815                	j	80005072 <sys_link+0x10e>
    iunlockput(dp);
    80005040:	854a                	mv	a0,s2
    80005042:	d3efe0ef          	jal	80003580 <iunlockput>
    goto bad;
    80005046:	a021                	j	8000504e <sys_link+0xea>
    iunlockput(dp);
    80005048:	854a                	mv	a0,s2
    8000504a:	d36fe0ef          	jal	80003580 <iunlockput>
  ilock(ip);
    8000504e:	8526                	mv	a0,s1
    80005050:	adcfe0ef          	jal	8000332c <ilock>
  ip->nlink--;
    80005054:	04a4d783          	lhu	a5,74(s1)
    80005058:	37fd                	addiw	a5,a5,-1
    8000505a:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    8000505e:	8526                	mv	a0,s1
    80005060:	a18fe0ef          	jal	80003278 <iupdate>
  iunlockput(ip);
    80005064:	8526                	mv	a0,s1
    80005066:	d1afe0ef          	jal	80003580 <iunlockput>
  end_op();
    8000506a:	dd9fe0ef          	jal	80003e42 <end_op>
  return -1;
    8000506e:	64f2                	ld	s1,280(sp)
    80005070:	6952                	ld	s2,272(sp)
    return -1;
    80005072:	557d                	li	a0,-1
}
    80005074:	70b2                	ld	ra,296(sp)
    80005076:	7412                	ld	s0,288(sp)
    80005078:	6155                	addi	sp,sp,304
    8000507a:	8082                	ret

000000008000507c <sys_unlink>:
{
    8000507c:	7151                	addi	sp,sp,-240
    8000507e:	f586                	sd	ra,232(sp)
    80005080:	f1a2                	sd	s0,224(sp)
    80005082:	1980                	addi	s0,sp,240
  if (argstr(0, path, MAXPATH) < 0)
    80005084:	08000613          	li	a2,128
    80005088:	f3040593          	addi	a1,s0,-208
    8000508c:	4501                	li	a0,0
    8000508e:	8fffd0ef          	jal	8000298c <argstr>
    80005092:	14054763          	bltz	a0,800051e0 <sys_unlink+0x164>
    80005096:	eda6                	sd	s1,216(sp)
  begin_op();
    80005098:	d17fe0ef          	jal	80003dae <begin_op>
  if ((dp = nameiparent(path, name)) == 0) {
    8000509c:	fb040593          	addi	a1,s0,-80
    800050a0:	f3040513          	addi	a0,s0,-208
    800050a4:	b47fe0ef          	jal	80003bea <nameiparent>
    800050a8:	84aa                	mv	s1,a0
    800050aa:	c955                	beqz	a0,8000515e <sys_unlink+0xe2>
  ilock(dp);
    800050ac:	a80fe0ef          	jal	8000332c <ilock>
  if (namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    800050b0:	00002597          	auipc	a1,0x2
    800050b4:	57058593          	addi	a1,a1,1392 # 80007620 <etext+0x620>
    800050b8:	fb040513          	addi	a0,s0,-80
    800050bc:	845fe0ef          	jal	80003900 <namecmp>
    800050c0:	10050a63          	beqz	a0,800051d4 <sys_unlink+0x158>
    800050c4:	00002597          	auipc	a1,0x2
    800050c8:	56458593          	addi	a1,a1,1380 # 80007628 <etext+0x628>
    800050cc:	fb040513          	addi	a0,s0,-80
    800050d0:	831fe0ef          	jal	80003900 <namecmp>
    800050d4:	10050063          	beqz	a0,800051d4 <sys_unlink+0x158>
    800050d8:	e9ca                	sd	s2,208(sp)
  if ((ip = dirlookup(dp, name, &off)) == 0)
    800050da:	f2c40613          	addi	a2,s0,-212
    800050de:	fb040593          	addi	a1,s0,-80
    800050e2:	8526                	mv	a0,s1
    800050e4:	833fe0ef          	jal	80003916 <dirlookup>
    800050e8:	892a                	mv	s2,a0
    800050ea:	0e050463          	beqz	a0,800051d2 <sys_unlink+0x156>
    800050ee:	e5ce                	sd	s3,200(sp)
  ilock(ip);
    800050f0:	a3cfe0ef          	jal	8000332c <ilock>
  if (ip->nlink < 1)
    800050f4:	04a91783          	lh	a5,74(s2)
    800050f8:	06f05763          	blez	a5,80005166 <sys_unlink+0xea>
  if (ip->type == T_DIR && !isdirempty(ip)) {
    800050fc:	04491703          	lh	a4,68(s2)
    80005100:	4785                	li	a5,1
    80005102:	06f70863          	beq	a4,a5,80005172 <sys_unlink+0xf6>
  memset(&de, 0, sizeof(de));
    80005106:	fc040993          	addi	s3,s0,-64
    8000510a:	4641                	li	a2,16
    8000510c:	4581                	li	a1,0
    8000510e:	854e                	mv	a0,s3
    80005110:	bd9fb0ef          	jal	80000ce8 <memset>
  if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80005114:	4741                	li	a4,16
    80005116:	f2c42683          	lw	a3,-212(s0)
    8000511a:	864e                	mv	a2,s3
    8000511c:	4581                	li	a1,0
    8000511e:	8526                	mv	a0,s1
    80005120:	ed8fe0ef          	jal	800037f8 <writei>
    80005124:	47c1                	li	a5,16
    80005126:	08f51763          	bne	a0,a5,800051b4 <sys_unlink+0x138>
  if (ip->type == T_DIR) {
    8000512a:	04491703          	lh	a4,68(s2)
    8000512e:	4785                	li	a5,1
    80005130:	08f70863          	beq	a4,a5,800051c0 <sys_unlink+0x144>
  iunlockput(dp);
    80005134:	8526                	mv	a0,s1
    80005136:	c4afe0ef          	jal	80003580 <iunlockput>
  ip->nlink--;
    8000513a:	04a95783          	lhu	a5,74(s2)
    8000513e:	37fd                	addiw	a5,a5,-1
    80005140:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80005144:	854a                	mv	a0,s2
    80005146:	932fe0ef          	jal	80003278 <iupdate>
  iunlockput(ip);
    8000514a:	854a                	mv	a0,s2
    8000514c:	c34fe0ef          	jal	80003580 <iunlockput>
  end_op();
    80005150:	cf3fe0ef          	jal	80003e42 <end_op>
  return 0;
    80005154:	4501                	li	a0,0
    80005156:	64ee                	ld	s1,216(sp)
    80005158:	694e                	ld	s2,208(sp)
    8000515a:	69ae                	ld	s3,200(sp)
    8000515c:	a059                	j	800051e2 <sys_unlink+0x166>
    end_op();
    8000515e:	ce5fe0ef          	jal	80003e42 <end_op>
    return -1;
    80005162:	64ee                	ld	s1,216(sp)
    80005164:	a8b5                	j	800051e0 <sys_unlink+0x164>
    panic("unlink: nlink < 1");
    80005166:	00002517          	auipc	a0,0x2
    8000516a:	4ca50513          	addi	a0,a0,1226 # 80007630 <etext+0x630>
    8000516e:	ec4fb0ef          	jal	80000832 <panic>
  for (off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    80005172:	04c92703          	lw	a4,76(s2)
    80005176:	02000793          	li	a5,32
    8000517a:	f8e7f6e3          	bgeu	a5,a4,80005106 <sys_unlink+0x8a>
    8000517e:	89be                	mv	s3,a5
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80005180:	4741                	li	a4,16
    80005182:	86ce                	mv	a3,s3
    80005184:	f1840613          	addi	a2,s0,-232
    80005188:	4581                	li	a1,0
    8000518a:	854a                	mv	a0,s2
    8000518c:	d7afe0ef          	jal	80003706 <readi>
    80005190:	47c1                	li	a5,16
    80005192:	00f51b63          	bne	a0,a5,800051a8 <sys_unlink+0x12c>
    if (de.inum != 0)
    80005196:	f1845783          	lhu	a5,-232(s0)
    8000519a:	eba1                	bnez	a5,800051ea <sys_unlink+0x16e>
  for (off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    8000519c:	29c1                	addiw	s3,s3,16
    8000519e:	04c92783          	lw	a5,76(s2)
    800051a2:	fcf9efe3          	bltu	s3,a5,80005180 <sys_unlink+0x104>
    800051a6:	b785                	j	80005106 <sys_unlink+0x8a>
      panic("isdirempty: readi");
    800051a8:	00002517          	auipc	a0,0x2
    800051ac:	4a050513          	addi	a0,a0,1184 # 80007648 <etext+0x648>
    800051b0:	e82fb0ef          	jal	80000832 <panic>
    panic("unlink: writei");
    800051b4:	00002517          	auipc	a0,0x2
    800051b8:	4ac50513          	addi	a0,a0,1196 # 80007660 <etext+0x660>
    800051bc:	e76fb0ef          	jal	80000832 <panic>
    dp->nlink--;
    800051c0:	04a4d783          	lhu	a5,74(s1)
    800051c4:	37fd                	addiw	a5,a5,-1
    800051c6:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    800051ca:	8526                	mv	a0,s1
    800051cc:	8acfe0ef          	jal	80003278 <iupdate>
    800051d0:	b795                	j	80005134 <sys_unlink+0xb8>
    800051d2:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    800051d4:	8526                	mv	a0,s1
    800051d6:	baafe0ef          	jal	80003580 <iunlockput>
  end_op();
    800051da:	c69fe0ef          	jal	80003e42 <end_op>
  return -1;
    800051de:	64ee                	ld	s1,216(sp)
    return -1;
    800051e0:	557d                	li	a0,-1
}
    800051e2:	70ae                	ld	ra,232(sp)
    800051e4:	740e                	ld	s0,224(sp)
    800051e6:	616d                	addi	sp,sp,240
    800051e8:	8082                	ret
    iunlockput(ip);
    800051ea:	854a                	mv	a0,s2
    800051ec:	b94fe0ef          	jal	80003580 <iunlockput>
    goto bad;
    800051f0:	694e                	ld	s2,208(sp)
    800051f2:	69ae                	ld	s3,200(sp)
    800051f4:	b7c5                	j	800051d4 <sys_unlink+0x158>

00000000800051f6 <sys_open>:

uint64
sys_open(void)
{
    800051f6:	7131                	addi	sp,sp,-192
    800051f8:	fd06                	sd	ra,184(sp)
    800051fa:	f922                	sd	s0,176(sp)
    800051fc:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    800051fe:	f4c40593          	addi	a1,s0,-180
    80005202:	4505                	li	a0,1
    80005204:	f50fd0ef          	jal	80002954 <argint>
  if ((n = argstr(0, path, MAXPATH)) < 0)
    80005208:	08000613          	li	a2,128
    8000520c:	f5040593          	addi	a1,s0,-176
    80005210:	4501                	li	a0,0
    80005212:	f7afd0ef          	jal	8000298c <argstr>
    80005216:	10054563          	bltz	a0,80005320 <sys_open+0x12a>
    8000521a:	f526                	sd	s1,168(sp)
    return -1;

  begin_op();
    8000521c:	b93fe0ef          	jal	80003dae <begin_op>

  if (omode & O_CREATE) {
    80005220:	f4c42783          	lw	a5,-180(s0)
    80005224:	2007f793          	andi	a5,a5,512
    80005228:	cfd9                	beqz	a5,800052c6 <sys_open+0xd0>
    ip = create(path, T_FILE, 0, 0);
    8000522a:	4681                	li	a3,0
    8000522c:	4601                	li	a2,0
    8000522e:	4589                	li	a1,2
    80005230:	f5040513          	addi	a0,s0,-176
    80005234:	a7fff0ef          	jal	80004cb2 <create>
    80005238:	84aa                	mv	s1,a0
    if (ip == 0) {
    8000523a:	c151                	beqz	a0,800052be <sys_open+0xc8>
      end_op();
      return -1;
    }
  }

  if (ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)) {
    8000523c:	04449703          	lh	a4,68(s1)
    80005240:	478d                	li	a5,3
    80005242:	00f71763          	bne	a4,a5,80005250 <sys_open+0x5a>
    80005246:	0464d703          	lhu	a4,70(s1)
    8000524a:	47a5                	li	a5,9
    8000524c:	0ae7e863          	bltu	a5,a4,800052fc <sys_open+0x106>
    80005250:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if ((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0) {
    80005252:	f7ffe0ef          	jal	800041d0 <filealloc>
    80005256:	892a                	mv	s2,a0
    80005258:	cd4d                	beqz	a0,80005312 <sys_open+0x11c>
    8000525a:	ed4e                	sd	s3,152(sp)
    8000525c:	a19ff0ef          	jal	80004c74 <fdalloc>
    80005260:	89aa                	mv	s3,a0
    80005262:	0a054463          	bltz	a0,8000530a <sys_open+0x114>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if (ip->type == T_DEVICE) {
    80005266:	04449703          	lh	a4,68(s1)
    8000526a:	478d                	li	a5,3
    8000526c:	0af70f63          	beq	a4,a5,8000532a <sys_open+0x134>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    80005270:	4789                	li	a5,2
    80005272:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    80005276:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    8000527a:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    8000527e:	f4c42783          	lw	a5,-180(s0)
    80005282:	0017f713          	andi	a4,a5,1
    80005286:	00174713          	xori	a4,a4,1
    8000528a:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    8000528e:	0037f713          	andi	a4,a5,3
    80005292:	00e03733          	snez	a4,a4
    80005296:	00e904a3          	sb	a4,9(s2)

  if ((omode & O_TRUNC) && ip->type == T_FILE) {
    8000529a:	4007f793          	andi	a5,a5,1024
    8000529e:	c791                	beqz	a5,800052aa <sys_open+0xb4>
    800052a0:	04449703          	lh	a4,68(s1)
    800052a4:	4789                	li	a5,2
    800052a6:	08f70963          	beq	a4,a5,80005338 <sys_open+0x142>
    itrunc(ip);
  }

  iunlock(ip);
    800052aa:	8526                	mv	a0,s1
    800052ac:	92efe0ef          	jal	800033da <iunlock>
  end_op();
    800052b0:	b93fe0ef          	jal	80003e42 <end_op>

  return fd;
    800052b4:	854e                	mv	a0,s3
    800052b6:	74aa                	ld	s1,168(sp)
    800052b8:	790a                	ld	s2,160(sp)
    800052ba:	69ea                	ld	s3,152(sp)
    800052bc:	a09d                	j	80005322 <sys_open+0x12c>
      end_op();
    800052be:	b85fe0ef          	jal	80003e42 <end_op>
      return -1;
    800052c2:	74aa                	ld	s1,168(sp)
    800052c4:	a8b1                	j	80005320 <sys_open+0x12a>
    if ((ip = namei(path)) == 0) {
    800052c6:	f5040513          	addi	a0,s0,-176
    800052ca:	907fe0ef          	jal	80003bd0 <namei>
    800052ce:	84aa                	mv	s1,a0
    800052d0:	c115                	beqz	a0,800052f4 <sys_open+0xfe>
    ilock(ip);
    800052d2:	85afe0ef          	jal	8000332c <ilock>
    if (ip->type == T_DIR && omode != O_RDONLY) {
    800052d6:	04449703          	lh	a4,68(s1)
    800052da:	4785                	li	a5,1
    800052dc:	f6f710e3          	bne	a4,a5,8000523c <sys_open+0x46>
    800052e0:	f4c42783          	lw	a5,-180(s0)
    800052e4:	d7b5                	beqz	a5,80005250 <sys_open+0x5a>
      iunlockput(ip);
    800052e6:	8526                	mv	a0,s1
    800052e8:	a98fe0ef          	jal	80003580 <iunlockput>
      end_op();
    800052ec:	b57fe0ef          	jal	80003e42 <end_op>
      return -1;
    800052f0:	74aa                	ld	s1,168(sp)
    800052f2:	a03d                	j	80005320 <sys_open+0x12a>
      end_op();
    800052f4:	b4ffe0ef          	jal	80003e42 <end_op>
      return -1;
    800052f8:	74aa                	ld	s1,168(sp)
    800052fa:	a01d                	j	80005320 <sys_open+0x12a>
    iunlockput(ip);
    800052fc:	8526                	mv	a0,s1
    800052fe:	a82fe0ef          	jal	80003580 <iunlockput>
    end_op();
    80005302:	b41fe0ef          	jal	80003e42 <end_op>
    return -1;
    80005306:	74aa                	ld	s1,168(sp)
    80005308:	a821                	j	80005320 <sys_open+0x12a>
      fileclose(f);
    8000530a:	854a                	mv	a0,s2
    8000530c:	f69fe0ef          	jal	80004274 <fileclose>
    80005310:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    80005312:	8526                	mv	a0,s1
    80005314:	a6cfe0ef          	jal	80003580 <iunlockput>
    end_op();
    80005318:	b2bfe0ef          	jal	80003e42 <end_op>
    return -1;
    8000531c:	74aa                	ld	s1,168(sp)
    8000531e:	790a                	ld	s2,160(sp)
    return -1;
    80005320:	557d                	li	a0,-1
}
    80005322:	70ea                	ld	ra,184(sp)
    80005324:	744a                	ld	s0,176(sp)
    80005326:	6129                	addi	sp,sp,192
    80005328:	8082                	ret
    f->type = FD_DEVICE;
    8000532a:	00e92023          	sw	a4,0(s2)
    f->major = ip->major;
    8000532e:	04649783          	lh	a5,70(s1)
    80005332:	02f91223          	sh	a5,36(s2)
    80005336:	b791                	j	8000527a <sys_open+0x84>
    itrunc(ip);
    80005338:	8526                	mv	a0,s1
    8000533a:	8e0fe0ef          	jal	8000341a <itrunc>
    8000533e:	b7b5                	j	800052aa <sys_open+0xb4>

0000000080005340 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    80005340:	7175                	addi	sp,sp,-144
    80005342:	e506                	sd	ra,136(sp)
    80005344:	e122                	sd	s0,128(sp)
    80005346:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    80005348:	a67fe0ef          	jal	80003dae <begin_op>
  if (argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0) {
    8000534c:	08000613          	li	a2,128
    80005350:	f7040593          	addi	a1,s0,-144
    80005354:	4501                	li	a0,0
    80005356:	e36fd0ef          	jal	8000298c <argstr>
    8000535a:	02054363          	bltz	a0,80005380 <sys_mkdir+0x40>
    8000535e:	4681                	li	a3,0
    80005360:	4601                	li	a2,0
    80005362:	4585                	li	a1,1
    80005364:	f7040513          	addi	a0,s0,-144
    80005368:	94bff0ef          	jal	80004cb2 <create>
    8000536c:	c911                	beqz	a0,80005380 <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    8000536e:	a12fe0ef          	jal	80003580 <iunlockput>
  end_op();
    80005372:	ad1fe0ef          	jal	80003e42 <end_op>
  return 0;
    80005376:	4501                	li	a0,0
}
    80005378:	60aa                	ld	ra,136(sp)
    8000537a:	640a                	ld	s0,128(sp)
    8000537c:	6149                	addi	sp,sp,144
    8000537e:	8082                	ret
    end_op();
    80005380:	ac3fe0ef          	jal	80003e42 <end_op>
    return -1;
    80005384:	557d                	li	a0,-1
    80005386:	bfcd                	j	80005378 <sys_mkdir+0x38>

0000000080005388 <sys_mknod>:

uint64
sys_mknod(void)
{
    80005388:	7135                	addi	sp,sp,-160
    8000538a:	ed06                	sd	ra,152(sp)
    8000538c:	e922                	sd	s0,144(sp)
    8000538e:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    80005390:	a1ffe0ef          	jal	80003dae <begin_op>
  argint(1, &major);
    80005394:	f6c40593          	addi	a1,s0,-148
    80005398:	4505                	li	a0,1
    8000539a:	dbafd0ef          	jal	80002954 <argint>
  argint(2, &minor);
    8000539e:	f6840593          	addi	a1,s0,-152
    800053a2:	4509                	li	a0,2
    800053a4:	db0fd0ef          	jal	80002954 <argint>
  if ((argstr(0, path, MAXPATH)) < 0 ||
    800053a8:	08000613          	li	a2,128
    800053ac:	f7040593          	addi	a1,s0,-144
    800053b0:	4501                	li	a0,0
    800053b2:	ddafd0ef          	jal	8000298c <argstr>
    800053b6:	02054563          	bltz	a0,800053e0 <sys_mknod+0x58>
      (ip = create(path, T_DEVICE, major, minor)) == 0) {
    800053ba:	f6841683          	lh	a3,-152(s0)
    800053be:	f6c41603          	lh	a2,-148(s0)
    800053c2:	458d                	li	a1,3
    800053c4:	f7040513          	addi	a0,s0,-144
    800053c8:	8ebff0ef          	jal	80004cb2 <create>
  if ((argstr(0, path, MAXPATH)) < 0 ||
    800053cc:	c911                	beqz	a0,800053e0 <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    800053ce:	9b2fe0ef          	jal	80003580 <iunlockput>
  end_op();
    800053d2:	a71fe0ef          	jal	80003e42 <end_op>
  return 0;
    800053d6:	4501                	li	a0,0
}
    800053d8:	60ea                	ld	ra,152(sp)
    800053da:	644a                	ld	s0,144(sp)
    800053dc:	610d                	addi	sp,sp,160
    800053de:	8082                	ret
    end_op();
    800053e0:	a63fe0ef          	jal	80003e42 <end_op>
    return -1;
    800053e4:	557d                	li	a0,-1
    800053e6:	bfcd                	j	800053d8 <sys_mknod+0x50>

00000000800053e8 <sys_chdir>:

uint64
sys_chdir(void)
{
    800053e8:	7135                	addi	sp,sp,-160
    800053ea:	ed06                	sd	ra,152(sp)
    800053ec:	e922                	sd	s0,144(sp)
    800053ee:	e14a                	sd	s2,128(sp)
    800053f0:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    800053f2:	d24fc0ef          	jal	80001916 <myproc>
    800053f6:	892a                	mv	s2,a0

  begin_op();
    800053f8:	9b7fe0ef          	jal	80003dae <begin_op>
  if (argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0) {
    800053fc:	08000613          	li	a2,128
    80005400:	f6040593          	addi	a1,s0,-160
    80005404:	4501                	li	a0,0
    80005406:	d86fd0ef          	jal	8000298c <argstr>
    8000540a:	02054f63          	bltz	a0,80005448 <sys_chdir+0x60>
    8000540e:	e526                	sd	s1,136(sp)
    80005410:	f6040513          	addi	a0,s0,-160
    80005414:	fbcfe0ef          	jal	80003bd0 <namei>
    80005418:	84aa                	mv	s1,a0
    8000541a:	c515                	beqz	a0,80005446 <sys_chdir+0x5e>
    end_op();
    return -1;
  }
  ilock(ip);
    8000541c:	f11fd0ef          	jal	8000332c <ilock>
  if (ip->type != T_DIR) {
    80005420:	04449703          	lh	a4,68(s1)
    80005424:	4785                	li	a5,1
    80005426:	02f71963          	bne	a4,a5,80005458 <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    8000542a:	8526                	mv	a0,s1
    8000542c:	faffd0ef          	jal	800033da <iunlock>
  iput(p->cwd);
    80005430:	15093503          	ld	a0,336(s2)
    80005434:	87afe0ef          	jal	800034ae <iput>
  end_op();
    80005438:	a0bfe0ef          	jal	80003e42 <end_op>
  p->cwd = ip;
    8000543c:	14993823          	sd	s1,336(s2)
  return 0;
    80005440:	4501                	li	a0,0
    80005442:	64aa                	ld	s1,136(sp)
    80005444:	a029                	j	8000544e <sys_chdir+0x66>
    80005446:	64aa                	ld	s1,136(sp)
    end_op();
    80005448:	9fbfe0ef          	jal	80003e42 <end_op>
    return -1;
    8000544c:	557d                	li	a0,-1
}
    8000544e:	60ea                	ld	ra,152(sp)
    80005450:	644a                	ld	s0,144(sp)
    80005452:	690a                	ld	s2,128(sp)
    80005454:	610d                	addi	sp,sp,160
    80005456:	8082                	ret
    iunlockput(ip);
    80005458:	8526                	mv	a0,s1
    8000545a:	926fe0ef          	jal	80003580 <iunlockput>
    end_op();
    8000545e:	9e5fe0ef          	jal	80003e42 <end_op>
    return -1;
    80005462:	64aa                	ld	s1,136(sp)
    80005464:	b7e5                	j	8000544c <sys_chdir+0x64>

0000000080005466 <sys_exec>:

uint64
sys_exec(void)
{
    80005466:	7105                	addi	sp,sp,-480
    80005468:	ef86                	sd	ra,472(sp)
    8000546a:	eba2                	sd	s0,464(sp)
    8000546c:	1380                	addi	s0,sp,480
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    8000546e:	e2840593          	addi	a1,s0,-472
    80005472:	4505                	li	a0,1
    80005474:	cfcfd0ef          	jal	80002970 <argaddr>
  if (argstr(0, path, MAXPATH) < 0) {
    80005478:	08000613          	li	a2,128
    8000547c:	f3040593          	addi	a1,s0,-208
    80005480:	4501                	li	a0,0
    80005482:	d0afd0ef          	jal	8000298c <argstr>
    80005486:	0c054e63          	bltz	a0,80005562 <sys_exec+0xfc>
    8000548a:	e7a6                	sd	s1,456(sp)
    8000548c:	e3ca                	sd	s2,448(sp)
    8000548e:	ff4e                	sd	s3,440(sp)
    80005490:	fb52                	sd	s4,432(sp)
    80005492:	f756                	sd	s5,424(sp)
    80005494:	f35a                	sd	s6,416(sp)
    80005496:	ef5e                	sd	s7,408(sp)
    return -1;
  }
  memset(argv, 0, sizeof(argv));
    80005498:	e3040a13          	addi	s4,s0,-464
    8000549c:	10000613          	li	a2,256
    800054a0:	4581                	li	a1,0
    800054a2:	8552                	mv	a0,s4
    800054a4:	845fb0ef          	jal	80000ce8 <memset>
  for (i = 0;; i++) {
    if (i >= NELEM(argv)) {
    800054a8:	84d2                	mv	s1,s4
  memset(argv, 0, sizeof(argv));
    800054aa:	89d2                	mv	s3,s4
    800054ac:	4901                	li	s2,0
      goto bad;
    }
    if (fetchaddr(uargv + sizeof(uint64) * i, (uint64 *)&uarg) < 0) {
    800054ae:	e2040a93          	addi	s5,s0,-480
      break;
    }
    argv[i] = kalloc();
    if (argv[i] == 0)
      goto bad;
    if (fetchstr(uarg, argv[i], PGSIZE) < 0)
    800054b2:	6b05                	lui	s6,0x1
    if (i >= NELEM(argv)) {
    800054b4:	02000b93          	li	s7,32
    if (fetchaddr(uargv + sizeof(uint64) * i, (uint64 *)&uarg) < 0) {
    800054b8:	00391513          	slli	a0,s2,0x3
    800054bc:	85d6                	mv	a1,s5
    800054be:	e2843783          	ld	a5,-472(s0)
    800054c2:	953e                	add	a0,a0,a5
    800054c4:	c08fd0ef          	jal	800028cc <fetchaddr>
    800054c8:	02054663          	bltz	a0,800054f4 <sys_exec+0x8e>
    if (uarg == 0) {
    800054cc:	e2043783          	ld	a5,-480(s0)
    800054d0:	c3b9                	beqz	a5,80005516 <sys_exec+0xb0>
    argv[i] = kalloc();
    800054d2:	e64fb0ef          	jal	80000b36 <kalloc>
    800054d6:	85aa                	mv	a1,a0
    800054d8:	00a9b023          	sd	a0,0(s3)
    if (argv[i] == 0)
    800054dc:	cd01                	beqz	a0,800054f4 <sys_exec+0x8e>
    if (fetchstr(uarg, argv[i], PGSIZE) < 0)
    800054de:	865a                	mv	a2,s6
    800054e0:	e2043503          	ld	a0,-480(s0)
    800054e4:	c2efd0ef          	jal	80002912 <fetchstr>
    800054e8:	00054663          	bltz	a0,800054f4 <sys_exec+0x8e>
    if (i >= NELEM(argv)) {
    800054ec:	0905                	addi	s2,s2,1
    800054ee:	09a1                	addi	s3,s3,8
    800054f0:	fd7914e3          	bne	s2,s7,800054b8 <sys_exec+0x52>
    kfree(argv[i]);

  return ret;

bad:
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800054f4:	100a0a13          	addi	s4,s4,256
    800054f8:	6088                	ld	a0,0(s1)
    800054fa:	cd29                	beqz	a0,80005554 <sys_exec+0xee>
    kfree(argv[i]);
    800054fc:	d52fb0ef          	jal	80000a4e <kfree>
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005500:	04a1                	addi	s1,s1,8
    80005502:	ff449be3          	bne	s1,s4,800054f8 <sys_exec+0x92>
    80005506:	64be                	ld	s1,456(sp)
    80005508:	691e                	ld	s2,448(sp)
    8000550a:	79fa                	ld	s3,440(sp)
    8000550c:	7a5a                	ld	s4,432(sp)
    8000550e:	7aba                	ld	s5,424(sp)
    80005510:	7b1a                	ld	s6,416(sp)
    80005512:	6bfa                	ld	s7,408(sp)
    80005514:	a0b9                	j	80005562 <sys_exec+0xfc>
      argv[i] = 0;
    80005516:	0009079b          	sext.w	a5,s2
    8000551a:	e3040593          	addi	a1,s0,-464
    8000551e:	078e                	slli	a5,a5,0x3
    80005520:	97ae                	add	a5,a5,a1
    80005522:	0007b023          	sd	zero,0(a5)
  int ret = kexec(path, argv);
    80005526:	f3040513          	addi	a0,s0,-208
    8000552a:	bdeff0ef          	jal	80004908 <kexec>
    8000552e:	892a                	mv	s2,a0
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005530:	100a0a13          	addi	s4,s4,256
    80005534:	6088                	ld	a0,0(s1)
    80005536:	c511                	beqz	a0,80005542 <sys_exec+0xdc>
    kfree(argv[i]);
    80005538:	d16fb0ef          	jal	80000a4e <kfree>
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    8000553c:	04a1                	addi	s1,s1,8
    8000553e:	ff449be3          	bne	s1,s4,80005534 <sys_exec+0xce>
  return ret;
    80005542:	854a                	mv	a0,s2
    80005544:	64be                	ld	s1,456(sp)
    80005546:	691e                	ld	s2,448(sp)
    80005548:	79fa                	ld	s3,440(sp)
    8000554a:	7a5a                	ld	s4,432(sp)
    8000554c:	7aba                	ld	s5,424(sp)
    8000554e:	7b1a                	ld	s6,416(sp)
    80005550:	6bfa                	ld	s7,408(sp)
    80005552:	a809                	j	80005564 <sys_exec+0xfe>
    80005554:	64be                	ld	s1,456(sp)
    80005556:	691e                	ld	s2,448(sp)
    80005558:	79fa                	ld	s3,440(sp)
    8000555a:	7a5a                	ld	s4,432(sp)
    8000555c:	7aba                	ld	s5,424(sp)
    8000555e:	7b1a                	ld	s6,416(sp)
    80005560:	6bfa                	ld	s7,408(sp)
    return -1;
    80005562:	557d                	li	a0,-1
  return -1;
}
    80005564:	60fe                	ld	ra,472(sp)
    80005566:	645e                	ld	s0,464(sp)
    80005568:	613d                	addi	sp,sp,480
    8000556a:	8082                	ret

000000008000556c <sys_pipe>:

uint64
sys_pipe(void)
{
    8000556c:	7139                	addi	sp,sp,-64
    8000556e:	fc06                	sd	ra,56(sp)
    80005570:	f822                	sd	s0,48(sp)
    80005572:	f426                	sd	s1,40(sp)
    80005574:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    80005576:	ba0fc0ef          	jal	80001916 <myproc>
    8000557a:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    8000557c:	fd840593          	addi	a1,s0,-40
    80005580:	4501                	li	a0,0
    80005582:	beefd0ef          	jal	80002970 <argaddr>
  if (pipealloc(&rf, &wf) < 0)
    80005586:	fc840593          	addi	a1,s0,-56
    8000558a:	fd040513          	addi	a0,s0,-48
    8000558e:	80aff0ef          	jal	80004598 <pipealloc>
    80005592:	0a054663          	bltz	a0,8000563e <sys_pipe+0xd2>
    return -1;
  fd0 = -1;
    80005596:	57fd                	li	a5,-1
    80005598:	fcf42223          	sw	a5,-60(s0)
  if ((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0) {
    8000559c:	fd043503          	ld	a0,-48(s0)
    800055a0:	ed4ff0ef          	jal	80004c74 <fdalloc>
    800055a4:	fca42223          	sw	a0,-60(s0)
    800055a8:	08054363          	bltz	a0,8000562e <sys_pipe+0xc2>
    800055ac:	fc843503          	ld	a0,-56(s0)
    800055b0:	ec4ff0ef          	jal	80004c74 <fdalloc>
    800055b4:	fca42023          	sw	a0,-64(s0)
    800055b8:	06054263          	bltz	a0,8000561c <sys_pipe+0xb0>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if (copyout(p->pagetable, p->sz, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    800055bc:	4711                	li	a4,4
    800055be:	fc440693          	addi	a3,s0,-60
    800055c2:	fd843603          	ld	a2,-40(s0)
    800055c6:	64ac                	ld	a1,72(s1)
    800055c8:	68a8                	ld	a0,80(s1)
    800055ca:	f97fb0ef          	jal	80001560 <copyout>
    800055ce:	02054063          	bltz	a0,800055ee <sys_pipe+0x82>
      copyout(p->pagetable, p->sz, fdarray + sizeof(fd0), (char *)&fd1,
    800055d2:	4711                	li	a4,4
    800055d4:	fc040693          	addi	a3,s0,-64
    800055d8:	fd843603          	ld	a2,-40(s0)
    800055dc:	963a                	add	a2,a2,a4
    800055de:	64ac                	ld	a1,72(s1)
    800055e0:	68a8                	ld	a0,80(s1)
    800055e2:	f7ffb0ef          	jal	80001560 <copyout>
    800055e6:	87aa                	mv	a5,a0
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    800055e8:	4501                	li	a0,0
  if (copyout(p->pagetable, p->sz, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    800055ea:	0407db63          	bgez	a5,80005640 <sys_pipe+0xd4>
    p->ofile[fd0] = 0;
    800055ee:	fc442783          	lw	a5,-60(s0)
    800055f2:	07e9                	addi	a5,a5,26
    800055f4:	078e                	slli	a5,a5,0x3
    800055f6:	97a6                	add	a5,a5,s1
    800055f8:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    800055fc:	fc042783          	lw	a5,-64(s0)
    80005600:	07e9                	addi	a5,a5,26
    80005602:	078e                	slli	a5,a5,0x3
    80005604:	94be                	add	s1,s1,a5
    80005606:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    8000560a:	fd043503          	ld	a0,-48(s0)
    8000560e:	c67fe0ef          	jal	80004274 <fileclose>
    fileclose(wf);
    80005612:	fc843503          	ld	a0,-56(s0)
    80005616:	c5ffe0ef          	jal	80004274 <fileclose>
    return -1;
    8000561a:	a015                	j	8000563e <sys_pipe+0xd2>
    if (fd0 >= 0)
    8000561c:	fc442783          	lw	a5,-60(s0)
    80005620:	0007c763          	bltz	a5,8000562e <sys_pipe+0xc2>
      p->ofile[fd0] = 0;
    80005624:	07e9                	addi	a5,a5,26
    80005626:	078e                	slli	a5,a5,0x3
    80005628:	97a6                	add	a5,a5,s1
    8000562a:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    8000562e:	fd043503          	ld	a0,-48(s0)
    80005632:	c43fe0ef          	jal	80004274 <fileclose>
    fileclose(wf);
    80005636:	fc843503          	ld	a0,-56(s0)
    8000563a:	c3bfe0ef          	jal	80004274 <fileclose>
    return -1;
    8000563e:	557d                	li	a0,-1
}
    80005640:	70e2                	ld	ra,56(sp)
    80005642:	7442                	ld	s0,48(sp)
    80005644:	74a2                	ld	s1,40(sp)
    80005646:	6121                	addi	sp,sp,64
    80005648:	8082                	ret
    8000564a:	0000                	unimp
    8000564c:	0000                	unimp
	...

0000000080005650 <kernelvec>:
.globl kerneltrap
.globl kernelvec
.align 4
kernelvec:
        # make room to save registers.
        addi sp, sp, -256
    80005650:	7111                	addi	sp,sp,-256

        # save caller-saved registers.
        sd ra, 0(sp)
    80005652:	e006                	sd	ra,0(sp)
        # sd sp, 8(sp)
        sd gp, 16(sp)
    80005654:	e80e                	sd	gp,16(sp)
        # sd tp, 24(sp)
        sd t0, 32(sp)
    80005656:	f016                	sd	t0,32(sp)
        sd t1, 40(sp)
    80005658:	f41a                	sd	t1,40(sp)
        sd t2, 48(sp)
    8000565a:	f81e                	sd	t2,48(sp)
        sd a0, 72(sp)
    8000565c:	e4aa                	sd	a0,72(sp)
        sd a1, 80(sp)
    8000565e:	e8ae                	sd	a1,80(sp)
        sd a2, 88(sp)
    80005660:	ecb2                	sd	a2,88(sp)
        sd a3, 96(sp)
    80005662:	f0b6                	sd	a3,96(sp)
        sd a4, 104(sp)
    80005664:	f4ba                	sd	a4,104(sp)
        sd a5, 112(sp)
    80005666:	f8be                	sd	a5,112(sp)
        sd a6, 120(sp)
    80005668:	fcc2                	sd	a6,120(sp)
        sd a7, 128(sp)
    8000566a:	e146                	sd	a7,128(sp)
        sd t3, 216(sp)
    8000566c:	edf2                	sd	t3,216(sp)
        sd t4, 224(sp)
    8000566e:	f1f6                	sd	t4,224(sp)
        sd t5, 232(sp)
    80005670:	f5fa                	sd	t5,232(sp)
        sd t6, 240(sp)
    80005672:	f9fe                	sd	t6,240(sp)

        # call the C trap handler in trap.c
        call kerneltrap
    80005674:	93cfd0ef          	jal	800027b0 <kerneltrap>

        # restore registers.
        ld ra, 0(sp)
    80005678:	6082                	ld	ra,0(sp)
        # ld sp, 8(sp)
        ld gp, 16(sp)
    8000567a:	61c2                	ld	gp,16(sp)
        # not tp (contains hartid), in case we moved CPUs
        ld t0, 32(sp)
    8000567c:	7282                	ld	t0,32(sp)
        ld t1, 40(sp)
    8000567e:	7322                	ld	t1,40(sp)
        ld t2, 48(sp)
    80005680:	73c2                	ld	t2,48(sp)
        ld a0, 72(sp)
    80005682:	6526                	ld	a0,72(sp)
        ld a1, 80(sp)
    80005684:	65c6                	ld	a1,80(sp)
        ld a2, 88(sp)
    80005686:	6666                	ld	a2,88(sp)
        ld a3, 96(sp)
    80005688:	7686                	ld	a3,96(sp)
        ld a4, 104(sp)
    8000568a:	7726                	ld	a4,104(sp)
        ld a5, 112(sp)
    8000568c:	77c6                	ld	a5,112(sp)
        ld a6, 120(sp)
    8000568e:	7866                	ld	a6,120(sp)
        ld a7, 128(sp)
    80005690:	688a                	ld	a7,128(sp)
        ld t3, 216(sp)
    80005692:	6e6e                	ld	t3,216(sp)
        ld t4, 224(sp)
    80005694:	7e8e                	ld	t4,224(sp)
        ld t5, 232(sp)
    80005696:	7f2e                	ld	t5,232(sp)
        ld t6, 240(sp)
    80005698:	7fce                	ld	t6,240(sp)

        addi sp, sp, 256
    8000569a:	6111                	addi	sp,sp,256

        # return to whatever we were doing in the kernel.
        sret
    8000569c:	10200073          	sret
    800056a0:	0001                	nop
    800056a2:	00000013          	nop
    800056a6:	00000013          	nop
    800056aa:	00000013          	nop

00000000800056ae <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    800056ae:	1141                	addi	sp,sp,-16
    800056b0:	e406                	sd	ra,8(sp)
    800056b2:	e022                	sd	s0,0(sp)
    800056b4:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(volatile uint32 *)(PLIC + UART0_IRQ * 4) = 1;
    800056b6:	0c000737          	lui	a4,0xc000
    800056ba:	4785                	li	a5,1
    800056bc:	d71c                	sw	a5,40(a4)
  *(volatile uint32 *)(PLIC + VIRTIO0_IRQ * 4) = 1;
    800056be:	c35c                	sw	a5,4(a4)
}
    800056c0:	60a2                	ld	ra,8(sp)
    800056c2:	6402                	ld	s0,0(sp)
    800056c4:	0141                	addi	sp,sp,16
    800056c6:	8082                	ret

00000000800056c8 <plicinithart>:

void
plicinithart(void)
{
    800056c8:	1141                	addi	sp,sp,-16
    800056ca:	e406                	sd	ra,8(sp)
    800056cc:	e022                	sd	s0,0(sp)
    800056ce:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800056d0:	a12fc0ef          	jal	800018e2 <cpuid>

  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(volatile uint32 *)PLIC_SENABLE(hart) =
    800056d4:	0085179b          	slliw	a5,a0,0x8
    800056d8:	0c002737          	lui	a4,0xc002
    800056dc:	08070713          	addi	a4,a4,128 # c002080 <_entry-0x73ffdf80>
    800056e0:	97ba                	add	a5,a5,a4
    800056e2:	40200713          	li	a4,1026
    800056e6:	c398                	sw	a4,0(a5)
    (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);

  // set this hart's S-mode priority threshold to 0.
  *(volatile uint32 *)PLIC_SPRIORITY(hart) = 0;
    800056e8:	00d5151b          	slliw	a0,a0,0xd
    800056ec:	0c2017b7          	lui	a5,0xc201
    800056f0:	953e                	add	a0,a0,a5
    800056f2:	00052023          	sw	zero,0(a0)
}
    800056f6:	60a2                	ld	ra,8(sp)
    800056f8:	6402                	ld	s0,0(sp)
    800056fa:	0141                	addi	sp,sp,16
    800056fc:	8082                	ret

00000000800056fe <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    800056fe:	1141                	addi	sp,sp,-16
    80005700:	e406                	sd	ra,8(sp)
    80005702:	e022                	sd	s0,0(sp)
    80005704:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005706:	9dcfc0ef          	jal	800018e2 <cpuid>
  int irq = *(volatile uint32 *)PLIC_SCLAIM(hart);
    8000570a:	00d5151b          	slliw	a0,a0,0xd
    8000570e:	0c2017b7          	lui	a5,0xc201
    80005712:	0791                	addi	a5,a5,4 # c201004 <_entry-0x73dfeffc>
    80005714:	953e                	add	a0,a0,a5
  return irq;
}
    80005716:	4108                	lw	a0,0(a0)
    80005718:	60a2                	ld	ra,8(sp)
    8000571a:	6402                	ld	s0,0(sp)
    8000571c:	0141                	addi	sp,sp,16
    8000571e:	8082                	ret

0000000080005720 <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    80005720:	1101                	addi	sp,sp,-32
    80005722:	ec06                	sd	ra,24(sp)
    80005724:	e822                	sd	s0,16(sp)
    80005726:	e426                	sd	s1,8(sp)
    80005728:	1000                	addi	s0,sp,32
    8000572a:	84aa                	mv	s1,a0
  int hart = cpuid();
    8000572c:	9b6fc0ef          	jal	800018e2 <cpuid>
  *(volatile uint32 *)PLIC_SCLAIM(hart) = irq;
    80005730:	00d5179b          	slliw	a5,a0,0xd
    80005734:	0c201737          	lui	a4,0xc201
    80005738:	0711                	addi	a4,a4,4 # c201004 <_entry-0x73dfeffc>
    8000573a:	97ba                	add	a5,a5,a4
    8000573c:	c384                	sw	s1,0(a5)
}
    8000573e:	60e2                	ld	ra,24(sp)
    80005740:	6442                	ld	s0,16(sp)
    80005742:	64a2                	ld	s1,8(sp)
    80005744:	6105                	addi	sp,sp,32
    80005746:	8082                	ret

0000000080005748 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80005748:	1141                	addi	sp,sp,-16
    8000574a:	e406                	sd	ra,8(sp)
    8000574c:	e022                	sd	s0,0(sp)
    8000574e:	0800                	addi	s0,sp,16
  if (i >= NUM)
    80005750:	479d                	li	a5,7
    80005752:	04a7ca63          	blt	a5,a0,800057a6 <free_desc+0x5e>
    panic("free_desc 1");
  if (disk.free[i])
    80005756:	0001b797          	auipc	a5,0x1b
    8000575a:	55278793          	addi	a5,a5,1362 # 80020ca8 <disk>
    8000575e:	97aa                	add	a5,a5,a0
    80005760:	0187c783          	lbu	a5,24(a5)
    80005764:	e7b9                	bnez	a5,800057b2 <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005766:	00451693          	slli	a3,a0,0x4
    8000576a:	0001b797          	auipc	a5,0x1b
    8000576e:	53e78793          	addi	a5,a5,1342 # 80020ca8 <disk>
    80005772:	6398                	ld	a4,0(a5)
    80005774:	9736                	add	a4,a4,a3
    80005776:	00073023          	sd	zero,0(a4)
  disk.desc[i].len = 0;
    8000577a:	6398                	ld	a4,0(a5)
    8000577c:	9736                	add	a4,a4,a3
    8000577e:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    80005782:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80005786:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    8000578a:	97aa                	add	a5,a5,a0
    8000578c:	4705                	li	a4,1
    8000578e:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    80005792:	0001b517          	auipc	a0,0x1b
    80005796:	52e50513          	addi	a0,a0,1326 # 80020cc0 <disk+0x18>
    8000579a:	893fc0ef          	jal	8000202c <wakeup>
}
    8000579e:	60a2                	ld	ra,8(sp)
    800057a0:	6402                	ld	s0,0(sp)
    800057a2:	0141                	addi	sp,sp,16
    800057a4:	8082                	ret
    panic("free_desc 1");
    800057a6:	00002517          	auipc	a0,0x2
    800057aa:	eca50513          	addi	a0,a0,-310 # 80007670 <etext+0x670>
    800057ae:	884fb0ef          	jal	80000832 <panic>
    panic("free_desc 2");
    800057b2:	00002517          	auipc	a0,0x2
    800057b6:	ece50513          	addi	a0,a0,-306 # 80007680 <etext+0x680>
    800057ba:	878fb0ef          	jal	80000832 <panic>

00000000800057be <virtio_disk_init>:
{
    800057be:	1101                	addi	sp,sp,-32
    800057c0:	ec06                	sd	ra,24(sp)
    800057c2:	e822                	sd	s0,16(sp)
    800057c4:	e426                	sd	s1,8(sp)
    800057c6:	e04a                	sd	s2,0(sp)
    800057c8:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    800057ca:	00002597          	auipc	a1,0x2
    800057ce:	ec658593          	addi	a1,a1,-314 # 80007690 <etext+0x690>
    800057d2:	0001b517          	auipc	a0,0x1b
    800057d6:	5fe50513          	addi	a0,a0,1534 # 80020dd0 <disk+0x128>
    800057da:	bb6fb0ef          	jal	80000b90 <initlock>
  if (*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800057de:	100017b7          	lui	a5,0x10001
    800057e2:	4398                	lw	a4,0(a5)
    800057e4:	747277b7          	lui	a5,0x74727
    800057e8:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    800057ec:	14f71263          	bne	a4,a5,80005930 <virtio_disk_init+0x172>
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800057f0:	100017b7          	lui	a5,0x10001
    800057f4:	43d8                	lw	a4,4(a5)
  if (*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800057f6:	4789                	li	a5,2
    800057f8:	12f71c63          	bne	a4,a5,80005930 <virtio_disk_init+0x172>
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800057fc:	100017b7          	lui	a5,0x10001
    80005800:	4798                	lw	a4,8(a5)
    80005802:	4789                	li	a5,2
    80005804:	12f71663          	bne	a4,a5,80005930 <virtio_disk_init+0x172>
      *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551) {
    80005808:	100017b7          	lui	a5,0x10001
    8000580c:	47d8                	lw	a4,12(a5)
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    8000580e:	554d47b7          	lui	a5,0x554d4
    80005812:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    80005816:	10f71d63          	bne	a4,a5,80005930 <virtio_disk_init+0x172>
  *R(VIRTIO_MMIO_STATUS) = status;
    8000581a:	100017b7          	lui	a5,0x10001
    8000581e:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005822:	4705                	li	a4,1
    80005824:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005826:	470d                	li	a4,3
    80005828:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    8000582a:	10001737          	lui	a4,0x10001
    8000582e:	4b18                	lw	a4,16(a4)
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    80005830:	c7ffe6b7          	lui	a3,0xc7ffe
    80005834:	55f68693          	addi	a3,a3,1375 # ffffffffc7ffe55f <end+0xffffffff47fdd777>
    80005838:	8f75                	and	a4,a4,a3
    8000583a:	100016b7          	lui	a3,0x10001
    8000583e:	d298                	sw	a4,32(a3)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005840:	472d                	li	a4,11
    80005842:	dbb8                	sw	a4,112(a5)
  status = *R(VIRTIO_MMIO_STATUS);
    80005844:	0707a903          	lw	s2,112(a5)
  if (!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80005848:	00897793          	andi	a5,s2,8
    8000584c:	0e078863          	beqz	a5,8000593c <virtio_disk_init+0x17e>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80005850:	100017b7          	lui	a5,0x10001
    80005854:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if (*R(VIRTIO_MMIO_QUEUE_READY))
    80005858:	43fc                	lw	a5,68(a5)
    8000585a:	0e079763          	bnez	a5,80005948 <virtio_disk_init+0x18a>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    8000585e:	100017b7          	lui	a5,0x10001
    80005862:	5bdc                	lw	a5,52(a5)
  if (max == 0)
    80005864:	0e078863          	beqz	a5,80005954 <virtio_disk_init+0x196>
  if (max < NUM)
    80005868:	471d                	li	a4,7
    8000586a:	0ef77b63          	bgeu	a4,a5,80005960 <virtio_disk_init+0x1a2>
  disk.desc = kalloc();
    8000586e:	ac8fb0ef          	jal	80000b36 <kalloc>
    80005872:	0001b497          	auipc	s1,0x1b
    80005876:	43648493          	addi	s1,s1,1078 # 80020ca8 <disk>
    8000587a:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    8000587c:	abafb0ef          	jal	80000b36 <kalloc>
    80005880:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    80005882:	ab4fb0ef          	jal	80000b36 <kalloc>
    80005886:	87aa                	mv	a5,a0
    80005888:	e888                	sd	a0,16(s1)
  if (!disk.desc || !disk.avail || !disk.used)
    8000588a:	6088                	ld	a0,0(s1)
    8000588c:	0e050063          	beqz	a0,8000596c <virtio_disk_init+0x1ae>
    80005890:	0001b717          	auipc	a4,0x1b
    80005894:	42073703          	ld	a4,1056(a4) # 80020cb0 <disk+0x8>
    80005898:	00173713          	seqz	a4,a4
    8000589c:	0017b793          	seqz	a5,a5
    800058a0:	8fd9                	or	a5,a5,a4
    800058a2:	e7e9                	bnez	a5,8000596c <virtio_disk_init+0x1ae>
  memset(disk.desc, 0, PGSIZE);
    800058a4:	6605                	lui	a2,0x1
    800058a6:	4581                	li	a1,0
    800058a8:	c40fb0ef          	jal	80000ce8 <memset>
  memset(disk.avail, 0, PGSIZE);
    800058ac:	0001b497          	auipc	s1,0x1b
    800058b0:	3fc48493          	addi	s1,s1,1020 # 80020ca8 <disk>
    800058b4:	6605                	lui	a2,0x1
    800058b6:	4581                	li	a1,0
    800058b8:	6488                	ld	a0,8(s1)
    800058ba:	c2efb0ef          	jal	80000ce8 <memset>
  memset(disk.used, 0, PGSIZE);
    800058be:	6605                	lui	a2,0x1
    800058c0:	4581                	li	a1,0
    800058c2:	6888                	ld	a0,16(s1)
    800058c4:	c24fb0ef          	jal	80000ce8 <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    800058c8:	100017b7          	lui	a5,0x10001
    800058cc:	4721                	li	a4,8
    800058ce:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    800058d0:	4098                	lw	a4,0(s1)
    800058d2:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    800058d6:	40d8                	lw	a4,4(s1)
    800058d8:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    800058dc:	649c                	ld	a5,8(s1)
    800058de:	10001737          	lui	a4,0x10001
    800058e2:	08f72823          	sw	a5,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    800058e6:	9781                	srai	a5,a5,0x20
    800058e8:	08f72a23          	sw	a5,148(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    800058ec:	689c                	ld	a5,16(s1)
    800058ee:	0af72023          	sw	a5,160(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    800058f2:	9781                	srai	a5,a5,0x20
    800058f4:	0af72223          	sw	a5,164(a4)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    800058f8:	4785                	li	a5,1
    800058fa:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    800058fc:	00f48c23          	sb	a5,24(s1)
    80005900:	00f48ca3          	sb	a5,25(s1)
    80005904:	00f48d23          	sb	a5,26(s1)
    80005908:	00f48da3          	sb	a5,27(s1)
    8000590c:	00f48e23          	sb	a5,28(s1)
    80005910:	00f48ea3          	sb	a5,29(s1)
    80005914:	00f48f23          	sb	a5,30(s1)
    80005918:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    8000591c:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80005920:	07272823          	sw	s2,112(a4)
}
    80005924:	60e2                	ld	ra,24(sp)
    80005926:	6442                	ld	s0,16(sp)
    80005928:	64a2                	ld	s1,8(sp)
    8000592a:	6902                	ld	s2,0(sp)
    8000592c:	6105                	addi	sp,sp,32
    8000592e:	8082                	ret
    panic("could not find virtio disk");
    80005930:	00002517          	auipc	a0,0x2
    80005934:	d7050513          	addi	a0,a0,-656 # 800076a0 <etext+0x6a0>
    80005938:	efbfa0ef          	jal	80000832 <panic>
    panic("virtio disk FEATURES_OK unset");
    8000593c:	00002517          	auipc	a0,0x2
    80005940:	d8450513          	addi	a0,a0,-636 # 800076c0 <etext+0x6c0>
    80005944:	eeffa0ef          	jal	80000832 <panic>
    panic("virtio disk should not be ready");
    80005948:	00002517          	auipc	a0,0x2
    8000594c:	d9850513          	addi	a0,a0,-616 # 800076e0 <etext+0x6e0>
    80005950:	ee3fa0ef          	jal	80000832 <panic>
    panic("virtio disk has no queue 0");
    80005954:	00002517          	auipc	a0,0x2
    80005958:	dac50513          	addi	a0,a0,-596 # 80007700 <etext+0x700>
    8000595c:	ed7fa0ef          	jal	80000832 <panic>
    panic("virtio disk max queue too short");
    80005960:	00002517          	auipc	a0,0x2
    80005964:	dc050513          	addi	a0,a0,-576 # 80007720 <etext+0x720>
    80005968:	ecbfa0ef          	jal	80000832 <panic>
    panic("virtio disk kalloc");
    8000596c:	00002517          	auipc	a0,0x2
    80005970:	dd450513          	addi	a0,a0,-556 # 80007740 <etext+0x740>
    80005974:	ebffa0ef          	jal	80000832 <panic>

0000000080005978 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80005978:	711d                	addi	sp,sp,-96
    8000597a:	ec86                	sd	ra,88(sp)
    8000597c:	e8a2                	sd	s0,80(sp)
    8000597e:	e4a6                	sd	s1,72(sp)
    80005980:	e0ca                	sd	s2,64(sp)
    80005982:	fc4e                	sd	s3,56(sp)
    80005984:	f852                	sd	s4,48(sp)
    80005986:	f456                	sd	s5,40(sp)
    80005988:	f05a                	sd	s6,32(sp)
    8000598a:	ec5e                	sd	s7,24(sp)
    8000598c:	e862                	sd	s8,16(sp)
    8000598e:	1080                	addi	s0,sp,96
    80005990:	89aa                	mv	s3,a0
    80005992:	8b2e                	mv	s6,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    80005994:	00c52b83          	lw	s7,12(a0)
    80005998:	001b9b9b          	slliw	s7,s7,0x1
    8000599c:	1b82                	slli	s7,s7,0x20
    8000599e:	020bdb93          	srli	s7,s7,0x20

  acquire(&disk.vdisk_lock);
    800059a2:	0001b517          	auipc	a0,0x1b
    800059a6:	42e50513          	addi	a0,a0,1070 # 80020dd0 <disk+0x128>
    800059aa:	a66fb0ef          	jal	80000c10 <acquire>
  for (int i = 0; i < NUM; i++) {
    800059ae:	44a1                	li	s1,8
      disk.free[i] = 0;
    800059b0:	0001ba97          	auipc	s5,0x1b
    800059b4:	2f8a8a93          	addi	s5,s5,760 # 80020ca8 <disk>
  for (int i = 0; i < 3; i++) {
    800059b8:	4a0d                	li	s4,3
    idx[i] = alloc_desc();
    800059ba:	5c7d                	li	s8,-1
    800059bc:	a885                	j	80005a2c <virtio_disk_rw+0xb4>
      disk.free[i] = 0;
    800059be:	00fa8733          	add	a4,s5,a5
    800059c2:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    800059c6:	c19c                	sw	a5,0(a1)
    if (idx[i] < 0) {
    800059c8:	0207c563          	bltz	a5,800059f2 <virtio_disk_rw+0x7a>
  for (int i = 0; i < 3; i++) {
    800059cc:	2905                	addiw	s2,s2,1
    800059ce:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    800059d0:	07490263          	beq	s2,s4,80005a34 <virtio_disk_rw+0xbc>
    idx[i] = alloc_desc();
    800059d4:	85b2                	mv	a1,a2
  for (int i = 0; i < NUM; i++) {
    800059d6:	0001b717          	auipc	a4,0x1b
    800059da:	2d270713          	addi	a4,a4,722 # 80020ca8 <disk>
    800059de:	4781                	li	a5,0
    if (disk.free[i]) {
    800059e0:	01874683          	lbu	a3,24(a4)
    800059e4:	fee9                	bnez	a3,800059be <virtio_disk_rw+0x46>
  for (int i = 0; i < NUM; i++) {
    800059e6:	2785                	addiw	a5,a5,1
    800059e8:	0705                	addi	a4,a4,1
    800059ea:	fe979be3          	bne	a5,s1,800059e0 <virtio_disk_rw+0x68>
    idx[i] = alloc_desc();
    800059ee:	0185a023          	sw	s8,0(a1)
      for (int j = 0; j < i; j++)
    800059f2:	01205d63          	blez	s2,80005a0c <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    800059f6:	fa042503          	lw	a0,-96(s0)
    800059fa:	d4fff0ef          	jal	80005748 <free_desc>
      for (int j = 0; j < i; j++)
    800059fe:	4785                	li	a5,1
    80005a00:	0127d663          	bge	a5,s2,80005a0c <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    80005a04:	fa442503          	lw	a0,-92(s0)
    80005a08:	d41ff0ef          	jal	80005748 <free_desc>
  int idx[3];
  while (1) {
    if (alloc3_desc(idx) == 0) {
      break;
    }
    sleep_prepare(&disk.free[0]);
    80005a0c:	0001b517          	auipc	a0,0x1b
    80005a10:	2b450513          	addi	a0,a0,692 # 80020cc0 <disk+0x18>
    80005a14:	d90fc0ef          	jal	80001fa4 <sleep_prepare>
    sleep(&disk.free[0], &disk.vdisk_lock);
    80005a18:	0001b597          	auipc	a1,0x1b
    80005a1c:	3b858593          	addi	a1,a1,952 # 80020dd0 <disk+0x128>
    80005a20:	0001b517          	auipc	a0,0x1b
    80005a24:	2a050513          	addi	a0,a0,672 # 80020cc0 <disk+0x18>
    80005a28:	db8fc0ef          	jal	80001fe0 <sleep>
  for (int i = 0; i < 3; i++) {
    80005a2c:	fa040613          	addi	a2,s0,-96
    80005a30:	4901                	li	s2,0
    80005a32:	b74d                	j	800059d4 <virtio_disk_rw+0x5c>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005a34:	fa042503          	lw	a0,-96(s0)
    80005a38:	00451693          	slli	a3,a0,0x4

  if (write)
    80005a3c:	0001b797          	auipc	a5,0x1b
    80005a40:	26c78793          	addi	a5,a5,620 # 80020ca8 <disk>
    80005a44:	00451713          	slli	a4,a0,0x4
    80005a48:	0a070713          	addi	a4,a4,160
    80005a4c:	973e                	add	a4,a4,a5
    80005a4e:	01603633          	snez	a2,s6
    80005a52:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80005a54:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80005a58:	01773823          	sd	s7,16(a4)

  disk.desc[idx[0]].addr = (uint64)buf0;
    80005a5c:	6398                	ld	a4,0(a5)
    80005a5e:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005a60:	0a868613          	addi	a2,a3,168 # 100010a8 <_entry-0x6fffef58>
    80005a64:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64)buf0;
    80005a66:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80005a68:	6390                	ld	a2,0(a5)
    80005a6a:	00d605b3          	add	a1,a2,a3
    80005a6e:	4741                	li	a4,16
    80005a70:	c598                	sw	a4,8(a1)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80005a72:	4805                	li	a6,1
    80005a74:	01059623          	sh	a6,12(a1)
  disk.desc[idx[0]].next = idx[1];
    80005a78:	fa442703          	lw	a4,-92(s0)
    80005a7c:	00e59723          	sh	a4,14(a1)

  disk.desc[idx[1]].addr = (uint64)b->data;
    80005a80:	0712                	slli	a4,a4,0x4
    80005a82:	963a                	add	a2,a2,a4
    80005a84:	05898593          	addi	a1,s3,88
    80005a88:	e20c                	sd	a1,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    80005a8a:	0007b883          	ld	a7,0(a5)
    80005a8e:	9746                	add	a4,a4,a7
    80005a90:	40000613          	li	a2,1024
    80005a94:	c710                	sw	a2,8(a4)
  if (write)
    80005a96:	001b3613          	seqz	a2,s6
    80005a9a:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    80005a9e:	01066633          	or	a2,a2,a6
    80005aa2:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80005aa6:	fa842583          	lw	a1,-88(s0)
    80005aaa:	00b71723          	sh	a1,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80005aae:	00250613          	addi	a2,a0,2
    80005ab2:	0612                	slli	a2,a2,0x4
    80005ab4:	963e                	add	a2,a2,a5
    80005ab6:	577d                	li	a4,-1
    80005ab8:	00e60823          	sb	a4,16(a2)
  disk.desc[idx[2]].addr = (uint64)&disk.info[idx[0]].status;
    80005abc:	0592                	slli	a1,a1,0x4
    80005abe:	98ae                	add	a7,a7,a1
    80005ac0:	03068713          	addi	a4,a3,48
    80005ac4:	973e                	add	a4,a4,a5
    80005ac6:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    80005aca:	6398                	ld	a4,0(a5)
    80005acc:	972e                	add	a4,a4,a1
    80005ace:	01072423          	sw	a6,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80005ad2:	4689                	li	a3,2
    80005ad4:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    80005ad8:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80005adc:	0109a223          	sw	a6,4(s3)
  disk.info[idx[0]].b = b;
    80005ae0:	01363423          	sd	s3,8(a2)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80005ae4:	6794                	ld	a3,8(a5)
    80005ae6:	0026d703          	lhu	a4,2(a3)
    80005aea:	8b1d                	andi	a4,a4,7
    80005aec:	0706                	slli	a4,a4,0x1
    80005aee:	96ba                	add	a3,a3,a4
    80005af0:	00a69223          	sh	a0,4(a3)

// fence for memory-mapped IO
static inline void
io_fence()
{
  asm volatile("fence iorw, iorw" ::: "memory");
    80005af4:	0ff0000f          	fence

  io_fence();

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80005af8:	6798                	ld	a4,8(a5)
    80005afa:	00275783          	lhu	a5,2(a4)
    80005afe:	2785                	addiw	a5,a5,1
    80005b00:	00f71123          	sh	a5,2(a4)
    80005b04:	0ff0000f          	fence

  io_fence();

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80005b08:	100017b7          	lui	a5,0x10001
    80005b0c:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while (b->disk == 1) {
    80005b10:	0049a783          	lw	a5,4(s3)
    80005b14:	03079263          	bne	a5,a6,80005b38 <virtio_disk_rw+0x1c0>
    sleep_prepare(b);
    sleep(b, &disk.vdisk_lock);
    80005b18:	0001b917          	auipc	s2,0x1b
    80005b1c:	2b890913          	addi	s2,s2,696 # 80020dd0 <disk+0x128>
  while (b->disk == 1) {
    80005b20:	84be                	mv	s1,a5
    sleep_prepare(b);
    80005b22:	854e                	mv	a0,s3
    80005b24:	c80fc0ef          	jal	80001fa4 <sleep_prepare>
    sleep(b, &disk.vdisk_lock);
    80005b28:	85ca                	mv	a1,s2
    80005b2a:	854e                	mv	a0,s3
    80005b2c:	cb4fc0ef          	jal	80001fe0 <sleep>
  while (b->disk == 1) {
    80005b30:	0049a783          	lw	a5,4(s3)
    80005b34:	fe9787e3          	beq	a5,s1,80005b22 <virtio_disk_rw+0x1aa>
  }

  disk.info[idx[0]].b = 0;
    80005b38:	fa042903          	lw	s2,-96(s0)
    80005b3c:	00290713          	addi	a4,s2,2
    80005b40:	0712                	slli	a4,a4,0x4
    80005b42:	0001b797          	auipc	a5,0x1b
    80005b46:	16678793          	addi	a5,a5,358 # 80020ca8 <disk>
    80005b4a:	97ba                	add	a5,a5,a4
    80005b4c:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80005b50:	0001b997          	auipc	s3,0x1b
    80005b54:	15898993          	addi	s3,s3,344 # 80020ca8 <disk>
    80005b58:	00491713          	slli	a4,s2,0x4
    80005b5c:	0009b783          	ld	a5,0(s3)
    80005b60:	97ba                	add	a5,a5,a4
    80005b62:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80005b66:	854a                	mv	a0,s2
    80005b68:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80005b6c:	bddff0ef          	jal	80005748 <free_desc>
    if (flag & VRING_DESC_F_NEXT)
    80005b70:	8885                	andi	s1,s1,1
    80005b72:	f0fd                	bnez	s1,80005b58 <virtio_disk_rw+0x1e0>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80005b74:	0001b517          	auipc	a0,0x1b
    80005b78:	25c50513          	addi	a0,a0,604 # 80020dd0 <disk+0x128>
    80005b7c:	926fb0ef          	jal	80000ca2 <release>
}
    80005b80:	60e6                	ld	ra,88(sp)
    80005b82:	6446                	ld	s0,80(sp)
    80005b84:	64a6                	ld	s1,72(sp)
    80005b86:	6906                	ld	s2,64(sp)
    80005b88:	79e2                	ld	s3,56(sp)
    80005b8a:	7a42                	ld	s4,48(sp)
    80005b8c:	7aa2                	ld	s5,40(sp)
    80005b8e:	7b02                	ld	s6,32(sp)
    80005b90:	6be2                	ld	s7,24(sp)
    80005b92:	6c42                	ld	s8,16(sp)
    80005b94:	6125                	addi	sp,sp,96
    80005b96:	8082                	ret

0000000080005b98 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80005b98:	1101                	addi	sp,sp,-32
    80005b9a:	ec06                	sd	ra,24(sp)
    80005b9c:	e822                	sd	s0,16(sp)
    80005b9e:	e426                	sd	s1,8(sp)
    80005ba0:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    80005ba2:	0001b497          	auipc	s1,0x1b
    80005ba6:	10648493          	addi	s1,s1,262 # 80020ca8 <disk>
    80005baa:	0001b517          	auipc	a0,0x1b
    80005bae:	22650513          	addi	a0,a0,550 # 80020dd0 <disk+0x128>
    80005bb2:	85efb0ef          	jal	80000c10 <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80005bb6:	100017b7          	lui	a5,0x10001
    80005bba:	53bc                	lw	a5,96(a5)
    80005bbc:	8b8d                	andi	a5,a5,3
    80005bbe:	10001737          	lui	a4,0x10001
    80005bc2:	d37c                	sw	a5,100(a4)
    80005bc4:	0ff0000f          	fence
  io_fence();

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while (disk.used_idx != disk.used->idx) {
    80005bc8:	689c                	ld	a5,16(s1)
    80005bca:	0204d703          	lhu	a4,32(s1)
    80005bce:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    80005bd2:	04f70663          	beq	a4,a5,80005c1e <virtio_disk_intr+0x86>
    80005bd6:	0ff0000f          	fence
    io_fence();
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80005bda:	6898                	ld	a4,16(s1)
    80005bdc:	0204d783          	lhu	a5,32(s1)
    80005be0:	8b9d                	andi	a5,a5,7
    80005be2:	078e                	slli	a5,a5,0x3
    80005be4:	97ba                	add	a5,a5,a4
    80005be6:	43dc                	lw	a5,4(a5)

    if (disk.info[id].status != 0)
    80005be8:	00278713          	addi	a4,a5,2
    80005bec:	0712                	slli	a4,a4,0x4
    80005bee:	9726                	add	a4,a4,s1
    80005bf0:	01074703          	lbu	a4,16(a4) # 10001010 <_entry-0x6fffeff0>
    80005bf4:	e321                	bnez	a4,80005c34 <virtio_disk_intr+0x9c>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80005bf6:	0789                	addi	a5,a5,2
    80005bf8:	0792                	slli	a5,a5,0x4
    80005bfa:	97a6                	add	a5,a5,s1
    80005bfc:	6788                	ld	a0,8(a5)
    b->disk = 0; // disk is done with buf
    80005bfe:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80005c02:	c2afc0ef          	jal	8000202c <wakeup>

    disk.used_idx += 1;
    80005c06:	0204d783          	lhu	a5,32(s1)
    80005c0a:	2785                	addiw	a5,a5,1
    80005c0c:	17c2                	slli	a5,a5,0x30
    80005c0e:	93c1                	srli	a5,a5,0x30
    80005c10:	02f49023          	sh	a5,32(s1)
  while (disk.used_idx != disk.used->idx) {
    80005c14:	6898                	ld	a4,16(s1)
    80005c16:	00275703          	lhu	a4,2(a4)
    80005c1a:	faf71ee3          	bne	a4,a5,80005bd6 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80005c1e:	0001b517          	auipc	a0,0x1b
    80005c22:	1b250513          	addi	a0,a0,434 # 80020dd0 <disk+0x128>
    80005c26:	87cfb0ef          	jal	80000ca2 <release>
}
    80005c2a:	60e2                	ld	ra,24(sp)
    80005c2c:	6442                	ld	s0,16(sp)
    80005c2e:	64a2                	ld	s1,8(sp)
    80005c30:	6105                	addi	sp,sp,32
    80005c32:	8082                	ret
      panic("virtio_disk_intr status");
    80005c34:	00002517          	auipc	a0,0x2
    80005c38:	b2450513          	addi	a0,a0,-1244 # 80007758 <etext+0x758>
    80005c3c:	bf7fa0ef          	jal	80000832 <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	9282                	jalr	t0

000000008000609c <userret>:
    8000609c:	0000100f          	fence.i
    800060a0:	12000073          	sfence.vma
    800060a4:	18051073          	csrw	satp,a0
    800060a8:	12000073          	sfence.vma
    800060ac:	02000537          	lui	a0,0x2000
    800060b0:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060b2:	0536                	slli	a0,a0,0xd
    800060b4:	02853083          	ld	ra,40(a0)
    800060b8:	03053103          	ld	sp,48(a0)
    800060bc:	03853183          	ld	gp,56(a0)
    800060c0:	04053203          	ld	tp,64(a0)
    800060c4:	04853283          	ld	t0,72(a0)
    800060c8:	05053303          	ld	t1,80(a0)
    800060cc:	05853383          	ld	t2,88(a0)
    800060d0:	7120                	ld	s0,96(a0)
    800060d2:	7524                	ld	s1,104(a0)
    800060d4:	7d2c                	ld	a1,120(a0)
    800060d6:	6150                	ld	a2,128(a0)
    800060d8:	6554                	ld	a3,136(a0)
    800060da:	6958                	ld	a4,144(a0)
    800060dc:	6d5c                	ld	a5,152(a0)
    800060de:	0a053803          	ld	a6,160(a0)
    800060e2:	0a853883          	ld	a7,168(a0)
    800060e6:	0b053903          	ld	s2,176(a0)
    800060ea:	0b853983          	ld	s3,184(a0)
    800060ee:	0c053a03          	ld	s4,192(a0)
    800060f2:	0c853a83          	ld	s5,200(a0)
    800060f6:	0d053b03          	ld	s6,208(a0)
    800060fa:	0d853b83          	ld	s7,216(a0)
    800060fe:	0e053c03          	ld	s8,224(a0)
    80006102:	0e853c83          	ld	s9,232(a0)
    80006106:	0f053d03          	ld	s10,240(a0)
    8000610a:	0f853d83          	ld	s11,248(a0)
    8000610e:	10053e03          	ld	t3,256(a0)
    80006112:	10853e83          	ld	t4,264(a0)
    80006116:	11053f03          	ld	t5,272(a0)
    8000611a:	11853f83          	ld	t6,280(a0)
    8000611e:	7928                	ld	a0,112(a0)
    80006120:	10200073          	sret
	...
