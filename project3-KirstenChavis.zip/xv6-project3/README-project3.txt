Priority Based Scheduler for xv6

Description
This project adjusts xv6 process scheduler into a priority based scheduler. A system call known as setpriority() has been added and utilized within two test programs known as prioritytest.c and syscalltest.c. 

Getting Started

Dependencies
Describe any prerequisites, libraries, OS version, etc., needed before installing program.
ex. Windows 10
Windows/WSL
Git Version: 2.56.0
Make Version: GNU Make 4.4.1
GCC Version: (GCC) 16.2.0
Perl Version: Perl (v5.42.3)
BC Version: BC 1.08.2
RISCV64 Version: riscv-unknown-elf-gcc.exe 16.1.0
RISCV64 Version: GNU ld 2.47.20260726

Installing
Build Command: make CPUS=1 qemu
Scheduler Test Command: prioritytest
System Call Test Command: syscalltest

Files Added
prioritytest.c
syscalltest.c

Files Modified
Makefile

defs.h
proc.c
proc.h
syscall.c
syscall.h
sysproc.c
trap.c

user.h
usys.pl

Acknowledgments
Created for Project 3, CMPS 460 Operating Systems, University of La Verne
