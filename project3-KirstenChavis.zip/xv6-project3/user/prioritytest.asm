
user/_prioritytest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <do_work>:
#include "kernel/stat.h"
#include "user/user.h"

#define WORKLOAD 100000000LL

void do_work() {
   0:	1101                	addi	sp,sp,-32
   2:	ec06                	sd	ra,24(sp)
   4:	e822                	sd	s0,16(sp)
   6:	1000                	addi	s0,sp,32
  volatile long x = 1;
   8:	4785                	li	a5,1
   a:	fef43423          	sd	a5,-24(s0)
  for (long i = 0; i < WORKLOAD; i++) {
   e:	4701                	li	a4,0
    x = (x << 1) ^ i;
    if (x == 0) x = 1;
  10:	863e                	mv	a2,a5
  for (long i = 0; i < WORKLOAD; i++) {
  12:	05f5e6b7          	lui	a3,0x5f5e
  16:	10068693          	addi	a3,a3,256 # 5f5e100 <base+0x5f5d0f0>
  1a:	a021                	j	22 <do_work+0x22>
  1c:	0705                	addi	a4,a4,1
  1e:	00d70e63          	beq	a4,a3,3a <do_work+0x3a>
    x = (x << 1) ^ i;
  22:	fe843783          	ld	a5,-24(s0)
  26:	0786                	slli	a5,a5,0x1
  28:	8fb9                	xor	a5,a5,a4
  2a:	fef43423          	sd	a5,-24(s0)
    if (x == 0) x = 1;
  2e:	fe843783          	ld	a5,-24(s0)
  32:	f7ed                	bnez	a5,1c <do_work+0x1c>
  34:	fec43423          	sd	a2,-24(s0)
  38:	b7d5                	j	1c <do_work+0x1c>
  }
  (void)x;
  3a:	fe843783          	ld	a5,-24(s0)
}
  3e:	60e2                	ld	ra,24(sp)
  40:	6442                	ld	s0,16(sp)
  42:	6105                	addi	sp,sp,32
  44:	8082                	ret

0000000000000046 <main>:

int main(int argc, char *argv[]) {
  46:	1141                	addi	sp,sp,-16
  48:	e406                	sd	ra,8(sp)
  4a:	e022                	sd	s0,0(sp)
  4c:	0800                	addi	s0,sp,16
  printf("--- STARTING SCHEDULER PERFORMANCE TESTS ---\n");
  4e:	00001517          	auipc	a0,0x1
  52:	a3250513          	addi	a0,a0,-1486 # a80 <malloc+0xfa>
  56:	075000ef          	jal	8ca <printf>

  // TEST 1: Fresh Allocation & Unequal Priorities
  printf("\n[Test 1] Unequal priorities & Allocation\n");
  5a:	00001517          	auipc	a0,0x1
  5e:	a5e50513          	addi	a0,a0,-1442 # ab8 <malloc+0x132>
  62:	069000ef          	jal	8ca <printf>
  
  int pid1 = fork();
  66:	3ee000ef          	jal	454 <fork>
  if (pid1 == 0) {
  6a:	e50d                	bnez	a0,94 <main+0x4e>
    // Should print kernel log showing birth at priority 50
    setpriority(10); // Raise priority to 10
  6c:	4529                	li	a0,10
  6e:	49e000ef          	jal	50c <setpriority>
    printf("High-priority child (10) starting math loop...\n");
  72:	00001517          	auipc	a0,0x1
  76:	a7650513          	addi	a0,a0,-1418 # ae8 <malloc+0x162>
  7a:	051000ef          	jal	8ca <printf>
    do_work();
  7e:	f83ff0ef          	jal	0 <do_work>
    printf("High-priority child FINISHED\n");
  82:	00001517          	auipc	a0,0x1
  86:	a9650513          	addi	a0,a0,-1386 # b18 <malloc+0x192>
  8a:	041000ef          	jal	8ca <printf>
    exit(0);
  8e:	4501                	li	a0,0
  90:	3cc000ef          	jal	45c <exit>
  }

  int pid2 = fork();
  94:	3c0000ef          	jal	454 <fork>
  if (pid2 == 0) {
  98:	e515                	bnez	a0,c4 <main+0x7e>
    setpriority(150); // Lower priority to 150
  9a:	09600513          	li	a0,150
  9e:	46e000ef          	jal	50c <setpriority>
    printf("Low-priority child (150) starting math loop...\n");
  a2:	00001517          	auipc	a0,0x1
  a6:	a9650513          	addi	a0,a0,-1386 # b38 <malloc+0x1b2>
  aa:	021000ef          	jal	8ca <printf>
    do_work();
  ae:	f53ff0ef          	jal	0 <do_work>
    printf("Low-priority child FINISHED\n");
  b2:	00001517          	auipc	a0,0x1
  b6:	ab650513          	addi	a0,a0,-1354 # b68 <malloc+0x1e2>
  ba:	011000ef          	jal	8ca <printf>
    exit(0);
  be:	4501                	li	a0,0
  c0:	39c000ef          	jal	45c <exit>
  }

  wait(0); wait(0);
  c4:	4501                	li	a0,0
  c6:	39e000ef          	jal	464 <wait>
  ca:	4501                	li	a0,0
  cc:	398000ef          	jal	464 <wait>

  // TEST 2: Equal Runnable Priorities (Round-Robin Tie Breaking)
  printf("\n[Test 2] Equal priority Round-Robin Tie Breaking\n");
  d0:	00001517          	auipc	a0,0x1
  d4:	ab850513          	addi	a0,a0,-1352 # b88 <malloc+0x202>
  d8:	7f2000ef          	jal	8ca <printf>
  setpriority(100); // Parent sets self to 100
  dc:	06400513          	li	a0,100
  e0:	42c000ef          	jal	50c <setpriority>

  int pid3 = fork();
  e4:	370000ef          	jal	454 <fork>
  if (pid3 == 0) {
  e8:	e515                	bnez	a0,114 <main+0xce>
    for(int i=1; i<=2; i++) {
      printf("Child A chunk %d\n", i);
  ea:	4585                	li	a1,1
  ec:	00001517          	auipc	a0,0x1
  f0:	ad450513          	addi	a0,a0,-1324 # bc0 <malloc+0x23a>
  f4:	7d6000ef          	jal	8ca <printf>
      do_work();
  f8:	f09ff0ef          	jal	0 <do_work>
      printf("Child A chunk %d\n", i);
  fc:	4589                	li	a1,2
  fe:	00001517          	auipc	a0,0x1
 102:	ac250513          	addi	a0,a0,-1342 # bc0 <malloc+0x23a>
 106:	7c4000ef          	jal	8ca <printf>
      do_work();
 10a:	ef7ff0ef          	jal	0 <do_work>
    }
    exit(0);
 10e:	4501                	li	a0,0
 110:	34c000ef          	jal	45c <exit>
  }

  int pid4 = fork();
 114:	340000ef          	jal	454 <fork>
  if (pid4 == 0) {
 118:	e515                	bnez	a0,144 <main+0xfe>
    for(int i=1; i<=2; i++) {
      printf("Child B chunk %d\n", i);
 11a:	4585                	li	a1,1
 11c:	00001517          	auipc	a0,0x1
 120:	abc50513          	addi	a0,a0,-1348 # bd8 <malloc+0x252>
 124:	7a6000ef          	jal	8ca <printf>
      do_work();
 128:	ed9ff0ef          	jal	0 <do_work>
      printf("Child B chunk %d\n", i);
 12c:	4589                	li	a1,2
 12e:	00001517          	auipc	a0,0x1
 132:	aaa50513          	addi	a0,a0,-1366 # bd8 <malloc+0x252>
 136:	794000ef          	jal	8ca <printf>
      do_work();
 13a:	ec7ff0ef          	jal	0 <do_work>
    }
    exit(0);
 13e:	4501                	li	a0,0
 140:	31c000ef          	jal	45c <exit>
  }

  wait(0); wait(0);
 144:	4501                	li	a0,0
 146:	31e000ef          	jal	464 <wait>
 14a:	4501                	li	a0,0
 14c:	318000ef          	jal	464 <wait>

  // TEST 3: Wakeup Adjustments
  printf("\n[Test 3] Testing Wakeup adjustments (-2 penalty reward)\n");
 150:	00001517          	auipc	a0,0x1
 154:	aa050513          	addi	a0,a0,-1376 # bf0 <malloc+0x26a>
 158:	772000ef          	jal	8ca <printf>
  int pid5 = fork();
 15c:	2f8000ef          	jal	454 <fork>
  if (pid5 == 0) {
 160:	e51d                	bnez	a0,18e <main+0x148>
    setpriority(50);
 162:	03200513          	li	a0,50
 166:	3a6000ef          	jal	50c <setpriority>
    printf("Child going to sleep for 5 ticks...\n");
 16a:	00001517          	auipc	a0,0x1
 16e:	ac650513          	addi	a0,a0,-1338 # c30 <malloc+0x2aa>
 172:	758000ef          	jal	8ca <printf>
    sleep(5); // Forces SLEEPING state transition
 176:	4515                	li	a0,5
 178:	36c000ef          	jal	4e4 <sleep>
    printf("Child woke up! Check kernel printout for -2 adjustment.\n");
 17c:	00001517          	auipc	a0,0x1
 180:	adc50513          	addi	a0,a0,-1316 # c58 <malloc+0x2d2>
 184:	746000ef          	jal	8ca <printf>
    exit(0);
 188:	4501                	li	a0,0
 18a:	2d2000ef          	jal	45c <exit>
  }

  wait(0);
 18e:	4501                	li	a0,0
 190:	2d4000ef          	jal	464 <wait>
  printf("\nAll scheduler tests completed.\n");
 194:	00001517          	auipc	a0,0x1
 198:	b0450513          	addi	a0,a0,-1276 # c98 <malloc+0x312>
 19c:	72e000ef          	jal	8ca <printf>
  exit(0);
 1a0:	4501                	li	a0,0
 1a2:	2ba000ef          	jal	45c <exit>

00000000000001a6 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
 1a6:	1141                	addi	sp,sp,-16
 1a8:	e406                	sd	ra,8(sp)
 1aa:	e022                	sd	s0,0(sp)
 1ac:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
 1ae:	e99ff0ef          	jal	46 <main>
  exit(r);
 1b2:	2aa000ef          	jal	45c <exit>

00000000000001b6 <strcpy>:
}

char *
strcpy(char *s, const char *t)
{
 1b6:	1141                	addi	sp,sp,-16
 1b8:	e406                	sd	ra,8(sp)
 1ba:	e022                	sd	s0,0(sp)
 1bc:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while ((*s++ = *t++) != 0)
 1be:	87aa                	mv	a5,a0
 1c0:	0585                	addi	a1,a1,1
 1c2:	0785                	addi	a5,a5,1
 1c4:	fff5c703          	lbu	a4,-1(a1)
 1c8:	fee78fa3          	sb	a4,-1(a5)
 1cc:	fb75                	bnez	a4,1c0 <strcpy+0xa>
    ;
  return os;
}
 1ce:	60a2                	ld	ra,8(sp)
 1d0:	6402                	ld	s0,0(sp)
 1d2:	0141                	addi	sp,sp,16
 1d4:	8082                	ret

00000000000001d6 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 1d6:	1141                	addi	sp,sp,-16
 1d8:	e406                	sd	ra,8(sp)
 1da:	e022                	sd	s0,0(sp)
 1dc:	0800                	addi	s0,sp,16
  while (*p && *p == *q)
 1de:	00054783          	lbu	a5,0(a0)
 1e2:	cb91                	beqz	a5,1f6 <strcmp+0x20>
 1e4:	0005c703          	lbu	a4,0(a1)
 1e8:	00f71763          	bne	a4,a5,1f6 <strcmp+0x20>
    p++, q++;
 1ec:	0505                	addi	a0,a0,1
 1ee:	0585                	addi	a1,a1,1
  while (*p && *p == *q)
 1f0:	00054783          	lbu	a5,0(a0)
 1f4:	fbe5                	bnez	a5,1e4 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 1f6:	0005c503          	lbu	a0,0(a1)
}
 1fa:	40a7853b          	subw	a0,a5,a0
 1fe:	60a2                	ld	ra,8(sp)
 200:	6402                	ld	s0,0(sp)
 202:	0141                	addi	sp,sp,16
 204:	8082                	ret

0000000000000206 <strlen>:

uint
strlen(const char *s)
{
 206:	1141                	addi	sp,sp,-16
 208:	e406                	sd	ra,8(sp)
 20a:	e022                	sd	s0,0(sp)
 20c:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
 20e:	00054783          	lbu	a5,0(a0)
 212:	cf91                	beqz	a5,22e <strlen+0x28>
 214:	00150793          	addi	a5,a0,1
 218:	86be                	mv	a3,a5
 21a:	0785                	addi	a5,a5,1
 21c:	fff7c703          	lbu	a4,-1(a5)
 220:	ff65                	bnez	a4,218 <strlen+0x12>
 222:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 226:	60a2                	ld	ra,8(sp)
 228:	6402                	ld	s0,0(sp)
 22a:	0141                	addi	sp,sp,16
 22c:	8082                	ret
  for (n = 0; s[n]; n++)
 22e:	4501                	li	a0,0
 230:	bfdd                	j	226 <strlen+0x20>

0000000000000232 <memset>:

void *
memset(void *dst, int c, uint n)
{
 232:	1141                	addi	sp,sp,-16
 234:	e406                	sd	ra,8(sp)
 236:	e022                	sd	s0,0(sp)
 238:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
 23a:	ca19                	beqz	a2,250 <memset+0x1e>
 23c:	87aa                	mv	a5,a0
 23e:	1602                	slli	a2,a2,0x20
 240:	9201                	srli	a2,a2,0x20
 242:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 246:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
 24a:	0785                	addi	a5,a5,1
 24c:	fee79de3          	bne	a5,a4,246 <memset+0x14>
  }
  return dst;
}
 250:	60a2                	ld	ra,8(sp)
 252:	6402                	ld	s0,0(sp)
 254:	0141                	addi	sp,sp,16
 256:	8082                	ret

0000000000000258 <strchr>:

char *
strchr(const char *s, char c)
{
 258:	1141                	addi	sp,sp,-16
 25a:	e406                	sd	ra,8(sp)
 25c:	e022                	sd	s0,0(sp)
 25e:	0800                	addi	s0,sp,16
  for (; *s; s++)
 260:	00054783          	lbu	a5,0(a0)
 264:	c799                	beqz	a5,272 <strchr+0x1a>
    if (*s == c)
 266:	00f58763          	beq	a1,a5,274 <strchr+0x1c>
  for (; *s; s++)
 26a:	0505                	addi	a0,a0,1
 26c:	00054783          	lbu	a5,0(a0)
 270:	fbfd                	bnez	a5,266 <strchr+0xe>
      return (char *)s;
  return 0;
 272:	4501                	li	a0,0
}
 274:	60a2                	ld	ra,8(sp)
 276:	6402                	ld	s0,0(sp)
 278:	0141                	addi	sp,sp,16
 27a:	8082                	ret

000000000000027c <gets>:

char *
gets(char *buf, int max)
{
 27c:	711d                	addi	sp,sp,-96
 27e:	ec86                	sd	ra,88(sp)
 280:	e8a2                	sd	s0,80(sp)
 282:	e4a6                	sd	s1,72(sp)
 284:	e0ca                	sd	s2,64(sp)
 286:	fc4e                	sd	s3,56(sp)
 288:	f852                	sd	s4,48(sp)
 28a:	f456                	sd	s5,40(sp)
 28c:	f05a                	sd	s6,32(sp)
 28e:	ec5e                	sd	s7,24(sp)
 290:	e862                	sd	s8,16(sp)
 292:	1080                	addi	s0,sp,96
 294:	8baa                	mv	s7,a0
 296:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for (i = 0; i + 1 < max;) {
 298:	892a                	mv	s2,a0
 29a:	4481                	li	s1,0
    cc = read(0, &c, 1);
 29c:	faf40b13          	addi	s6,s0,-81
 2a0:	4a85                	li	s5,1
  for (i = 0; i + 1 < max;) {
 2a2:	8c26                	mv	s8,s1
 2a4:	0014899b          	addiw	s3,s1,1
 2a8:	84ce                	mv	s1,s3
 2aa:	0349d863          	bge	s3,s4,2da <gets+0x5e>
    cc = read(0, &c, 1);
 2ae:	8656                	mv	a2,s5
 2b0:	85da                	mv	a1,s6
 2b2:	4501                	li	a0,0
 2b4:	1c0000ef          	jal	474 <read>
    if (cc < 1)
 2b8:	02a05163          	blez	a0,2da <gets+0x5e>
      break;
    buf[i++] = c;
 2bc:	faf44783          	lbu	a5,-81(s0)
 2c0:	00f90023          	sb	a5,0(s2)
    if (c == '\n' || c == '\r')
 2c4:	0905                	addi	s2,s2,1
 2c6:	ff678713          	addi	a4,a5,-10
 2ca:	00173713          	seqz	a4,a4
 2ce:	17cd                	addi	a5,a5,-13
 2d0:	0017b793          	seqz	a5,a5
 2d4:	8fd9                	or	a5,a5,a4
 2d6:	d7f1                	beqz	a5,2a2 <gets+0x26>
    buf[i++] = c;
 2d8:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 2da:	9c5e                	add	s8,s8,s7
 2dc:	000c0023          	sb	zero,0(s8)
  return buf;
}
 2e0:	855e                	mv	a0,s7
 2e2:	60e6                	ld	ra,88(sp)
 2e4:	6446                	ld	s0,80(sp)
 2e6:	64a6                	ld	s1,72(sp)
 2e8:	6906                	ld	s2,64(sp)
 2ea:	79e2                	ld	s3,56(sp)
 2ec:	7a42                	ld	s4,48(sp)
 2ee:	7aa2                	ld	s5,40(sp)
 2f0:	7b02                	ld	s6,32(sp)
 2f2:	6be2                	ld	s7,24(sp)
 2f4:	6c42                	ld	s8,16(sp)
 2f6:	6125                	addi	sp,sp,96
 2f8:	8082                	ret

00000000000002fa <stat>:

int
stat(const char *n, struct stat *st)
{
 2fa:	1101                	addi	sp,sp,-32
 2fc:	ec06                	sd	ra,24(sp)
 2fe:	e822                	sd	s0,16(sp)
 300:	e04a                	sd	s2,0(sp)
 302:	1000                	addi	s0,sp,32
 304:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 306:	4581                	li	a1,0
 308:	194000ef          	jal	49c <open>
  if (fd < 0)
 30c:	02054263          	bltz	a0,330 <stat+0x36>
 310:	e426                	sd	s1,8(sp)
 312:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 314:	85ca                	mv	a1,s2
 316:	19e000ef          	jal	4b4 <fstat>
 31a:	892a                	mv	s2,a0
  close(fd);
 31c:	8526                	mv	a0,s1
 31e:	166000ef          	jal	484 <close>
  return r;
 322:	64a2                	ld	s1,8(sp)
}
 324:	854a                	mv	a0,s2
 326:	60e2                	ld	ra,24(sp)
 328:	6442                	ld	s0,16(sp)
 32a:	6902                	ld	s2,0(sp)
 32c:	6105                	addi	sp,sp,32
 32e:	8082                	ret
    return -1;
 330:	57fd                	li	a5,-1
 332:	893e                	mv	s2,a5
 334:	bfc5                	j	324 <stat+0x2a>

0000000000000336 <atoi>:

int
atoi(const char *s)
{
 336:	1141                	addi	sp,sp,-16
 338:	e406                	sd	ra,8(sp)
 33a:	e022                	sd	s0,0(sp)
 33c:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while ('0' <= *s && *s <= '9')
 33e:	00054683          	lbu	a3,0(a0)
 342:	fd06879b          	addiw	a5,a3,-48
 346:	0ff7f793          	zext.b	a5,a5
 34a:	4625                	li	a2,9
 34c:	02f66963          	bltu	a2,a5,37e <atoi+0x48>
 350:	872a                	mv	a4,a0
  n = 0;
 352:	4501                	li	a0,0
    n = n * 10 + *s++ - '0';
 354:	0705                	addi	a4,a4,1
 356:	0025179b          	slliw	a5,a0,0x2
 35a:	9fa9                	addw	a5,a5,a0
 35c:	0017979b          	slliw	a5,a5,0x1
 360:	9fb5                	addw	a5,a5,a3
 362:	fd07851b          	addiw	a0,a5,-48
  while ('0' <= *s && *s <= '9')
 366:	00074683          	lbu	a3,0(a4)
 36a:	fd06879b          	addiw	a5,a3,-48
 36e:	0ff7f793          	zext.b	a5,a5
 372:	fef671e3          	bgeu	a2,a5,354 <atoi+0x1e>
  return n;
}
 376:	60a2                	ld	ra,8(sp)
 378:	6402                	ld	s0,0(sp)
 37a:	0141                	addi	sp,sp,16
 37c:	8082                	ret
  n = 0;
 37e:	4501                	li	a0,0
 380:	bfdd                	j	376 <atoi+0x40>

0000000000000382 <memmove>:

void *
memmove(void *vdst, const void *vsrc, int n)
{
 382:	1141                	addi	sp,sp,-16
 384:	e406                	sd	ra,8(sp)
 386:	e022                	sd	s0,0(sp)
 388:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 38a:	02b57563          	bgeu	a0,a1,3b4 <memmove+0x32>
    while (n-- > 0)
 38e:	00c05f63          	blez	a2,3ac <memmove+0x2a>
 392:	1602                	slli	a2,a2,0x20
 394:	9201                	srli	a2,a2,0x20
 396:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 39a:	872a                	mv	a4,a0
      *dst++ = *src++;
 39c:	0585                	addi	a1,a1,1
 39e:	0705                	addi	a4,a4,1
 3a0:	fff5c683          	lbu	a3,-1(a1)
 3a4:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
 3a8:	fee79ae3          	bne	a5,a4,39c <memmove+0x1a>
    src += n;
    while (n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 3ac:	60a2                	ld	ra,8(sp)
 3ae:	6402                	ld	s0,0(sp)
 3b0:	0141                	addi	sp,sp,16
 3b2:	8082                	ret
    while (n-- > 0)
 3b4:	fec05ce3          	blez	a2,3ac <memmove+0x2a>
    dst += n;
 3b8:	00c50733          	add	a4,a0,a2
    src += n;
 3bc:	95b2                	add	a1,a1,a2
 3be:	fff6079b          	addiw	a5,a2,-1
 3c2:	1782                	slli	a5,a5,0x20
 3c4:	9381                	srli	a5,a5,0x20
 3c6:	fff7c793          	not	a5,a5
 3ca:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 3cc:	15fd                	addi	a1,a1,-1
 3ce:	177d                	addi	a4,a4,-1
 3d0:	0005c683          	lbu	a3,0(a1)
 3d4:	00d70023          	sb	a3,0(a4)
    while (n-- > 0)
 3d8:	fef71ae3          	bne	a4,a5,3cc <memmove+0x4a>
 3dc:	bfc1                	j	3ac <memmove+0x2a>

00000000000003de <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 3de:	1141                	addi	sp,sp,-16
 3e0:	e406                	sd	ra,8(sp)
 3e2:	e022                	sd	s0,0(sp)
 3e4:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 3e6:	ce19                	beqz	a2,404 <memcmp+0x26>
 3e8:	1602                	slli	a2,a2,0x20
 3ea:	9201                	srli	a2,a2,0x20
 3ec:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 3f0:	00054783          	lbu	a5,0(a0)
 3f4:	0005c703          	lbu	a4,0(a1)
 3f8:	00e79b63          	bne	a5,a4,40e <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
 3fc:	0505                	addi	a0,a0,1
    p2++;
 3fe:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 400:	fed518e3          	bne	a0,a3,3f0 <memcmp+0x12>
  }
  return 0;
 404:	4501                	li	a0,0
}
 406:	60a2                	ld	ra,8(sp)
 408:	6402                	ld	s0,0(sp)
 40a:	0141                	addi	sp,sp,16
 40c:	8082                	ret
      return *p1 - *p2;
 40e:	40e7853b          	subw	a0,a5,a4
 412:	bfd5                	j	406 <memcmp+0x28>

0000000000000414 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 414:	1141                	addi	sp,sp,-16
 416:	e406                	sd	ra,8(sp)
 418:	e022                	sd	s0,0(sp)
 41a:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 41c:	f67ff0ef          	jal	382 <memmove>
}
 420:	60a2                	ld	ra,8(sp)
 422:	6402                	ld	s0,0(sp)
 424:	0141                	addi	sp,sp,16
 426:	8082                	ret

0000000000000428 <sbrk>:

char *
sbrk(int n)
{
 428:	1141                	addi	sp,sp,-16
 42a:	e406                	sd	ra,8(sp)
 42c:	e022                	sd	s0,0(sp)
 42e:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 430:	4585                	li	a1,1
 432:	0ba000ef          	jal	4ec <sys_sbrk>
}
 436:	60a2                	ld	ra,8(sp)
 438:	6402                	ld	s0,0(sp)
 43a:	0141                	addi	sp,sp,16
 43c:	8082                	ret

000000000000043e <sbrklazy>:

char *
sbrklazy(int n)
{
 43e:	1141                	addi	sp,sp,-16
 440:	e406                	sd	ra,8(sp)
 442:	e022                	sd	s0,0(sp)
 444:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 446:	4589                	li	a1,2
 448:	0a4000ef          	jal	4ec <sys_sbrk>
}
 44c:	60a2                	ld	ra,8(sp)
 44e:	6402                	ld	s0,0(sp)
 450:	0141                	addi	sp,sp,16
 452:	8082                	ret

0000000000000454 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 454:	4885                	li	a7,1
 ecall
 456:	00000073          	ecall
 ret
 45a:	8082                	ret

000000000000045c <exit>:
.global exit
exit:
 li a7, SYS_exit
 45c:	4889                	li	a7,2
 ecall
 45e:	00000073          	ecall
 ret
 462:	8082                	ret

0000000000000464 <wait>:
.global wait
wait:
 li a7, SYS_wait
 464:	488d                	li	a7,3
 ecall
 466:	00000073          	ecall
 ret
 46a:	8082                	ret

000000000000046c <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 46c:	4891                	li	a7,4
 ecall
 46e:	00000073          	ecall
 ret
 472:	8082                	ret

0000000000000474 <read>:
.global read
read:
 li a7, SYS_read
 474:	4895                	li	a7,5
 ecall
 476:	00000073          	ecall
 ret
 47a:	8082                	ret

000000000000047c <write>:
.global write
write:
 li a7, SYS_write
 47c:	48c1                	li	a7,16
 ecall
 47e:	00000073          	ecall
 ret
 482:	8082                	ret

0000000000000484 <close>:
.global close
close:
 li a7, SYS_close
 484:	48d5                	li	a7,21
 ecall
 486:	00000073          	ecall
 ret
 48a:	8082                	ret

000000000000048c <kill>:
.global kill
kill:
 li a7, SYS_kill
 48c:	4899                	li	a7,6
 ecall
 48e:	00000073          	ecall
 ret
 492:	8082                	ret

0000000000000494 <exec>:
.global exec
exec:
 li a7, SYS_exec
 494:	489d                	li	a7,7
 ecall
 496:	00000073          	ecall
 ret
 49a:	8082                	ret

000000000000049c <open>:
.global open
open:
 li a7, SYS_open
 49c:	48bd                	li	a7,15
 ecall
 49e:	00000073          	ecall
 ret
 4a2:	8082                	ret

00000000000004a4 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 4a4:	48c5                	li	a7,17
 ecall
 4a6:	00000073          	ecall
 ret
 4aa:	8082                	ret

00000000000004ac <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 4ac:	48c9                	li	a7,18
 ecall
 4ae:	00000073          	ecall
 ret
 4b2:	8082                	ret

00000000000004b4 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 4b4:	48a1                	li	a7,8
 ecall
 4b6:	00000073          	ecall
 ret
 4ba:	8082                	ret

00000000000004bc <link>:
.global link
link:
 li a7, SYS_link
 4bc:	48cd                	li	a7,19
 ecall
 4be:	00000073          	ecall
 ret
 4c2:	8082                	ret

00000000000004c4 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 4c4:	48d1                	li	a7,20
 ecall
 4c6:	00000073          	ecall
 ret
 4ca:	8082                	ret

00000000000004cc <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 4cc:	48a5                	li	a7,9
 ecall
 4ce:	00000073          	ecall
 ret
 4d2:	8082                	ret

00000000000004d4 <dup>:
.global dup
dup:
 li a7, SYS_dup
 4d4:	48a9                	li	a7,10
 ecall
 4d6:	00000073          	ecall
 ret
 4da:	8082                	ret

00000000000004dc <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 4dc:	48ad                	li	a7,11
 ecall
 4de:	00000073          	ecall
 ret
 4e2:	8082                	ret

00000000000004e4 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 4e4:	48e1                	li	a7,24
 ecall
 4e6:	00000073          	ecall
 ret
 4ea:	8082                	ret

00000000000004ec <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 4ec:	48b1                	li	a7,12
 ecall
 4ee:	00000073          	ecall
 ret
 4f2:	8082                	ret

00000000000004f4 <pause>:
.global pause
pause:
 li a7, SYS_pause
 4f4:	48b5                	li	a7,13
 ecall
 4f6:	00000073          	ecall
 ret
 4fa:	8082                	ret

00000000000004fc <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 4fc:	48b9                	li	a7,14
 ecall
 4fe:	00000073          	ecall
 ret
 502:	8082                	ret

0000000000000504 <sync>:
.global sync
sync:
 li a7, SYS_sync
 504:	48d9                	li	a7,22
 ecall
 506:	00000073          	ecall
 ret
 50a:	8082                	ret

000000000000050c <setpriority>:
.global setpriority
setpriority:
 li a7, SYS_setpriority
 50c:	48dd                	li	a7,23
 ecall
 50e:	00000073          	ecall
 ret
 512:	8082                	ret

0000000000000514 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 514:	1101                	addi	sp,sp,-32
 516:	ec06                	sd	ra,24(sp)
 518:	e822                	sd	s0,16(sp)
 51a:	1000                	addi	s0,sp,32
 51c:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 520:	4605                	li	a2,1
 522:	fef40593          	addi	a1,s0,-17
 526:	f57ff0ef          	jal	47c <write>
}
 52a:	60e2                	ld	ra,24(sp)
 52c:	6442                	ld	s0,16(sp)
 52e:	6105                	addi	sp,sp,32
 530:	8082                	ret

0000000000000532 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 532:	715d                	addi	sp,sp,-80
 534:	e486                	sd	ra,72(sp)
 536:	e0a2                	sd	s0,64(sp)
 538:	f84a                	sd	s2,48(sp)
 53a:	f44e                	sd	s3,40(sp)
 53c:	0880                	addi	s0,sp,80
 53e:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if (sgn && xx < 0) {
 540:	00d036b3          	snez	a3,a3
 544:	03f5d793          	srli	a5,a1,0x3f
 548:	8efd                	and	a3,a3,a5
  neg = 0;
 54a:	4301                	li	t1,0
  if (sgn && xx < 0) {
 54c:	c681                	beqz	a3,554 <printint+0x22>
    neg = 1;
    x = -xx;
 54e:	40b005b3          	neg	a1,a1
    neg = 1;
 552:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 554:	fb840993          	addi	s3,s0,-72
  neg = 0;
 558:	86ce                	mv	a3,s3
  i = 0;
 55a:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
 55c:	00000817          	auipc	a6,0x0
 560:	76c80813          	addi	a6,a6,1900 # cc8 <digits>
 564:	88ba                	mv	a7,a4
 566:	0017051b          	addiw	a0,a4,1
 56a:	872a                	mv	a4,a0
 56c:	02c5f7b3          	remu	a5,a1,a2
 570:	97c2                	add	a5,a5,a6
 572:	0007c783          	lbu	a5,0(a5)
 576:	00f68023          	sb	a5,0(a3)
  } while ((x /= base) != 0);
 57a:	87ae                	mv	a5,a1
 57c:	02c5d5b3          	divu	a1,a1,a2
 580:	0685                	addi	a3,a3,1
 582:	fec7f1e3          	bgeu	a5,a2,564 <printint+0x32>
  if (neg)
 586:	00030b63          	beqz	t1,59c <printint+0x6a>
    buf[i++] = '-';
 58a:	fd040793          	addi	a5,s0,-48
 58e:	953e                	add	a0,a0,a5
 590:	02d00793          	li	a5,45
 594:	fef50423          	sb	a5,-24(a0)
 598:	0028871b          	addiw	a4,a7,2

  while (--i >= 0)
 59c:	02e05563          	blez	a4,5c6 <printint+0x94>
 5a0:	fc26                	sd	s1,56(sp)
 5a2:	377d                	addiw	a4,a4,-1
 5a4:	00e984b3          	add	s1,s3,a4
 5a8:	19fd                	addi	s3,s3,-1
 5aa:	99ba                	add	s3,s3,a4
 5ac:	1702                	slli	a4,a4,0x20
 5ae:	9301                	srli	a4,a4,0x20
 5b0:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 5b4:	0004c583          	lbu	a1,0(s1)
 5b8:	854a                	mv	a0,s2
 5ba:	f5bff0ef          	jal	514 <putc>
  while (--i >= 0)
 5be:	14fd                	addi	s1,s1,-1
 5c0:	ff349ae3          	bne	s1,s3,5b4 <printint+0x82>
 5c4:	74e2                	ld	s1,56(sp)
}
 5c6:	60a6                	ld	ra,72(sp)
 5c8:	6406                	ld	s0,64(sp)
 5ca:	7942                	ld	s2,48(sp)
 5cc:	79a2                	ld	s3,40(sp)
 5ce:	6161                	addi	sp,sp,80
 5d0:	8082                	ret

00000000000005d2 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 5d2:	711d                	addi	sp,sp,-96
 5d4:	ec86                	sd	ra,88(sp)
 5d6:	e8a2                	sd	s0,80(sp)
 5d8:	e4a6                	sd	s1,72(sp)
 5da:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for (i = 0; fmt[i]; i++) {
 5dc:	0005c483          	lbu	s1,0(a1)
 5e0:	2a048063          	beqz	s1,880 <vprintf+0x2ae>
 5e4:	e0ca                	sd	s2,64(sp)
 5e6:	fc4e                	sd	s3,56(sp)
 5e8:	f852                	sd	s4,48(sp)
 5ea:	f456                	sd	s5,40(sp)
 5ec:	f05a                	sd	s6,32(sp)
 5ee:	ec5e                	sd	s7,24(sp)
 5f0:	e862                	sd	s8,16(sp)
 5f2:	8b2a                	mv	s6,a0
 5f4:	8a2e                	mv	s4,a1
 5f6:	8bb2                	mv	s7,a2
  state = 0;
 5f8:	4981                	li	s3,0
  for (i = 0; fmt[i]; i++) {
 5fa:	4901                	li	s2,0
 5fc:	4701                	li	a4,0
      if (c0 == '%') {
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if (state == '%') {
 5fe:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if (c0)
        c1 = fmt[i + 1] & 0xff;
      if (c1)
        c2 = fmt[i + 2] & 0xff;
      if (c0 == 'd') {
 602:	06400c13          	li	s8,100
 606:	a00d                	j	628 <vprintf+0x56>
        putc(fd, c0);
 608:	85a6                	mv	a1,s1
 60a:	855a                	mv	a0,s6
 60c:	f09ff0ef          	jal	514 <putc>
 610:	a019                	j	616 <vprintf+0x44>
    } else if (state == '%') {
 612:	03598363          	beq	s3,s5,638 <vprintf+0x66>
  for (i = 0; fmt[i]; i++) {
 616:	0019079b          	addiw	a5,s2,1
 61a:	893e                	mv	s2,a5
 61c:	873e                	mv	a4,a5
 61e:	97d2                	add	a5,a5,s4
 620:	0007c483          	lbu	s1,0(a5)
 624:	24048763          	beqz	s1,872 <vprintf+0x2a0>
    c0 = fmt[i] & 0xff;
 628:	0004879b          	sext.w	a5,s1
    if (state == 0) {
 62c:	fe0993e3          	bnez	s3,612 <vprintf+0x40>
      if (c0 == '%') {
 630:	fd579ce3          	bne	a5,s5,608 <vprintf+0x36>
        state = '%';
 634:	89be                	mv	s3,a5
 636:	b7c5                	j	616 <vprintf+0x44>
        c1 = fmt[i + 1] & 0xff;
 638:	00ea06b3          	add	a3,s4,a4
 63c:	0016c603          	lbu	a2,1(a3)
      if (c1)
 640:	24060563          	beqz	a2,88a <vprintf+0x2b8>
      if (c0 == 'd') {
 644:	0b878763          	beq	a5,s8,6f2 <vprintf+0x120>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if (c0 == 'l' && c1 == 'd') {
 648:	f9478693          	addi	a3,a5,-108
 64c:	0016b693          	seqz	a3,a3
 650:	f9c60593          	addi	a1,a2,-100
 654:	0015b593          	seqz	a1,a1
 658:	8df5                	and	a1,a1,a3
 65a:	e9c5                	bnez	a1,70a <vprintf+0x138>
        c2 = fmt[i + 2] & 0xff;
 65c:	9752                	add	a4,a4,s4
 65e:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
 662:	f9460713          	addi	a4,a2,-108
 666:	00173713          	seqz	a4,a4
 66a:	8f75                	and	a4,a4,a3
 66c:	f9c50593          	addi	a1,a0,-100
 670:	0015b593          	seqz	a1,a1
 674:	8df9                	and	a1,a1,a4
 676:	e5dd                	bnez	a1,724 <vprintf+0x152>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if (c0 == 'u') {
 678:	07500593          	li	a1,117
 67c:	0cb78163          	beq	a5,a1,73e <vprintf+0x16c>
        printint(fd, va_arg(ap, uint32), 10, 0);
      } else if (c0 == 'l' && c1 == 'u') {
 680:	f8b60593          	addi	a1,a2,-117
 684:	0015b593          	seqz	a1,a1
 688:	8df5                	and	a1,a1,a3
 68a:	e5f1                	bnez	a1,756 <vprintf+0x184>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
 68c:	f8b50593          	addi	a1,a0,-117
 690:	0015b593          	seqz	a1,a1
 694:	8df9                	and	a1,a1,a4
 696:	ede9                	bnez	a1,770 <vprintf+0x19e>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if (c0 == 'x') {
 698:	07800593          	li	a1,120
 69c:	0eb78763          	beq	a5,a1,78a <vprintf+0x1b8>
        printint(fd, va_arg(ap, uint32), 16, 0);
      } else if (c0 == 'l' && c1 == 'x') {
 6a0:	f8860613          	addi	a2,a2,-120
 6a4:	00163613          	seqz	a2,a2
 6a8:	8ef1                	and	a3,a3,a2
 6aa:	0e069c63          	bnez	a3,7a2 <vprintf+0x1d0>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
 6ae:	f8850513          	addi	a0,a0,-120
 6b2:	00153513          	seqz	a0,a0
 6b6:	8f69                	and	a4,a4,a0
 6b8:	10071263          	bnez	a4,7bc <vprintf+0x1ea>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if (c0 == 'p') {
 6bc:	07000713          	li	a4,112
 6c0:	10e78a63          	beq	a5,a4,7d4 <vprintf+0x202>
        printptr(fd, va_arg(ap, uint64));
      } else if (c0 == 'c') {
 6c4:	06300713          	li	a4,99
 6c8:	14e78a63          	beq	a5,a4,81c <vprintf+0x24a>
        putc(fd, va_arg(ap, uint32));
      } else if (c0 == 's') {
 6cc:	07300713          	li	a4,115
 6d0:	16e78063          	beq	a5,a4,830 <vprintf+0x25e>
        if ((s = va_arg(ap, char *)) == 0)
          s = "(null)";
        for (; *s; s++)
          putc(fd, *s);
      } else if (c0 == '%') {
 6d4:	02500713          	li	a4,37
 6d8:	18e78863          	beq	a5,a4,868 <vprintf+0x296>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 6dc:	02500593          	li	a1,37
 6e0:	855a                	mv	a0,s6
 6e2:	e33ff0ef          	jal	514 <putc>
        putc(fd, c0);
 6e6:	85a6                	mv	a1,s1
 6e8:	855a                	mv	a0,s6
 6ea:	e2bff0ef          	jal	514 <putc>
      }

      state = 0;
 6ee:	4981                	li	s3,0
 6f0:	b71d                	j	616 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 6f2:	008b8493          	addi	s1,s7,8
 6f6:	4685                	li	a3,1
 6f8:	4629                	li	a2,10
 6fa:	000ba583          	lw	a1,0(s7)
 6fe:	855a                	mv	a0,s6
 700:	e33ff0ef          	jal	532 <printint>
 704:	8ba6                	mv	s7,s1
      state = 0;
 706:	4981                	li	s3,0
 708:	b739                	j	616 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 70a:	008b8493          	addi	s1,s7,8
 70e:	4685                	li	a3,1
 710:	4629                	li	a2,10
 712:	000bb583          	ld	a1,0(s7)
 716:	855a                	mv	a0,s6
 718:	e1bff0ef          	jal	532 <printint>
        i += 1;
 71c:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 71e:	8ba6                	mv	s7,s1
      state = 0;
 720:	4981                	li	s3,0
 722:	bdd5                	j	616 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 724:	008b8493          	addi	s1,s7,8
 728:	4685                	li	a3,1
 72a:	4629                	li	a2,10
 72c:	000bb583          	ld	a1,0(s7)
 730:	855a                	mv	a0,s6
 732:	e01ff0ef          	jal	532 <printint>
        i += 2;
 736:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 738:	8ba6                	mv	s7,s1
      state = 0;
 73a:	4981                	li	s3,0
        i += 2;
 73c:	bde9                	j	616 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 10, 0);
 73e:	008b8493          	addi	s1,s7,8
 742:	4681                	li	a3,0
 744:	4629                	li	a2,10
 746:	000be583          	lwu	a1,0(s7)
 74a:	855a                	mv	a0,s6
 74c:	de7ff0ef          	jal	532 <printint>
 750:	8ba6                	mv	s7,s1
      state = 0;
 752:	4981                	li	s3,0
 754:	b5c9                	j	616 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 756:	008b8493          	addi	s1,s7,8
 75a:	4681                	li	a3,0
 75c:	4629                	li	a2,10
 75e:	000bb583          	ld	a1,0(s7)
 762:	855a                	mv	a0,s6
 764:	dcfff0ef          	jal	532 <printint>
        i += 1;
 768:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 76a:	8ba6                	mv	s7,s1
      state = 0;
 76c:	4981                	li	s3,0
 76e:	b565                	j	616 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 770:	008b8493          	addi	s1,s7,8
 774:	4681                	li	a3,0
 776:	4629                	li	a2,10
 778:	000bb583          	ld	a1,0(s7)
 77c:	855a                	mv	a0,s6
 77e:	db5ff0ef          	jal	532 <printint>
        i += 2;
 782:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 784:	8ba6                	mv	s7,s1
      state = 0;
 786:	4981                	li	s3,0
        i += 2;
 788:	b579                	j	616 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 16, 0);
 78a:	008b8493          	addi	s1,s7,8
 78e:	4681                	li	a3,0
 790:	4641                	li	a2,16
 792:	000be583          	lwu	a1,0(s7)
 796:	855a                	mv	a0,s6
 798:	d9bff0ef          	jal	532 <printint>
 79c:	8ba6                	mv	s7,s1
      state = 0;
 79e:	4981                	li	s3,0
 7a0:	bd9d                	j	616 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 7a2:	008b8493          	addi	s1,s7,8
 7a6:	4681                	li	a3,0
 7a8:	4641                	li	a2,16
 7aa:	000bb583          	ld	a1,0(s7)
 7ae:	855a                	mv	a0,s6
 7b0:	d83ff0ef          	jal	532 <printint>
        i += 1;
 7b4:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 7b6:	8ba6                	mv	s7,s1
      state = 0;
 7b8:	4981                	li	s3,0
 7ba:	bdb1                	j	616 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 7bc:	008b8493          	addi	s1,s7,8
 7c0:	4641                	li	a2,16
 7c2:	000bb583          	ld	a1,0(s7)
 7c6:	855a                	mv	a0,s6
 7c8:	d6bff0ef          	jal	532 <printint>
        i += 2;
 7cc:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 7ce:	8ba6                	mv	s7,s1
      state = 0;
 7d0:	4981                	li	s3,0
        i += 2;
 7d2:	b591                	j	616 <vprintf+0x44>
 7d4:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 7d6:	008b8793          	addi	a5,s7,8
 7da:	8cbe                	mv	s9,a5
 7dc:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 7e0:	03000593          	li	a1,48
 7e4:	855a                	mv	a0,s6
 7e6:	d2fff0ef          	jal	514 <putc>
  putc(fd, 'x');
 7ea:	07800593          	li	a1,120
 7ee:	855a                	mv	a0,s6
 7f0:	d25ff0ef          	jal	514 <putc>
 7f4:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 7f6:	00000b97          	auipc	s7,0x0
 7fa:	4d2b8b93          	addi	s7,s7,1234 # cc8 <digits>
 7fe:	03c9d793          	srli	a5,s3,0x3c
 802:	97de                	add	a5,a5,s7
 804:	0007c583          	lbu	a1,0(a5)
 808:	855a                	mv	a0,s6
 80a:	d0bff0ef          	jal	514 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 80e:	0992                	slli	s3,s3,0x4
 810:	34fd                	addiw	s1,s1,-1
 812:	f4f5                	bnez	s1,7fe <vprintf+0x22c>
        printptr(fd, va_arg(ap, uint64));
 814:	8be6                	mv	s7,s9
      state = 0;
 816:	4981                	li	s3,0
 818:	6ca2                	ld	s9,8(sp)
 81a:	bbf5                	j	616 <vprintf+0x44>
        putc(fd, va_arg(ap, uint32));
 81c:	008b8493          	addi	s1,s7,8
 820:	000bc583          	lbu	a1,0(s7)
 824:	855a                	mv	a0,s6
 826:	cefff0ef          	jal	514 <putc>
 82a:	8ba6                	mv	s7,s1
      state = 0;
 82c:	4981                	li	s3,0
 82e:	b3e5                	j	616 <vprintf+0x44>
        if ((s = va_arg(ap, char *)) == 0)
 830:	008b8993          	addi	s3,s7,8
 834:	000bb483          	ld	s1,0(s7)
 838:	cc91                	beqz	s1,854 <vprintf+0x282>
        for (; *s; s++)
 83a:	0004c583          	lbu	a1,0(s1)
 83e:	c195                	beqz	a1,862 <vprintf+0x290>
          putc(fd, *s);
 840:	855a                	mv	a0,s6
 842:	cd3ff0ef          	jal	514 <putc>
        for (; *s; s++)
 846:	0485                	addi	s1,s1,1
 848:	0004c583          	lbu	a1,0(s1)
 84c:	f9f5                	bnez	a1,840 <vprintf+0x26e>
        if ((s = va_arg(ap, char *)) == 0)
 84e:	8bce                	mv	s7,s3
      state = 0;
 850:	4981                	li	s3,0
 852:	b3d1                	j	616 <vprintf+0x44>
          s = "(null)";
 854:	00000497          	auipc	s1,0x0
 858:	46c48493          	addi	s1,s1,1132 # cc0 <malloc+0x33a>
        for (; *s; s++)
 85c:	02800593          	li	a1,40
 860:	b7c5                	j	840 <vprintf+0x26e>
        if ((s = va_arg(ap, char *)) == 0)
 862:	8bce                	mv	s7,s3
      state = 0;
 864:	4981                	li	s3,0
 866:	bb45                	j	616 <vprintf+0x44>
        putc(fd, '%');
 868:	85be                	mv	a1,a5
 86a:	855a                	mv	a0,s6
 86c:	ca9ff0ef          	jal	514 <putc>
 870:	bdbd                	j	6ee <vprintf+0x11c>
 872:	6906                	ld	s2,64(sp)
 874:	79e2                	ld	s3,56(sp)
 876:	7a42                	ld	s4,48(sp)
 878:	7aa2                	ld	s5,40(sp)
 87a:	7b02                	ld	s6,32(sp)
 87c:	6be2                	ld	s7,24(sp)
 87e:	6c42                	ld	s8,16(sp)
    }
  }
}
 880:	60e6                	ld	ra,88(sp)
 882:	6446                	ld	s0,80(sp)
 884:	64a6                	ld	s1,72(sp)
 886:	6125                	addi	sp,sp,96
 888:	8082                	ret
      if (c0 == 'd') {
 88a:	06400713          	li	a4,100
 88e:	e6e782e3          	beq	a5,a4,6f2 <vprintf+0x120>
      } else if (c0 == 'l' && c1 == 'd') {
 892:	f9478693          	addi	a3,a5,-108
 896:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 89a:	8532                	mv	a0,a2
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
 89c:	4701                	li	a4,0
 89e:	bbe9                	j	678 <vprintf+0xa6>

00000000000008a0 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 8a0:	715d                	addi	sp,sp,-80
 8a2:	ec06                	sd	ra,24(sp)
 8a4:	e822                	sd	s0,16(sp)
 8a6:	1000                	addi	s0,sp,32
 8a8:	e010                	sd	a2,0(s0)
 8aa:	e414                	sd	a3,8(s0)
 8ac:	e818                	sd	a4,16(s0)
 8ae:	ec1c                	sd	a5,24(s0)
 8b0:	03043023          	sd	a6,32(s0)
 8b4:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 8b8:	8622                	mv	a2,s0
 8ba:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 8be:	d15ff0ef          	jal	5d2 <vprintf>
}
 8c2:	60e2                	ld	ra,24(sp)
 8c4:	6442                	ld	s0,16(sp)
 8c6:	6161                	addi	sp,sp,80
 8c8:	8082                	ret

00000000000008ca <printf>:

void
printf(const char *fmt, ...)
{
 8ca:	711d                	addi	sp,sp,-96
 8cc:	ec06                	sd	ra,24(sp)
 8ce:	e822                	sd	s0,16(sp)
 8d0:	1000                	addi	s0,sp,32
 8d2:	e40c                	sd	a1,8(s0)
 8d4:	e810                	sd	a2,16(s0)
 8d6:	ec14                	sd	a3,24(s0)
 8d8:	f018                	sd	a4,32(s0)
 8da:	f41c                	sd	a5,40(s0)
 8dc:	03043823          	sd	a6,48(s0)
 8e0:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 8e4:	00840613          	addi	a2,s0,8
 8e8:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 8ec:	85aa                	mv	a1,a0
 8ee:	4505                	li	a0,1
 8f0:	ce3ff0ef          	jal	5d2 <vprintf>
}
 8f4:	60e2                	ld	ra,24(sp)
 8f6:	6442                	ld	s0,16(sp)
 8f8:	6125                	addi	sp,sp,96
 8fa:	8082                	ret

00000000000008fc <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 8fc:	1141                	addi	sp,sp,-16
 8fe:	e406                	sd	ra,8(sp)
 900:	e022                	sd	s0,0(sp)
 902:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header *)ap - 1;
 904:	ff050713          	addi	a4,a0,-16
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 908:	00000797          	auipc	a5,0x0
 90c:	6f87b783          	ld	a5,1784(a5) # 1000 <freep>
 910:	a095                	j	974 <free+0x78>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if (bp + bp->s.size == p->s.ptr) {
 912:	ff852583          	lw	a1,-8(a0)
 916:	6390                	ld	a2,0(a5)
 918:	02059813          	slli	a6,a1,0x20
 91c:	01c85693          	srli	a3,a6,0x1c
 920:	96ba                	add	a3,a3,a4
 922:	02d60563          	beq	a2,a3,94c <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 926:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if (p + p->s.size == bp) {
 92a:	4790                	lw	a2,8(a5)
 92c:	02061593          	slli	a1,a2,0x20
 930:	01c5d693          	srli	a3,a1,0x1c
 934:	96be                	add	a3,a3,a5
 936:	02d70263          	beq	a4,a3,95a <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 93a:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 93c:	00000717          	auipc	a4,0x0
 940:	6cf73223          	sd	a5,1732(a4) # 1000 <freep>
}
 944:	60a2                	ld	ra,8(sp)
 946:	6402                	ld	s0,0(sp)
 948:	0141                	addi	sp,sp,16
 94a:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 94c:	4614                	lw	a3,8(a2)
 94e:	9ead                	addw	a3,a3,a1
 950:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 954:	6394                	ld	a3,0(a5)
 956:	6290                	ld	a2,0(a3)
 958:	b7f9                	j	926 <free+0x2a>
    p->s.size += bp->s.size;
 95a:	ff852703          	lw	a4,-8(a0)
 95e:	9f31                	addw	a4,a4,a2
 960:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 962:	ff053703          	ld	a4,-16(a0)
 966:	bfd1                	j	93a <free+0x3e>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 968:	6394                	ld	a3,0(a5)
 96a:	00d7e463          	bltu	a5,a3,972 <free+0x76>
 96e:	fad762e3          	bltu	a4,a3,912 <free+0x16>
 972:	87b6                	mv	a5,a3
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 974:	fee7fae3          	bgeu	a5,a4,968 <free+0x6c>
 978:	6394                	ld	a3,0(a5)
 97a:	f8d76ce3          	bltu	a4,a3,912 <free+0x16>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 97e:	f8d7fae3          	bgeu	a5,a3,912 <free+0x16>
 982:	87b6                	mv	a5,a3
 984:	bfc5                	j	974 <free+0x78>

0000000000000986 <malloc>:
  return freep;
}

void *
malloc(uint nbytes)
{
 986:	7139                	addi	sp,sp,-64
 988:	fc06                	sd	ra,56(sp)
 98a:	f822                	sd	s0,48(sp)
 98c:	f04a                	sd	s2,32(sp)
 98e:	ec4e                	sd	s3,24(sp)
 990:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1) / sizeof(Header) + 1;
 992:	02051993          	slli	s3,a0,0x20
 996:	0209d993          	srli	s3,s3,0x20
 99a:	09bd                	addi	s3,s3,15
 99c:	0049d993          	srli	s3,s3,0x4
 9a0:	2985                	addiw	s3,s3,1
 9a2:	894e                	mv	s2,s3
  if ((prevp = freep) == 0) {
 9a4:	00000517          	auipc	a0,0x0
 9a8:	65c53503          	ld	a0,1628(a0) # 1000 <freep>
 9ac:	c905                	beqz	a0,9dc <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
 9ae:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
 9b0:	4798                	lw	a4,8(a5)
 9b2:	09377663          	bgeu	a4,s3,a3e <malloc+0xb8>
 9b6:	f426                	sd	s1,40(sp)
 9b8:	e852                	sd	s4,16(sp)
 9ba:	e456                	sd	s5,8(sp)
 9bc:	e05a                	sd	s6,0(sp)
  if (nu < 4096)
 9be:	8a4e                	mv	s4,s3
 9c0:	6705                	lui	a4,0x1
 9c2:	00e9f363          	bgeu	s3,a4,9c8 <malloc+0x42>
 9c6:	6a05                	lui	s4,0x1
 9c8:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 9cc:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void *)(p + 1);
    }
    if (p == freep)
 9d0:	00000497          	auipc	s1,0x0
 9d4:	63048493          	addi	s1,s1,1584 # 1000 <freep>
  if (p == SBRK_ERROR)
 9d8:	5afd                	li	s5,-1
 9da:	a83d                	j	a18 <malloc+0x92>
 9dc:	f426                	sd	s1,40(sp)
 9de:	e852                	sd	s4,16(sp)
 9e0:	e456                	sd	s5,8(sp)
 9e2:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 9e4:	00000797          	auipc	a5,0x0
 9e8:	62c78793          	addi	a5,a5,1580 # 1010 <base>
 9ec:	00000717          	auipc	a4,0x0
 9f0:	60f73a23          	sd	a5,1556(a4) # 1000 <freep>
 9f4:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 9f6:	0007a423          	sw	zero,8(a5)
    if (p->s.size >= nunits) {
 9fa:	b7d1                	j	9be <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 9fc:	6398                	ld	a4,0(a5)
 9fe:	e118                	sd	a4,0(a0)
 a00:	a899                	j	a56 <malloc+0xd0>
  hp->s.size = nu;
 a02:	01652423          	sw	s6,8(a0)
  free((void *)(hp + 1));
 a06:	0541                	addi	a0,a0,16
 a08:	ef5ff0ef          	jal	8fc <free>
  return freep;
 a0c:	6088                	ld	a0,0(s1)
      if ((p = morecore(nunits)) == 0)
 a0e:	c125                	beqz	a0,a6e <malloc+0xe8>
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
 a10:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
 a12:	4798                	lw	a4,8(a5)
 a14:	03277163          	bgeu	a4,s2,a36 <malloc+0xb0>
    if (p == freep)
 a18:	6098                	ld	a4,0(s1)
 a1a:	853e                	mv	a0,a5
 a1c:	fef71ae3          	bne	a4,a5,a10 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 a20:	8552                	mv	a0,s4
 a22:	a07ff0ef          	jal	428 <sbrk>
  if (p == SBRK_ERROR)
 a26:	fd551ee3          	bne	a0,s5,a02 <malloc+0x7c>
        return 0;
 a2a:	4501                	li	a0,0
 a2c:	74a2                	ld	s1,40(sp)
 a2e:	6a42                	ld	s4,16(sp)
 a30:	6aa2                	ld	s5,8(sp)
 a32:	6b02                	ld	s6,0(sp)
 a34:	a03d                	j	a62 <malloc+0xdc>
 a36:	74a2                	ld	s1,40(sp)
 a38:	6a42                	ld	s4,16(sp)
 a3a:	6aa2                	ld	s5,8(sp)
 a3c:	6b02                	ld	s6,0(sp)
      if (p->s.size == nunits)
 a3e:	fae90fe3          	beq	s2,a4,9fc <malloc+0x76>
        p->s.size -= nunits;
 a42:	4137073b          	subw	a4,a4,s3
 a46:	c798                	sw	a4,8(a5)
        p += p->s.size;
 a48:	02071693          	slli	a3,a4,0x20
 a4c:	01c6d713          	srli	a4,a3,0x1c
 a50:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 a52:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 a56:	00000717          	auipc	a4,0x0
 a5a:	5aa73523          	sd	a0,1450(a4) # 1000 <freep>
      return (void *)(p + 1);
 a5e:	01078513          	addi	a0,a5,16
  }
}
 a62:	70e2                	ld	ra,56(sp)
 a64:	7442                	ld	s0,48(sp)
 a66:	7902                	ld	s2,32(sp)
 a68:	69e2                	ld	s3,24(sp)
 a6a:	6121                	addi	sp,sp,64
 a6c:	8082                	ret
 a6e:	74a2                	ld	s1,40(sp)
 a70:	6a42                	ld	s4,16(sp)
 a72:	6aa2                	ld	s5,8(sp)
 a74:	6b02                	ld	s6,0(sp)
 a76:	b7f5                	j	a62 <malloc+0xdc>
