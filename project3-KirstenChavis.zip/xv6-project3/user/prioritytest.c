#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define WORKLOAD 100000000LL

void do_work() {
  volatile long x = 1;
  for (long i = 0; i < WORKLOAD; i++) {
    x = (x << 1) ^ i;
    if (x == 0) x = 1;
  }
  (void)x;
}

int main(int argc, char *argv[]) {
  printf("--- STARTING SCHEDULER PERFORMANCE TESTS ---\n");

  // TEST 1: Fresh Allocation & Unequal Priorities
  printf("\n[Test 1] Unequal priorities & Allocation\n");
  
  int pid1 = fork();
  if (pid1 == 0) {
    // Should print kernel log showing birth at priority 50
    setpriority(10); // Raise priority to 10
    printf("High-priority child (10) starting math loop...\n");
    do_work();
    printf("High-priority child FINISHED\n");
    exit(0);
  }

  int pid2 = fork();
  if (pid2 == 0) {
    setpriority(150); // Lower priority to 150
    printf("Low-priority child (150) starting math loop...\n");
    do_work();
    printf("Low-priority child FINISHED\n");
    exit(0);
  }

  wait(0); wait(0);

  // TEST 2: Equal Runnable Priorities (Round-Robin Tie Breaking)
  printf("\n[Test 2] Equal priority Round-Robin Tie Breaking\n");
  setpriority(100); // Parent sets self to 100

  int pid3 = fork();
  if (pid3 == 0) {
    for(int i=1; i<=2; i++) {
      printf("Child A chunk %d\n", i);
      do_work();
    }
    exit(0);
  }

  int pid4 = fork();
  if (pid4 == 0) {
    for(int i=1; i<=2; i++) {
      printf("Child B chunk %d\n", i);
      do_work();
    }
    exit(0);
  }

  wait(0); wait(0);

  // TEST 3: Wakeup Adjustments
  printf("\n[Test 3] Testing Wakeup adjustments (-2 penalty reward)\n");
  int pid5 = fork();
  if (pid5 == 0) {
    setpriority(50);
    printf("Child going to sleep for 5 ticks...\n");
    sleep(5); // Forces SLEEPING state transition
    printf("Child woke up! Check kernel printout for -2 adjustment.\n");
    exit(0);
  }

  wait(0);
  printf("\nAll scheduler tests completed.\n");
  exit(0);
}
