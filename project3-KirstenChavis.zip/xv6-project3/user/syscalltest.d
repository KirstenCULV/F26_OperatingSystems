user/syscalltest.o: user/syscalltest.c kernel/types.h kernel/stat.h \
 user/user.h
