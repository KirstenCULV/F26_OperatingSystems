#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(int argc, char *argv[]) {
  printf("--- STARTING SYSTEM CALL TESTS ---\n");

  // 1. Test invalid inputs (should return -1)
  printf("Testing invalid boundary -1... ");
  if (setpriority(-1) == -1) printf("PASSED\n"); else printf("FAILED\n");

  printf("Testing invalid boundary 201... ");
  if (setpriority(201) == -1) printf("PASSED\n"); else printf("FAILED\n");

  // 2. Test valid inputs and old priority returns
  printf("Setting priority to 50... ");
  int old = setpriority(50);
  printf("PASSED (Returned old priority: %d)\n", old);

  printf("Setting priority to 200 (Lowering priority)... \n");
  printf("[Notice if system immediately yields here]\n");
  old = setpriority(200);
  printf("PASSED (Returned old priority: %d)\n", old);

  printf("Setting priority to 0 (Raising priority)... \n");
  printf("[Notice: Should NOT yield here]\n");
  old = setpriority(0);
  printf("PASSED (Returned old priority: %d)\n", old);

  exit(0);
}
