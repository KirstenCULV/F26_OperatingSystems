user/prioritytest.o: user/prioritytest.c kernel/types.h kernel/stat.h \
 user/user.h
