user/printf.o: user/printf.c kernel/types.h kernel/stat.h user/user.h \
 C:/msys64/ucrt64/lib/gcc/riscv64-unknown-elf/16.1.0/include/stdarg.h
